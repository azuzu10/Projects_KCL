@echo off
cd /d "C:\Users\azaan\Desktop\Kings\Final project"
"C:\Users\azaan\Desktop\Kings\Final project\.venv\Scripts\python.exe" ^
    "KCL Main Project\Execution\accessibility_cli.py" download ^
    --pbf-dir "KCL Main Project\Execution\pbf_data" ^
    > "KCL Main Project\Execution\pbf_data\download_log.txt" 2>&1
echo DONE >> "KCL Main Project\Execution\pbf_data\download_log.txt"
