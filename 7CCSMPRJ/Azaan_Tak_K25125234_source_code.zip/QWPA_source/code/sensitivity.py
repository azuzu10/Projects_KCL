#!/usr/bin/env python3
"""
Sensitivity sweeps over the four parameters the report fixes by convention:
the 15-minute threshold T, the GMA decay constant tau = 10 min, the QAMD
quality cut q = 0, and the 3 km grid buffer. The question being answered is the
one an examiner will ask -- do the conclusions survive moving these?

Four sweeps. A (T in 5..30) is free, it just re-reads qamd_<city>.csv. B drops
the buffer by restricting to cells inside the admin boundary. C (tau) and D (q)
are the expensive ones: both parameters act during index computation, so each
value needs the origin-destination matrix rebuilt, which is why C and D run on
a --cities subset rather than all ten.

    python3 sensitivity.py --sweep A --out-dir output_figures
    python3 sensitivity.py --sweep B --out-dir output_figures --cache-dir .pipeline_cache
    python3 sensitivity.py --sweep CD --out-dir output_figures \
            --cache-dir .pipeline_cache --cities amsterdam paris washington_dc
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np
import pandas as pd

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

DIMS = ["cultural", "environmental", "nature", "physical", "social"]
ALL_CITIES = ["paris", "montreal", "new_york", "washington_dc", "berlin",
              "amsterdam", "madrid", "rome", "singapore", "melbourne"]


def n_cells(out_dir: str, city: str) -> int:
    return int(pd.read_csv(os.path.join(out_dir, f"meta_{city}.csv"))["n_cells"].iloc[0])


# --- Sweep A: walking-time threshold

def sweep_threshold(out_dir: str, cities: list[str],
                    thresholds=(5, 10, 15, 20, 30)) -> pd.DataFrame:
    """
    QAMD stores minutes to the nearest qualifying park, so varying the threshold
    is just a different cut on an existing column -- no recomputation needed.
    """
    rows = []
    for city in cities:
        qamd = pd.read_csv(os.path.join(out_dir, f"qamd_{city}.csv"))
        n = n_cells(out_dir, city)
        for T in thresholds:
            per_dim = {}
            for d in DIMS:
                v = qamd[f"QAMD_{d}"].dropna()
                per_dim[d] = 100 * (v <= T).sum() / n
            worst = min(per_dim, key=per_dim.get)
            best = max(per_dim, key=per_dim.get)
            rows.append({
                "city": city, "threshold_min": T,
                "mean_pct_of_all": float(np.mean(list(per_dim.values()))),
                "worst_dim": worst, "worst_pct": per_dim[worst],
                "best_dim": best, "best_pct": per_dim[best],
                **{f"pct_{d}": per_dim[d] for d in DIMS},
            })
    return pd.DataFrame(rows)


# --- Sweep B: grid buffer

def sweep_buffer(out_dir: str, cache_dir: str, cities: list[str]) -> pd.DataFrame:
    """
    Recompute coverage using only cells whose centroid falls inside the
    administrative boundary, and compare with the published figure, which uses
    the boundary plus a 3 km buffer.
    """
    import geopandas as gpd
    from shapely.prepared import prep

    rows = []
    for city in cities:
        bpath = os.path.join(cache_dir, f"{city}_boundary.geojson")
        cpath = os.path.join(out_dir, f"cells_{city}.csv")
        if not (os.path.exists(bpath) and os.path.exists(cpath)):
            print(f"  {city}: missing boundary or cells, skipped", file=sys.stderr)
            continue

        boundary = gpd.read_file(bpath).geometry.iloc[0]
        cells = pd.read_csv(cpath)
        pts = gpd.GeoSeries(gpd.points_from_xy(cells["cx"], cells["cy"]),
                            crs="EPSG:4326")
        inside = pts.within(boundary).values
        cells_in = cells.loc[inside, ["x", "y"]]
        n_all, n_in = len(cells), int(inside.sum())

        qwe = pd.read_csv(os.path.join(out_dir, f"qwe_{city}.csv"))
        gma = pd.read_csv(os.path.join(out_dir, f"gma_{city}.csv"))
        qamd = pd.read_csv(os.path.join(out_dir, f"qamd_{city}.csv"))

        def cov(df, prefix, keys_in=None, denom=None):
            cols = [f"{prefix}_{d}" for d in DIMS]
            hit = df[df[cols].sum(axis=1) > 0][["x_source", "y_source"]]
            if keys_in is not None:
                hit = hit.merge(keys_in, left_on=["x_source", "y_source"],
                                right_on=["x", "y"], how="inner")
            return 100 * len(hit) / denom

        def qamd_cov(df, keys_in=None, denom=None, T=15):
            tot = 0.0
            for d in DIMS:
                sub = df[["x_source", "y_source", f"QAMD_{d}"]].dropna()
                sub = sub[sub[f"QAMD_{d}"] <= T]
                if keys_in is not None:
                    sub = sub.merge(keys_in, left_on=["x_source", "y_source"],
                                    right_on=["x", "y"], how="inner")
                tot += 100 * len(sub) / denom
            return tot / len(DIMS)

        rows.append({
            "city": city,
            "cells_buffered": n_all,
            "cells_admin_only": n_in,
            "pct_of_grid_inside": 100 * n_in / n_all,
            "qwe_buffered": cov(qwe, "QWE", None, n_all),
            "qwe_admin_only": cov(qwe, "QWE", cells_in, n_in),
            "gma_buffered": cov(gma, "GMA", None, n_all),
            "gma_admin_only": cov(gma, "GMA", cells_in, n_in),
            "qamd15_buffered": qamd_cov(qamd, None, n_all),
            "qamd15_admin_only": qamd_cov(qamd, cells_in, n_in),
        })
        print(f"  {city:<14} {n_in:>9,}/{n_all:<9,} cells inside "
              f"({100*n_in/n_all:4.1f}%)", flush=True)
    return pd.DataFrame(rows)


# --- Sweeps C and D: tau and q (need the OD matrix)

def sweep_tau_q(out_dir: str, cache_dir: str, cities: list[str],
                taus=(5, 10, 15, 20), qs=(-0.5, 0.0, 0.5, 1.0),
                chunk: int = 12000) -> tuple[pd.DataFrame, pd.DataFrame]:
    import geopandas as gpd
    import quality_accessibility_osmium as qa
    import fast_distance

    tau_rows, q_rows = [], []
    for city in cities:
        cpq = os.path.join(cache_dir, f"{city}_cells.parquet")
        cpc = os.path.join(cache_dir, f"{city}_cells.csv")
        cp = cpq if os.path.exists(cpq) else cpc
        ov = os.path.join(cache_dir, f"{city}_overlap.parquet")
        cs = os.path.join(cache_dir, f"{city}_cell_scores.parquet")
        if not (os.path.exists(cp) and os.path.exists(ov) and os.path.exists(cs)):
            print(f"  {city}: cache incomplete, skipped", file=sys.stderr)
            continue

        cdf = pd.read_parquet(cp) if cp.endswith(".parquet") else pd.read_csv(cp)
        cells = gpd.GeoDataFrame(cdf.drop(columns=["geometry_wkt"]),
                                 geometry=gpd.GeoSeries.from_wkt(cdf["geometry_wkt"]),
                                 crs="EPSG:4326")
        overlap = pd.read_parquet(ov)
        cell_scores = pd.read_parquet(cs)
        n = len(cells)

        gma_hits = {t: 0 for t in taus}
        qamd_hits = {(q, d): 0 for q in qs for d in DIMS}

        for lo in range(0, n, chunk):
            mask = np.zeros(n, dtype=bool)
            mask[lo:min(lo + chunk, n)] = True
            dsub = fast_distance.build_distance_df_fast(
                cells, overlap, origin_mask=mask, verbose=False)
            if len(dsub) == 0:
                continue
            for t in taus:
                g = qa.gravity_accessibility(dsub, cell_scores, tau=float(t))
                if len(g):
                    gma_hits[t] += int((g[[f"GMA_{d}" for d in DIMS]]
                                        .sum(axis=1) > 0).sum())
            for q in qs:
                a = qa.quality_adjusted_min_distance(dsub, cell_scores, q=float(q))
                for d in DIMS:
                    col = f"QAMD_{d}"
                    if col in a.columns:
                        qamd_hits[(q, d)] += int((a[col].dropna() <= 15).sum())
            del dsub

        for t in taus:
            tau_rows.append({"city": city, "tau_min": t,
                             "gma_pct": 100 * gma_hits[t] / n})
        for q in qs:
            per = {d: 100 * qamd_hits[(q, d)] / n for d in DIMS}
            q_rows.append({"city": city, "q": q,
                           "mean_pct": float(np.mean(list(per.values()))),
                           "worst_dim": min(per, key=per.get),
                           **{f"pct_{d}": per[d] for d in DIMS}})
        print(f"  {city} done", flush=True)
    return pd.DataFrame(tau_rows), pd.DataFrame(q_rows)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--sweep", default="A", help="A, B, CD or ABCD")
    ap.add_argument("--out-dir", default="output_figures")
    ap.add_argument("--cache-dir", default=".pipeline_cache")
    ap.add_argument("--cities", nargs="+", default=None)
    ap.add_argument("--chunk", type=int, default=12000)
    args = ap.parse_args()

    cities = args.cities or ALL_CITIES
    sw = args.sweep.upper()

    if "A" in sw:
        print("Sweep A: walking-time threshold")
        df = sweep_threshold(args.out_dir, cities)
        p = os.path.join(args.out_dir, "sensitivity_threshold.csv")
        df.round(3).to_csv(p, index=False)
        print(f"  -> {p}\n")

    if "B" in sw:
        print("Sweep B: grid buffer (admin-only vs +3km)")
        df = sweep_buffer(args.out_dir, args.cache_dir, cities)
        p = os.path.join(args.out_dir, "sensitivity_buffer.csv")
        df.round(3).to_csv(p, index=False)
        print(f"  -> {p}\n")

    if "C" in sw or "D" in sw:
        print("Sweeps C/D: tau and q")
        t, q = sweep_tau_q(args.out_dir, args.cache_dir, cities, chunk=args.chunk)
        pt = os.path.join(args.out_dir, "sensitivity_tau.csv")
        pq = os.path.join(args.out_dir, "sensitivity_q.csv")
        t.round(3).to_csv(pt, index=False)
        q.round(3).to_csv(pq, index=False)
        print(f"  -> {pt}\n  -> {pq}\n")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
