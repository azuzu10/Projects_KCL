#!/usr/bin/env python3
"""
Command-line front end for the pipeline.

Four subcommands: run (one city), run-all (all 35, or --cities for a subset),
download (fetch PBFs from Geofabrik without running anything), and list-cities
(cities, relation IDs, PBF sources).

Typical invocations:

    python accessibility_cli.py run amsterdam --pbf noord-holland-260620.osm.pbf
    python accessibility_cli.py run berlin --auto-download
    python accessibility_cli.py run-all --cities london paris berlin tokyo
    python accessibility_cli.py run amsterdam --pbf f.osm.pbf --threshold 10 --tau 5 --q 0.5 --buffer 2000
    python accessibility_cli.py download
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
import time
import traceback
import urllib.request
from datetime import datetime
from pathlib import Path

# --- Resolve import path
_HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(_HERE))

from quality_accessibility_osmium import (   # noqa: E402
    run as _run_pipeline,
    CITY_OSM_RELATIONS,
    SCORE_DIMS,
)

# --- Geofabrik PBF catalogue
# city -> (url, local_filename, approx_size_mb)
# (*) marks files > 1 GB

PBF_CATALOGUE: dict[str, tuple[str, str, int]] = {
    "amsterdam":     ("https://download.geofabrik.de/europe/netherlands-latest.osm.pbf",                           "netherlands-latest.osm.pbf",              900),
    "auckland":      ("https://download.geofabrik.de/australia-oceania/new-zealand-latest.osm.pbf",                "new-zealand-latest.osm.pbf",              900),
    "berlin":        ("https://download.geofabrik.de/europe/germany/berlin-latest.osm.pbf",                        "berlin-latest.osm.pbf",                   190),
    "boston":        ("https://download.geofabrik.de/north-america/us/massachusetts-latest.osm.pbf",               "massachusetts-latest.osm.pbf",            500),
    "buenos_aires":  ("https://download.geofabrik.de/south-america/argentina-latest.osm.pbf",                      "argentina-latest.osm.pbf",                750),
    "chicago":       ("https://download.geofabrik.de/north-america/us/illinois-latest.osm.pbf",                    "illinois-latest.osm.pbf",                 460),
    "christchurch":  ("https://download.geofabrik.de/australia-oceania/new-zealand-latest.osm.pbf",                "new-zealand-latest.osm.pbf",              900),
    "copenhagen":    ("https://download.geofabrik.de/europe/denmark-latest.osm.pbf",                               "denmark-latest.osm.pbf",                  360),
    "hong_kong":     ("https://download.geofabrik.de/asia/hong-kong-latest.osm.pbf",                               "hong-kong-latest.osm.pbf",                 55),
    "houston":       ("https://download.geofabrik.de/north-america/us/texas-latest.osm.pbf",                       "texas-latest.osm.pbf",                   1400),  # (*)
    "london":        ("https://download.geofabrik.de/europe/great-britain/england/greater-london-latest.osm.pbf",  "greater-london-latest.osm.pbf",           120),
    "madrid":        ("https://download.geofabrik.de/europe/spain-latest.osm.pbf",                                 "spain-latest.osm.pbf",                   1050),  # (*)
    "melbourne":     ("https://download.geofabrik.de/australia-oceania/australia/victoria-latest.osm.pbf",         "victoria-latest.osm.pbf",                 420),
    "montreal":      ("https://download.geofabrik.de/north-america/canada/quebec-latest.osm.pbf",                  "quebec-latest.osm.pbf",                   600),
    "moscow":        ("https://download.geofabrik.de/europe/russia/central-fed-district-latest.osm.pbf",           "central-fed-district-latest.osm.pbf",    1800),  # (*)
    "new_york":      ("https://download.geofabrik.de/north-america/us/new-york-latest.osm.pbf",                    "new-york-latest.osm.pbf",                1100),  # (*)
    "paris":         ("https://download.geofabrik.de/europe/france/ile-de-france-latest.osm.pbf",                  "ile-de-france-latest.osm.pbf",            450),
    "perth":         ("https://download.geofabrik.de/australia-oceania/australia/western-australia-latest.osm.pbf","western-australia-latest.osm.pbf",        560),
    "philadelphia":  ("https://download.geofabrik.de/north-america/us/pennsylvania-latest.osm.pbf",                "pennsylvania-latest.osm.pbf",             600),
    "rio_de_janeiro":("https://download.geofabrik.de/south-america/brazil/sudeste-latest.osm.pbf",                 "sudeste-latest.osm.pbf",                 1600),  # (*)
    "rome":          ("https://download.geofabrik.de/europe/italy/centro-latest.osm.pbf",                          "centro-latest.osm.pbf",                   450),
    "san_diego":     ("https://download.geofabrik.de/north-america/us/california-latest.osm.pbf",                  "california-latest.osm.pbf",              4000),  # (*)
    "san_francisco": ("https://download.geofabrik.de/north-america/us/california-latest.osm.pbf",                  "california-latest.osm.pbf",              4000),  # (*)
    "seattle":       ("https://download.geofabrik.de/north-america/us/washington-latest.osm.pbf",                  "washington-latest.osm.pbf",               570),
    "seoul":         ("https://download.geofabrik.de/asia/south-korea-latest.osm.pbf",                             "south-korea-latest.osm.pbf",              460),
    "singapore":     ("https://download.geofabrik.de/asia/malaysia-singapore-brunei-latest.osm.pbf",               "malaysia-singapore-brunei-latest.osm.pbf",620),
    "st_petersburg": ("https://download.geofabrik.de/europe/russia/northwestern-fed-district-latest.osm.pbf",      "northwestern-fed-district-latest.osm.pbf",1500), # (*)
    "stockholm":     ("https://download.geofabrik.de/europe/sweden-latest.osm.pbf",                                "sweden-latest.osm.pbf",                   650),
    "sydney":        ("https://download.geofabrik.de/australia-oceania/australia/new-south-wales-latest.osm.pbf",  "new-south-wales-latest.osm.pbf",          820),
    "taipeh":        ("https://download.geofabrik.de/asia/taiwan-latest.osm.pbf",                                  "taiwan-latest.osm.pbf",                   360),
    "tokyo":         ("https://download.geofabrik.de/asia/japan/kanto-latest.osm.pbf",                             "kanto-latest.osm.pbf",                    950),
    "toronto":       ("https://download.geofabrik.de/north-america/canada/ontario-latest.osm.pbf",                 "ontario-latest.osm.pbf",                 1200),  # (*)
    "vancouver":     ("https://download.geofabrik.de/north-america/canada/british-columbia-latest.osm.pbf",        "british-columbia-latest.osm.pbf",         510),
    "vienna":        ("https://download.geofabrik.de/europe/austria-latest.osm.pbf",                               "austria-latest.osm.pbf",                  600),
    "washington_dc": ("https://download.geofabrik.de/north-america/us/district-of-columbia-latest.osm.pbf",        "district-of-columbia-latest.osm.pbf",      70),
}

_DEFAULT_SCORES = (
    "Health-Promoting-Parks-Replication-main/"
    "Health-Promoting-Parks-Replication-main/data/scores_cities.csv"
)
_DEFAULT_FINGERPRINTS = (
    "Health-Promoting-Parks-Replication-main/"
    "Health-Promoting-Parks-Replication-main/data/fingerprints_cities.csv"
)

# --- Download helpers

def _progress(block: int, block_size: int, total: int) -> None:
    done = block * block_size
    if total > 0:
        pct  = min(done / total * 100, 100)
        bar  = "#" * int(pct // 2)
        print(f"\r  [{bar:<50}] {pct:5.1f}%  {done/1e6:.0f}/{total/1e6:.0f} MB",
              end="", flush=True)
    else:
        print(f"\r  Downloaded {done/1e6:.0f} MB", end="", flush=True)


def _download_pbf(url: str, dest: Path, skip_existing: bool = True) -> bool:
    """
    Download *url* to *dest*. Returns True if the file was already present.
    Raises RuntimeError on failure, cleans up partial download automatically.
    """
    if dest.exists() and skip_existing:
        size_mb = dest.stat().st_size / 1e6
        print(f"  [exists] {dest.name}  ({size_mb:.0f} MB) — skipping download.")
        return True
    print(f"  [fetch]  {url}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        urllib.request.urlretrieve(url, str(dest), reporthook=_progress)
        print()
        print(f"  [saved]  {dest}  ({dest.stat().st_size/1e6:.0f} MB)")
        return False
    except Exception as exc:
        if dest.exists():
            dest.unlink()
        raise RuntimeError(f"Download failed: {exc}") from exc


# --- Result persistence

def _save_results(city: str, results: dict, out_dir: Path) -> None:
    city_dir = out_dir / city
    city_dir.mkdir(parents=True, exist_ok=True)
    for key in ("qwe", "qamd", "gma", "best", "cell_scores", "overlap"):
        results[key].to_csv(city_dir / f"{key}_{city}.csv", index=False)
    # Save cell centroids for the map visualisation
    if results.get("cells") is not None:
        results["cells"][["x", "y", "cx", "cy"]].to_csv(
            city_dir / f"cells_{city}.csv", index=False
        )
    # Save park geometries for the map visualisation
    if results.get("parks") is not None and len(results["parks"]) > 0:
        try:
            results["parks"].to_file(
                str(city_dir / f"parks_{city}.geojson"), driver="GeoJSON"
            )
        except Exception as exc:
            print(f"  Warning: could not save parks GeoJSON: {exc}")
    print(f"  Saved to {city_dir}/")


def _outputs_exist(city: str, out_dir: Path) -> bool:
    city_dir = out_dir / city
    return all(
        (city_dir / f"{k}_{city}.csv").exists()
        for k in ("qwe", "qamd", "gma", "best")
    )


def _log_row(log_path: Path, row: dict) -> None:
    write_header = not log_path.exists()
    with open(log_path, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(row.keys()))
        if write_header:
            w.writeheader()
        w.writerow(row)


# --- Subcommand: list-cities

def cmd_list_cities(_args: argparse.Namespace) -> None:
    header = f"{'City':<20} {'OSM Relation':>14}  {'PBF file':<42}  {'~MB':>5}"
    print(header)
    print("-" * len(header))
    for city in sorted(CITY_OSM_RELATIONS):
        rel_id = CITY_OSM_RELATIONS[city]
        url, fname, mb = PBF_CATALOGUE[city]
        flag = " (*)" if mb >= 1000 else ""
        print(f"{city:<20} {rel_id:>14}  {fname:<42}  {mb:>5}{flag}")
    print("\n(*) File larger than 1 GB — expect a long download.")


# --- Subcommand: download

def cmd_download(args: argparse.Namespace) -> None:
    cities   = args.cities or sorted(PBF_CATALOGUE.keys())
    pbf_dir  = Path(args.pbf_dir)

    unknown = [c for c in cities if c not in PBF_CATALOGUE]
    if unknown:
        sys.exit(f"Unknown cities: {unknown}.  Run 'list-cities' to see valid names.")

    print(f"\nDownloading PBF files -> {pbf_dir.resolve()}\n")
    seen: set[str] = set()
    for city in cities:
        url, fname, mb = PBF_CATALOGUE[city]
        if fname in seen:
            continue
        seen.add(fname)
        flag = "  (*LARGE*)" if mb >= 1000 else ""
        print(f"[{city}]  {fname}  (~{mb} MB{flag})")
        try:
            _download_pbf(url, pbf_dir / fname)
        except RuntimeError as exc:
            print(f"  WARNING: {exc}")
    print("\nDone.")


# --- Subcommand: run

def cmd_run(args: argparse.Namespace) -> None:
    city = args.city

    if city not in CITY_OSM_RELATIONS:
        sys.exit(
            f"Unknown city '{city}'.\n"
            f"Run 'list-cities' to see the {len(CITY_OSM_RELATIONS)} available cities."
        )

    # Resolve PBF path
    if args.pbf:
        pbf_path = Path(args.pbf)
    elif args.auto_download:
        url, fname, mb = PBF_CATALOGUE[city]
        pbf_path = Path(args.pbf_dir) / fname
        flag = "  (*LARGE*)" if mb >= 1000 else ""
        print(f"\nAuto-download: {fname}  (~{mb} MB{flag})")
        try:
            _download_pbf(url, pbf_path)
        except RuntimeError as exc:
            sys.exit(str(exc))
    else:
        sys.exit(
            "Provide either --pbf <file.osm.pbf>  or  --auto-download.\n"
            "Run 'download' first to get the PBF, then pass it with --pbf."
        )

    if not pbf_path.exists():
        sys.exit(f"PBF file not found: {pbf_path}")

    out_dir = Path(args.out_dir)

    if not args.force and _outputs_exist(city, out_dir):
        print(f"Output CSVs already exist for '{city}'. Use --force to overwrite.")
        return

    _run_one(
        city        = city,
        pbf_path    = pbf_path,
        out_dir     = out_dir,
        scores      = args.scores,
        fingerprints= args.fingerprints,
        buffer_m    = args.buffer,
        threshold   = args.threshold,
        tau         = args.tau,
        q           = args.q,
        best_thresholds = args.best_thresholds,
        log_path    = out_dir / "run_log.csv",
    )


# --- Subcommand: run-all

def cmd_run_all(args: argparse.Namespace) -> None:
    cities  = args.cities or sorted(CITY_OSM_RELATIONS.keys())
    out_dir = Path(args.out_dir)
    pbf_dir = Path(args.pbf_dir)
    log_path = out_dir / "run_log.csv"

    unknown = [c for c in cities if c not in CITY_OSM_RELATIONS]
    if unknown:
        sys.exit(f"Unknown cities: {unknown}.  Run 'list-cities' to see valid names.")

    print(f"\n{'='*62}")
    print(f"  Batch run — {len(cities)} city/cities")
    print(f"  PBF dir : {pbf_dir.resolve()}")
    print(f"  Out dir : {out_dir.resolve()}")
    print(f"{'='*62}\n")

    # --- Phase 1: download missing PBFs
    if not args.skip_download:
        print("PHASE 1 — Downloading PBF files\n")
        seen: set[str] = set()
        for city in cities:
            url, fname, mb = PBF_CATALOGUE[city]
            if fname in seen:
                continue
            seen.add(fname)
            flag = "  (*LARGE*)" if mb >= 1000 else ""
            print(f"  [{city}]  {fname}  (~{mb} MB{flag})")
            try:
                _download_pbf(url, pbf_dir / fname)
            except RuntimeError as exc:
                print(f"  WARNING: {exc}")
        print()
    else:
        print("PHASE 1 — Skipped (--skip-download)\n")

    # --- Phase 2: run pipeline per city
    print("PHASE 2 — Running pipeline\n")
    results_ok:  list[str] = []
    results_skip:list[str] = []
    results_fail:list[tuple[str, str]] = []

    for idx, city in enumerate(cities, 1):
        print(f"[{idx:02d}/{len(cities):02d}]  {city.upper()}")

        if not args.force and _outputs_exist(city, out_dir):
            print(f"  Already done — skipping. Use --force to re-run.\n")
            results_skip.append(city)
            _log_row(log_path, {
                "timestamp": _now(), "city": city, "status": "skipped",
                "elapsed_s": 0, "grid_cells": "", "parks": "",
                "green_cells": "", "dist_pairs": "", "error": "",
            })
            continue

        _, fname, _ = PBF_CATALOGUE[city]
        pbf_path = pbf_dir / fname

        if not pbf_path.exists():
            msg = f"PBF not found: {pbf_path}  (run 'download' first)"
            print(f"  SKIPPED: {msg}\n")
            results_fail.append((city, msg))
            _log_row(log_path, {
                "timestamp": _now(), "city": city, "status": "FAILED",
                "elapsed_s": 0, "grid_cells": "", "parks": "",
                "green_cells": "", "dist_pairs": "", "error": msg,
            })
            continue

        ok = _run_one(
            city        = city,
            pbf_path    = pbf_path,
            out_dir     = out_dir,
            scores      = args.scores,
            fingerprints= args.fingerprints,
            buffer_m    = args.buffer,
            threshold   = args.threshold,
            tau         = args.tau,
            q           = args.q,
            best_thresholds = args.best_thresholds,
            log_path    = log_path,
        )
        (results_ok if ok else results_fail).append(
            city if ok else (city, "pipeline error — see log")
        )
        print()

    # --- Summary
    print("=" * 62)
    print("  BATCH COMPLETE")
    print(f"  OK      : {len(results_ok)}   {results_ok}")
    print(f"  Skipped : {len(results_skip)}  {results_skip}")
    print(f"  Failed  : {len(results_fail)}")
    for entry in results_fail:
        city, err = (entry, "error") if isinstance(entry, str) else entry
        print(f"    {city}: {err}")
    print(f"\n  Log: {log_path.resolve()}")
    print("=" * 62)


# --- Shared pipeline runner

def _run_one(
    city: str,
    pbf_path: Path,
    out_dir: Path,
    scores: str,
    fingerprints: str,
    buffer_m: float,
    threshold: float,
    tau: float,
    q: float,
    best_thresholds: list[float],
    log_path: Path,
) -> bool:
    """Run pipeline for one city. Returns True on success."""
    print(f"  PBF  : {pbf_path}")
    print(f"  Params: buffer={buffer_m}m  threshold={threshold}min  tau={tau}  q={q}  "
          f"best=[{','.join(str(int(t)) for t in best_thresholds)}]min")
    t0 = time.time()
    try:
        results = _run_pipeline(
            city              = city,
            pbf_path          = str(pbf_path),
            scores_path       = scores,
            fingerprints_path = fingerprints,
            buffer_m          = buffer_m,
            qwe_threshold_min = threshold,
            gma_tau           = tau,
            qamd_q            = q,
        )
        elapsed = time.time() - t0
        _save_results(city, results, out_dir)

        cells  = len(results["cells"])
        parks  = len(results["parks"])
        green  = len(results["cell_scores"])
        pairs  = len(results["dist_df"])
        print(f"  Done in {elapsed:.0f}s | cells={cells:,} parks={parks} "
              f"green_cells={green:,} dist_pairs={pairs:,}")

        _log_row(log_path, {
            "timestamp": _now(), "city": city, "status": "ok",
            "elapsed_s": round(elapsed, 1),
            "grid_cells": cells, "parks": parks,
            "green_cells": green, "dist_pairs": pairs, "error": "",
        })
        return True

    except Exception:
        elapsed = time.time() - t0
        tb = traceback.format_exc()
        short = tb.strip().splitlines()[-1]
        print(f"  FAILED after {elapsed:.0f}s: {short}")
        for line in tb.splitlines():
            print(f"    {line}")
        _log_row(log_path, {
            "timestamp": _now(), "city": city, "status": "FAILED",
            "elapsed_s": round(elapsed, 1),
            "grid_cells": "", "parks": "", "green_cells": "", "dist_pairs": "",
            "error": short,
        })
        return False


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# --- Argument parser

def _add_index_params(p: argparse.ArgumentParser) -> None:
    """Add shared index-tuning arguments to a subparser."""
    g = p.add_argument_group("index parameters")
    g.add_argument("--threshold", type=float, default=15.0, metavar="MIN",
                   help="QWE walking-time threshold in minutes (default: 15)")
    g.add_argument("--tau", type=float, default=10.0, metavar="MIN",
                   help="GMA exponential decay half-life in minutes (default: 10)")
    g.add_argument("--q", type=float, default=0.0, metavar="SCORE",
                   help="QAMD minimum quality z-score threshold (default: 0.0 = above average)")
    g.add_argument("--best-thresholds", nargs="+", type=float,
                   default=[5.0, 15.0, 30.0], metavar="MIN",
                   help="BEST walking-time thresholds in minutes (default: 5 15 30)")
    g.add_argument("--buffer", type=float, default=3000.0, metavar="M",
                   help="City boundary buffer in metres for grid generation (default: 3000)")

def _add_data_params(p: argparse.ArgumentParser) -> None:
    """Add shared data-path arguments to a subparser."""
    g = p.add_argument_group("data paths")
    g.add_argument("--scores", default=_DEFAULT_SCORES, metavar="CSV",
                   help="Path to scores_cities.csv (Dietz et al.)")
    g.add_argument("--fingerprints", default=_DEFAULT_FINGERPRINTS, metavar="CSV",
                   help="Path to fingerprints_cities.csv (Dietz et al.)")
    g.add_argument("--out-dir", default="output_figures", metavar="DIR",
                   help="Root output folder for result CSVs (default: output_figures/)")

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="accessibility_cli.py",
        description="Quality-weighted park accessibility analysis CLI.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")
    sub.required = True

    # --- list-cities
    sub.add_parser(
        "list-cities",
        help="Print all 35 available cities with their OSM IDs and PBF sources.",
    )

    # --- download
    p_dl = sub.add_parser(
        "download",
        help="Download Geofabrik PBF files for the given cities (or all 35).",
    )
    p_dl.add_argument("--cities", nargs="+", metavar="CITY",
                      help="Cities to download (default: all 35).")
    p_dl.add_argument("--pbf-dir", default="pbf_data", metavar="DIR",
                      help="Directory to save PBF files (default: pbf_data/).")

    # --- run
    p_run = sub.add_parser(
        "run",
        help="Run the full pipeline for a single city.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="""
Run the quality-weighted accessibility pipeline for one city.

Examples
--------
  # With an existing PBF:
  python accessibility_cli.py run amsterdam --pbf noord-holland-260620.osm.pbf

  # Auto-download PBF then run:
  python accessibility_cli.py run berlin --auto-download

  # Custom index parameters:
  python accessibility_cli.py run london --pbf greater-london.osm.pbf \\
      --threshold 10 --tau 5 --q 0.5
        """,
    )
    p_run.add_argument("city", metavar="CITY",
                       help=f"City name. One of: {', '.join(sorted(CITY_OSM_RELATIONS))}.")
    pbf_group = p_run.add_mutually_exclusive_group()
    pbf_group.add_argument("--pbf", metavar="FILE",
                           help="Path to an existing .osm.pbf file.")
    pbf_group.add_argument("--auto-download", action="store_true",
                           help="Download the PBF from Geofabrik automatically.")
    p_run.add_argument("--pbf-dir", default="pbf_data", metavar="DIR",
                       help="Where to save auto-downloaded PBF (default: pbf_data/).")
    p_run.add_argument("--force", action="store_true",
                       help="Overwrite existing output CSVs if present.")
    _add_index_params(p_run)
    _add_data_params(p_run)

    # --- run-all
    p_all = sub.add_parser(
        "run-all",
        help="Run the pipeline for all 35 cities (or a subset).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        description="""
Run the pipeline for all 35 study cities in sequence.
PBF files are downloaded automatically unless --skip-download is set.

Examples
--------
  # All 35 cities:
  python accessibility_cli.py run-all

  # Specific subset:
  python accessibility_cli.py run-all --cities london paris berlin tokyo

  # Use PBFs already on disk, skip download:
  python accessibility_cli.py run-all --skip-download --pbf-dir /data/osm

  # Re-run even if outputs exist:
  python accessibility_cli.py run-all --cities amsterdam --force
        """,
    )
    p_all.add_argument("--cities", nargs="+", metavar="CITY",
                       help="Subset of cities to run (default: all 35).")
    p_all.add_argument("--pbf-dir", default="pbf_data", metavar="DIR",
                       help="Directory containing or to download PBF files (default: pbf_data/).")
    p_all.add_argument("--skip-download", action="store_true",
                       help="Do not download any PBF files; fail if a file is missing.")
    p_all.add_argument("--force", action="store_true",
                       help="Overwrite existing output CSVs.")
    _add_index_params(p_all)
    _add_data_params(p_all)

    return parser


# --- Entry point

def main() -> None:
    parser = build_parser()
    args   = parser.parse_args()

    dispatch = {
        "list-cities": cmd_list_cities,
        "download":    cmd_download,
        "run":         cmd_run,
        "run-all":     cmd_run_all,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
