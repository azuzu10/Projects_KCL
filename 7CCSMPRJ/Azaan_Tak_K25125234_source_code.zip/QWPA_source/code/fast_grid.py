#!/usr/bin/env python3
"""
Vectorised replacement for quality_accessibility_osmium.generate_ghs_grid().

The original builds a dict and a shapely box per cell in a nested loop, then
checks intersection against the boundary with no spatial index. Fine for
Amsterdam; for a metro boundary spanning hundreds of thousands of cells it
dominated the entire pipeline's runtime. Here the cell polygons come from one
shapely.box() call over numpy arrays and the boundary test goes through an
STRtree.

The point is speed, not different answers: same columns (x, y, cx, cy,
geometry), same CRS, same cells, same row order. verify_against_reference()
confirms that on a given boundary -- Amsterdam matches to the byte.
"""

from __future__ import annotations

import numpy as np
import geopandas as gpd
import shapely

try:  # shapely 2.x
    from shapely import box as _box_scalar
    from shapely import STRtree
    _SHAPELY2 = True
except ImportError:  # pragma: no cover
    from shapely.geometry import box as _box_scalar
    STRtree = None
    _SHAPELY2 = False

from shapely.ops import unary_union

GHS_CELL_DEG = 3.0 / 3600.0  # 3 arc-seconds


def generate_ghs_grid_fast(
    boundary: gpd.GeoDataFrame,
    buffer_m: float = 3000.0,
    cell_deg: float = GHS_CELL_DEG,
) -> gpd.GeoDataFrame:
    """Vectorised GHS-aligned grid generation. See module docstring."""
    boundary_proj = boundary.to_crs(boundary.estimate_utm_crs())
    boundary_buf = boundary_proj.buffer(buffer_m).to_crs("EPSG:4326")
    bounds = boundary_buf.total_bounds

    minx = np.floor(bounds[0] / cell_deg) * cell_deg
    miny = np.floor(bounds[1] / cell_deg) * cell_deg
    maxx = np.ceil(bounds[2] / cell_deg) * cell_deg
    maxy = np.ceil(bounds[3] / cell_deg) * cell_deg

    xs = np.arange(minx, maxx, cell_deg)
    ys = np.arange(miny, maxy, cell_deg)

    # Original loops col-major: for each x (col_i), for each y (row_j).
    # Reproduce that ordering exactly with meshgrid(indexing='ij').
    col_idx, row_idx = np.meshgrid(
        np.arange(len(xs)), np.arange(len(ys)), indexing="ij"
    )
    xx, yy = np.meshgrid(xs, ys, indexing="ij")

    col_idx = col_idx.ravel()
    row_idx = row_idx.ravel()
    xx = xx.ravel()
    yy = yy.ravel()

    if _SHAPELY2:
        geoms = shapely.box(xx, yy, xx + cell_deg, yy + cell_deg)
    else:  # pragma: no cover
        geoms = np.array(
            [_box_scalar(a, b, a + cell_deg, b + cell_deg) for a, b in zip(xx, yy)],
            dtype=object,
        )

    boundary_union = unary_union(boundary_buf.geometry.values)

    if _SHAPELY2 and STRtree is not None:
        tree = STRtree(geoms)
        keep = tree.query(boundary_union, predicate="intersects")
        keep = np.sort(keep)
    else:  # pragma: no cover
        keep = np.array(
            [i for i, g in enumerate(geoms) if g.intersects(boundary_union)]
        )

    gdf = gpd.GeoDataFrame(
        {
            "x": col_idx[keep],
            "y": row_idx[keep],
            "cx": xx[keep] + cell_deg / 2,
            "cy": yy[keep] + cell_deg / 2,
        },
        geometry=list(np.asarray(geoms, dtype=object)[keep]),
        crs="EPSG:4326",
    )
    return gdf.reset_index(drop=True)


def install(module) -> None:
    """Monkeypatch `module.generate_ghs_grid` with the fast implementation."""
    module.generate_ghs_grid = generate_ghs_grid_fast


def verify_against_reference(boundary, buffer_m: float = 3000.0) -> dict:
    """
    Run both the original and fast implementations on the same boundary and
    report whether they agree. Returns a dict of comparison results.
    """
    import quality_accessibility_osmium as qa

    ref = qa.generate_ghs_grid.__wrapped__ if hasattr(
        qa.generate_ghs_grid, "__wrapped__"
    ) else qa.generate_ghs_grid

    a = ref(boundary, buffer_m=buffer_m)
    b = generate_ghs_grid_fast(boundary, buffer_m=buffer_m)

    same_len = len(a) == len(b)
    key_a = set(zip(a["x"], a["y"]))
    key_b = set(zip(b["x"], b["y"]))
    return {
        "n_reference": len(a),
        "n_fast": len(b),
        "same_length": same_len,
        "same_cell_set": key_a == key_b,
        "only_in_reference": len(key_a - key_b),
        "only_in_fast": len(key_b - key_a),
    }
