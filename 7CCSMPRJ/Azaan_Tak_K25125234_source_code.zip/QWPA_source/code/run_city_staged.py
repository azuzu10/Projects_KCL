#!/usr/bin/env python3
"""
Staged, resumable wrapper around quality_accessibility_osmium.run().

The monolithic script runs a city in one go, which was fine for Amsterdam and
painful for Spain (1.4 GB): if the run dies at the distance matrix, the hours of
PBF parsing die with it. So this splits the pipeline into seven stages, each
writing its result to a cache directory -- boundary, parks, grid, overlap,
cell scores, distances, indices. A re-run skips whatever is already cached and
picks up at the first incomplete stage.

    python run_city_staged.py <city> <extract.osm.pbf> [--out-dir DIR]
        [--cache-dir DIR] [--chunk-origins N] [--slow-grid] [--slow-dist]
        [--no-lowmem-index] [--no-targeted-parks]

--chunk-origins bounds peak memory during the distance stage. The --slow-* and
--no-* flags fall back to the original implementations if you distrust the fast
paths (each fast path was verified against its original before being made the
default; the comments below say how).
"""

from __future__ import annotations

import argparse
import os
import sys
import time
import traceback

import pandas as pd
import geopandas as gpd

# Make the sibling pipeline module importable regardless of cwd
_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import quality_accessibility_osmium as qa  # noqa: E402

# Vectorised grid generation (verified to produce byte-identical output to the
# original nested-loop implementation; ~10x faster). Opt out with --slow-grid.
try:
    import fast_grid  # noqa: E402
    _HAVE_FAST_GRID = True
except ImportError:  # pragma: no cover
    _HAVE_FAST_GRID = False

# KD-tree distance matrix (verified bit-exact against the reference on Amsterdam:
# 9,072,560 OD pairs, identical pair set and distances). Opt out with --slow-dist.
try:
    import fast_distance  # noqa: E402
    _HAVE_FAST_DIST = True
except ImportError:  # pragma: no cover
    _HAVE_FAST_DIST = False

# Disk-backed node-location index for province/country-sized extracts. Swaps the
# index backend only; locations and geometry are unchanged. Opt out with
# --no-lowmem-index.
try:
    import lowmem_index  # noqa: E402
    _HAVE_LOWMEM = True
except ImportError:  # pragma: no cover
    _HAVE_LOWMEM = False

# Targeted park extraction: resolves coordinates only for the known target park
# ways instead of indexing every node in the file. Verified to produce identical
# parks to qa.extract_parks() on Amsterdam (106) and Melbourne (1,787) --
# same ID sets, geometries equal, identical total area. Opt out with
# --no-targeted-parks.
try:
    import targeted_parks  # noqa: E402
    _HAVE_TARGETED_PARKS = True
except ImportError:  # pragma: no cover
    _HAVE_TARGETED_PARKS = False

STAGE_NAMES = {
    1: "boundary",
    2: "parks",
    3: "grid",
    4: "overlap",
    5: "cell_scores",
    6: "distances",
    7: "indices",
}


# --- cache helpers

def _p(cache_dir: str, city: str, name: str, ext: str) -> str:
    return os.path.join(cache_dir, f"{city}_{name}.{ext}")


def _have(path: str) -> bool:
    return os.path.exists(path) and os.path.getsize(path) > 0


def _read_parquet_or_csv(path: str) -> pd.DataFrame:
    if path.endswith(".parquet"):
        try:
            return pd.read_parquet(path)
        except Exception:
            alt = path[: -len(".parquet")] + ".csv"
            if _have(alt):
                return pd.read_csv(alt)
            raise
    return pd.read_csv(path)


def _write_parquet_or_csv(df: pd.DataFrame, path: str) -> str:
    """Prefer parquet; fall back to CSV when no parquet engine is installed."""
    try:
        df.to_parquet(path, index=False)
        return path
    except Exception:
        alt = path[: -len(".parquet")] + ".csv" if path.endswith(".parquet") else path
        df.to_csv(alt, index=False)
        return alt


def _resolve_data_paths(project_root: str) -> tuple[str, str]:
    """Locate the Dietz scores/fingerprints CSVs, tolerating the nested layout."""
    candidates = [
        os.path.join(project_root, "Health-Promoting-Parks-Replication-main", "data"),
        os.path.join(
            project_root,
            "Health-Promoting-Parks-Replication-main",
            "Health-Promoting-Parks-Replication-main",
            "data",
        ),
    ]
    for d in candidates:
        s = os.path.join(d, "scores_cities.csv")
        f = os.path.join(d, "fingerprints_cities.csv")
        if _have(s) and _have(f):
            return s, f
    raise FileNotFoundError(
        "Could not locate scores_cities.csv / fingerprints_cities.csv under:\n  "
        + "\n  ".join(candidates)
    )


# --- the staged pipeline

def run_staged(
    city: str,
    pbf_path: str,
    out_dir: str = "output_figures",
    cache_dir: str = ".pipeline_cache",
    project_root: str | None = None,
    max_stage: int = 7,
    force: bool = False,
    fast_grid_enabled: bool = True,
    fast_dist_enabled: bool = True,
    lowmem_index_enabled: bool = True,
    targeted_parks_enabled: bool = True,
    chunk_origins: int = 0,
    buffer_m: float = 3000.0,
    qwe_threshold_min: float = 15.0,
    gma_tau: float = 10.0,
    qamd_q: float = 0.0,
) -> dict:
    if city not in qa.CITY_OSM_RELATIONS:
        raise ValueError(
            f"Unknown city '{city}'. Known: {sorted(qa.CITY_OSM_RELATIONS)}"
        )
    # The PBF is only read by stages 1-2. If both are already cached the extract
    # is not needed at all, so it can be deleted from the server after the first
    # pass to reclaim disk. Only insist on it when it will actually be opened.
    _b_cached = _have(_p(cache_dir, city, "boundary", "geojson"))
    _p_cached = _have(_p(cache_dir, city, "parks", "geojson"))
    _needs_pbf = (not force) and (not (_b_cached and _p_cached))
    if force or _needs_pbf:
        if not pbf_path or not _have(pbf_path):
            raise FileNotFoundError(
                f"PBF not found: {pbf_path!r}\n"
                f"(needed because stage 1/2 are not cached in {cache_dir})"
            )

    if fast_grid_enabled and _HAVE_FAST_GRID:
        fast_grid.install(qa)
    if fast_dist_enabled and _HAVE_FAST_DIST:
        fast_distance.install(qa)
    if lowmem_index_enabled and _HAVE_LOWMEM:
        # auto=True: only extracts >= 500 MB get the slower disk-backed index,
        # so city-sized files keep the faster in-memory one.
        lowmem_index.install(auto=True)

    project_root = project_root or os.getcwd()
    os.makedirs(cache_dir, exist_ok=True)
    os.makedirs(out_dir, exist_ok=True)
    if targeted_parks_enabled and _HAVE_TARGETED_PARKS:
        targeted_parks.install(qa)
        # Cache each PBF scan so an interrupted extraction resumes at the next
        # pass rather than rescanning a multi-GB file from the start.
        targeted_parks.set_cache(os.path.join(cache_dir, f"{city}_tp"))

    scores_path, fingerprints_path = _resolve_data_paths(project_root)

    relation_id = qa.CITY_OSM_RELATIONS[city]
    print(f"\n{'='*64}")
    print(f"  City      : {city}  (OSM relation {relation_id})")
    _pbf_desc = pbf_path if _needs_pbf else "(cached, not needed)"
    print(f"  PBF       : {_pbf_desc}")
    print(f"  Cache     : {cache_dir}")
    print(f"  Max stage : {max_stage} ({STAGE_NAMES.get(max_stage, '?')})")
    print(f"{'='*64}\n")

    t_all = time.time()
    state: dict = {}

    def stage(n: int) -> bool:
        """True if stage n should run now."""
        return n <= max_stage

    # ---- Stage 1: city boundary --------------------------------------------
    f_boundary = _p(cache_dir, city, "boundary", "geojson")
    if stage(1):
        if _have(f_boundary) and not force:
            print("[1/7] boundary      CACHED")
        else:
            t = time.time()
            print("[1/7] boundary      extracting from PBF ...", flush=True)
            boundary = qa.extract_city_boundary(pbf_path, relation_id)
            boundary.to_file(f_boundary, driver="GeoJSON")
            print(f"      done in {time.time()-t:.1f}s -> {f_boundary}")

    # ---- Stage 2: park geometries ------------------------------------------
    f_parks = _p(cache_dir, city, "parks", "geojson")
    if stage(2):
        if _have(f_parks) and not force:
            print("[2/7] parks         CACHED")
        else:
            t = time.time()
            fp = pd.read_csv(fingerprints_path)
            target_ids = fp.loc[fp["city"] == city, "osm_id"].tolist()
            print(
                f"[2/7] parks         {len(target_ids)} target IDs; parsing PBF ...",
                flush=True,
            )
            parks = qa.extract_parks(pbf_path, target_osm_ids=target_ids)
            parks.to_file(f_parks, driver="GeoJSON")
            print(f"      {len(parks)} parks found, {time.time()-t:.1f}s -> {f_parks}")

    # ---- Stage 3: GHS grid --------------------------------------------------
    f_cells = _p(cache_dir, city, "cells", "parquet")
    f_cells_alt = _p(cache_dir, city, "cells", "csv")
    if stage(3):
        if (_have(f_cells) or _have(f_cells_alt)) and not force:
            print("[3/7] grid          CACHED")
        else:
            t = time.time()
            print("[3/7] grid          generating GHS-aligned cells ...", flush=True)
            boundary = gpd.read_file(f_boundary)
            cells = qa.generate_ghs_grid(boundary, buffer_m=buffer_m)
            # Persist geometry as WKT so it round-trips through parquet/csv
            cdf = pd.DataFrame(
                {
                    "x": cells["x"],
                    "y": cells["y"],
                    "cx": cells["cx"],
                    "cy": cells["cy"],
                    "geometry_wkt": cells.geometry.to_wkt(),
                }
            )
            written = _write_parquet_or_csv(cdf, f_cells)
            print(f"      {len(cdf):,} cells, {time.time()-t:.1f}s -> {written}")

    def _load_cells() -> gpd.GeoDataFrame:
        path = f_cells if _have(f_cells) else f_cells_alt
        cdf = _read_parquet_or_csv(path)
        return gpd.GeoDataFrame(
            cdf.drop(columns=["geometry_wkt"]),
            geometry=gpd.GeoSeries.from_wkt(cdf["geometry_wkt"]),
            crs="EPSG:4326",
        )

    # ---- Stage 4: park-cell overlap ----------------------------------------
    f_overlap = _p(cache_dir, city, "overlap", "parquet")
    f_overlap_alt = _p(cache_dir, city, "overlap", "csv")
    if stage(4):
        if (_have(f_overlap) or _have(f_overlap_alt)) and not force:
            print("[4/7] overlap       CACHED")
        else:
            t = time.time()
            print("[4/7] overlap       intersecting parks with cells ...", flush=True)
            cells = _load_cells()
            parks = gpd.read_file(f_parks)
            # qa.park_cell_overlap() calls .intersection() on every park, which
            # raises GEOSException("side location conflict") on a self-touching
            # ring and aborts the whole city. The original already applies
            # buffer(0) to park *ways* (_ParkWayHandler); multipolygon relations
            # assembled by _assemble_polygon() skip that step, which is where the
            # invalid geometry comes from. Apply the same repair, but only to
            # geometries that actually fail is_valid, so cities with clean data
            # are untouched.
            invalid = ~parks.geometry.is_valid
            n_invalid = int(invalid.sum())
            if n_invalid:
                bad_ids = parks.loc[invalid, "osm_id"].tolist()
                parks.loc[invalid, "geometry"] = parks.loc[invalid, "geometry"].buffer(0)
                still = int((~parks.geometry.is_valid).sum())
                print(f"      repaired {n_invalid} invalid park geometry/ies "
                      f"with buffer(0) (osm_id {bad_ids[:5]}); "
                      f"{still} still invalid")
            overlap = qa.park_cell_overlap(cells, parks)
            written = _write_parquet_or_csv(overlap, f_overlap)
            print(f"      {len(overlap):,} pairs, {time.time()-t:.1f}s -> {written}")

    # ---- Stage 5: cell-level quality scores --------------------------------
    f_cs = _p(cache_dir, city, "cell_scores", "parquet")
    f_cs_alt = _p(cache_dir, city, "cell_scores", "csv")
    if stage(5):
        if (_have(f_cs) or _have(f_cs_alt)) and not force:
            print("[5/7] cell_scores   CACHED")
        else:
            t = time.time()
            print("[5/7] cell_scores   area-weighted score assignment ...", flush=True)
            overlap = _read_parquet_or_csv(
                f_overlap if _have(f_overlap) else f_overlap_alt
            )
            scores = qa.load_park_scores(scores_path)
            cell_scores = qa.assign_cell_scores(overlap, scores, city)
            cell_scores = cell_scores.merge(
                overlap.groupby(["x", "y"])["overlap_ha"].sum().reset_index(),
                on=["x", "y"],
                how="left",
            )
            written = _write_parquet_or_csv(cell_scores, f_cs)
            print(
                f"      {len(cell_scores):,} green cells, "
                f"{time.time()-t:.1f}s -> {written}"
            )

    # ---- Stages 6 & 7: distances + indices ---------------------------------
    #
    # All four indices aggregate strictly per origin cell (x_source, y_source):
    #   QWE  = sum over reachable destinations
    #   QAMD = min  over qualifying destinations
    #   GMA  = sum  of distance-decayed contributions
    #   BEST = max  score reachable within each threshold
    # Partitioning the ORIGIN cells and concatenating the per-partition results
    # is therefore exact -- no origin's rows are ever split across partitions.
    # This keeps peak memory proportional to the chunk size rather than to the
    # full OD matrix, which for a metro-scale boundary runs to 10^8 rows.
    f_dist = _p(cache_dir, city, "dist", "parquet")
    f_dist_alt = _p(cache_dir, city, "dist", "csv")

    if stage(6) or stage(7):
        cells = _load_cells()
        overlap = _read_parquet_or_csv(
            f_overlap if _have(f_overlap) else f_overlap_alt
        )
        cell_scores = _read_parquet_or_csv(f_cs if _have(f_cs) else f_cs_alt)

        n_cells = len(cells)
        use_chunks = chunk_origins and chunk_origins < n_cells

        if not use_chunks:
            # -- single-shot path (small cities) ------------------------------
            if stage(6):
                if (_have(f_dist) or _have(f_dist_alt)) and not force:
                    print("[6/7] distances     CACHED")
                else:
                    t = time.time()
                    print("[6/7] distances     haversine matrix ...", flush=True)
                    dist_df = qa.build_distance_df(cells, overlap)
                    written = _write_parquet_or_csv(dist_df, f_dist)
                    print(
                        f"      {len(dist_df):,} OD pairs, "
                        f"{time.time()-t:.1f}s -> {written}"
                    )
            if not stage(7):
                print(f"\nTotal elapsed: {time.time()-t_all:.1f}s")
                return state

            t = time.time()
            print("[7/7] indices       QWE / QAMD / GMA / BEST ...", flush=True)
            dist_df = _read_parquet_or_csv(f_dist if _have(f_dist) else f_dist_alt)
            qwe = qa.quality_weighted_exposure(
                dist_df, cell_scores, threshold_min=qwe_threshold_min
            )
            qamd = qa.quality_adjusted_min_distance(dist_df, cell_scores, q=qamd_q)
            gma = qa.gravity_accessibility(dist_df, cell_scores, tau=gma_tau)
            best = qa.best_reachable_score(
                dist_df, cell_scores, thresholds_min=[5.0, 15.0, 30.0]
            )
            del dist_df
        else:
            # -- chunked path (metro-scale boundaries) ------------------------
            if not stage(7):
                print(
                    f"[6/7] distances     chunked mode: distances are computed "
                    f"together with indices in stage 7; nothing to do."
                )
                print(f"\nTotal elapsed: {time.time()-t_all:.1f}s")
                return state

            import numpy as np  # noqa: F401  (used by the --slow-dist fallback too)

            n_chunks = int(np.ceil(n_cells / chunk_origins))
            print(
                f"[6+7] chunked       {n_cells:,} origins in {n_chunks} chunks "
                f"of {chunk_origins:,}",
                flush=True,
            )
            chunk_dir = os.path.join(cache_dir, f"{city}_chunks")
            os.makedirs(chunk_dir, exist_ok=True)

            # Cached chunks are only valid for the exact partition that produced
            # them. If the chunk size or the grid size changed, chunk_0003 no
            # longer covers the same origins and blindly reusing it would splice
            # together overlapping/missing origin sets -- silently wrong output.
            # Record the partition and invalidate the cache when it differs.
            manifest = os.path.join(chunk_dir, "_partition.txt")
            sig = f"chunk_origins={chunk_origins}\nn_cells={n_cells}\n"
            old_sig = None
            if os.path.exists(manifest):
                with open(manifest, encoding="utf-8") as fh:
                    old_sig = fh.read()
            if old_sig is not None and old_sig != sig:
                stale = [f for f in os.listdir(chunk_dir) if f.endswith(".parquet")]
                print(
                    f"      partition changed since last run "
                    f"({old_sig.strip().replace(chr(10), ', ')} -> "
                    f"{sig.strip().replace(chr(10), ', ')}); "
                    f"discarding {len(stale)} stale chunk file(s)"
                )
                for f in stale:
                    os.remove(os.path.join(chunk_dir, f))
            with open(manifest, "w", encoding="utf-8") as fh:
                fh.write(sig)

            names = ["qwe", "qamd", "gma", "best"]
            for ci in range(n_chunks):
                done = all(
                    _have(os.path.join(chunk_dir, f"{n}_{ci:04d}.parquet"))
                    for n in names
                )
                if done and not force:
                    print(f"      chunk {ci+1}/{n_chunks}  CACHED")
                    continue

                t = time.time()
                lo, hi = ci * chunk_origins, min((ci + 1) * chunk_origins, n_cells)
                mask = np.zeros(n_cells, dtype=bool)
                mask[lo:hi] = True

                if _HAVE_FAST_DIST and fast_dist_enabled:
                    d = fast_distance.build_distance_df_fast(
                        cells, overlap, origin_mask=mask, verbose=False
                    )
                else:  # pragma: no cover
                    # qa.build_distance_df() derives its DESTINATIONS from the
                    # same frame it takes origins from:
                    #     dests = cells.merge(green_xys, how="inner")
                    # so passing only the chunk's origins would silently shrink
                    # the destination set to the green cells inside that chunk
                    # and under-count every index. Pass the chunk's origins
                    # UNION every green cell (preserving grid order), then drop
                    # the extra origin rows afterwards.
                    green_keys = set(
                        map(tuple, overlap[["x", "y"]].drop_duplicates().values)
                    )
                    keep = mask | np.array(
                        [(a, b) in green_keys
                         for a, b in zip(cells["x"].values, cells["y"].values)]
                    )
                    d = qa.build_distance_df(cells.loc[keep], overlap)
                    chunk_keys = set(
                        map(tuple, cells.loc[mask, ["x", "y"]].values)
                    )
                    d = d[
                        [
                            (a, b) in chunk_keys
                            for a, b in zip(d["x_source"].values, d["y_source"].values)
                        ]
                    ].reset_index(drop=True)

                if len(d) == 0:
                    empty = pd.DataFrame(columns=["x_source", "y_source"])
                    for n in names:
                        empty.to_parquet(
                            os.path.join(chunk_dir, f"{n}_{ci:04d}.parquet"),
                            index=False,
                        )
                    print(f"      chunk {ci+1}/{n_chunks}  no pairs")
                    continue

                parts = {
                    "qwe": qa.quality_weighted_exposure(
                        d, cell_scores, threshold_min=qwe_threshold_min
                    ),
                    "qamd": qa.quality_adjusted_min_distance(
                        d, cell_scores, q=qamd_q
                    ),
                    "gma": qa.gravity_accessibility(d, cell_scores, tau=gma_tau),
                    "best": qa.best_reachable_score(
                        d, cell_scores, thresholds_min=[5.0, 15.0, 30.0]
                    ),
                }
                for n, df_part in parts.items():
                    df_part.to_parquet(
                        os.path.join(chunk_dir, f"{n}_{ci:04d}.parquet"), index=False
                    )
                print(
                    f"      chunk {ci+1}/{n_chunks}  {len(d):,} pairs, "
                    f"{time.time()-t:.1f}s",
                    flush=True,
                )
                del d, parts

            print("      concatenating chunk results ...", flush=True)

            def _concat(name: str) -> pd.DataFrame:
                files = sorted(
                    os.path.join(chunk_dir, f)
                    for f in os.listdir(chunk_dir)
                    if f.startswith(f"{name}_") and f.endswith(".parquet")
                )
                frames = [pd.read_parquet(f) for f in files]
                frames = [f for f in frames if len(f)]
                if not frames:
                    return pd.DataFrame(columns=["x_source", "y_source"])
                out = pd.concat(frames, ignore_index=True)
                # qa.quality_adjusted_min_distance() skips dimensions with no
                # qualifying destinations and outer-merges the rest in encounter
                # order, so the column order depends on which chunk ran first.
                # Values are unaffected, but pin a canonical order so repeated
                # runs (and different chunk sizes) produce identical CSVs.
                lead = [c for c in ("x_source", "y_source") if c in out.columns]
                rest = sorted(c for c in out.columns if c not in lead)
                return out[lead + rest].sort_values(lead).reset_index(drop=True)

            qwe, qamd = _concat("qwe"), _concat("qamd")
            gma, best = _concat("gma"), _concat("best")
            t = time.time()

        qwe.to_csv(os.path.join(out_dir, f"qwe_{city}.csv"), index=False)
        qamd.to_csv(os.path.join(out_dir, f"qamd_{city}.csv"), index=False)
        gma.to_csv(os.path.join(out_dir, f"gma_{city}.csv"), index=False)
        best.to_csv(os.path.join(out_dir, f"best_{city}.csv"), index=False)
        cell_scores.to_csv(
            os.path.join(out_dir, f"cell_scores_{city}.csv"), index=False
        )
        overlap.to_csv(os.path.join(out_dir, f"overlap_{city}.csv"), index=False)
        cells[["x", "y", "cx", "cy"]].to_csv(
            os.path.join(out_dir, f"cells_{city}.csv"), index=False
        )
        try:
            gpd.read_file(f_parks).to_file(
                os.path.join(out_dir, f"parks_{city}.geojson"), driver="GeoJSON"
            )
        except Exception as exc:
            print(f"      WARNING: could not write parks GeoJSON: {exc}")

        # Record how many cells the grid held, for coverage percentages later
        meta = pd.DataFrame(
            [{"city": city, "n_cells": len(cells), "n_green_cells": len(cell_scores)}]
        )
        meta.to_csv(os.path.join(out_dir, f"meta_{city}.csv"), index=False)

        print(
            f"      QWE {len(qwe):,} | QAMD {len(qamd):,} | GMA {len(gma):,} | "
            f"BEST {len(best):,}  ({time.time()-t:.1f}s)"
        )
        state = {
            "qwe": qwe, "qamd": qamd, "gma": gma, "best": best,
            "cell_scores": cell_scores, "cells": cells,
        }

    print(f"\nTotal elapsed: {time.time()-t_all:.1f}s")
    return state


def print_status(city: str, cache_dir: str, out_dir: str) -> None:
    print(f"\nStage status for '{city}':")
    checks = [
        (1, "boundary", [_p(cache_dir, city, "boundary", "geojson")]),
        (2, "parks", [_p(cache_dir, city, "parks", "geojson")]),
        (3, "grid", [_p(cache_dir, city, "cells", "parquet"),
                     _p(cache_dir, city, "cells", "csv")]),
        (4, "overlap", [_p(cache_dir, city, "overlap", "parquet"),
                        _p(cache_dir, city, "overlap", "csv")]),
        (5, "cell_scores", [_p(cache_dir, city, "cell_scores", "parquet"),
                            _p(cache_dir, city, "cell_scores", "csv")]),
        (6, "distances", [_p(cache_dir, city, "dist", "parquet"),
                          _p(cache_dir, city, "dist", "csv")]),
        (7, "indices", [os.path.join(out_dir, f"qwe_{city}.csv")]),
    ]
    for n, name, paths in checks:
        hit = next((p for p in paths if _have(p)), None)
        if hit:
            print(f"  [{n}] {name:12} DONE  ({os.path.getsize(hit)/1e6:.1f} MB)")
        else:
            print(f"  [{n}] {name:12} --")
    print()


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("city")
    ap.add_argument("pbf", nargs="?", default=None)
    ap.add_argument("--out-dir", default="output_figures")
    ap.add_argument("--cache-dir", default=".pipeline_cache")
    ap.add_argument("--project-root", default=None)
    ap.add_argument("--max-stage", type=int, default=7)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--status", action="store_true")
    ap.add_argument("--slow-grid", action="store_true",
                    help="use the original nested-loop grid builder")
    ap.add_argument("--slow-dist", action="store_true",
                    help="use the original O(origins x dests) distance builder")
    ap.add_argument("--no-lowmem-index", action="store_true",
                    help="keep osmium's in-memory flex_mem node index even for "
                         "large extracts (faster, but needs much more RAM)")
    ap.add_argument("--no-targeted-parks", action="store_true",
                    help="use the original extract_parks (needs a full node index)")
    ap.add_argument("--chunk-origins", type=int, default=0, metavar="N",
                    help="process origins in chunks of N to bound memory "
                         "(recommended: 200000 for metro-scale boundaries)")
    args = ap.parse_args()

    if args.status:
        print_status(args.city, args.cache_dir, args.out_dir)
        return 0

    # A missing pbf argument is fine when stages 1-2 are already cached;
    # run_staged() raises a clear error if the extract is actually needed.

    try:
        run_staged(
            city=args.city,
            pbf_path=args.pbf,
            out_dir=args.out_dir,
            cache_dir=args.cache_dir,
            project_root=args.project_root,
            max_stage=args.max_stage,
            force=args.force,
            fast_grid_enabled=not args.slow_grid,
            fast_dist_enabled=not args.slow_dist,
            lowmem_index_enabled=not args.no_lowmem_index,
            targeted_parks_enabled=not args.no_targeted_parks,
            chunk_origins=args.chunk_origins,
        )
    except MemoryError:
        print("\nFAILED: out of memory.", file=sys.stderr)
        print(
            "Re-run with a smaller --buffer or on a machine with more RAM; "
            "completed stages are cached and will be skipped.",
            file=sys.stderr,
        )
        return 2
    except Exception:
        traceback.print_exc()
        print("\nFAILED -- completed stages remain cached; re-run to resume.",
              file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
