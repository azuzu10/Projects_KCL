#!/usr/bin/env python3
"""
Cross-city comparison figures, from the per-city pipeline outputs in --out-dir.

Writes crosscity_coverage.png (QWE/GMA/QAMD-15 coverage per city),
crosscity_qamd_15min.png (city x dimension heatmap), crosscity_qwe_mean.png,
crosscity_dimension_gap.png (best minus worst dimension per city), and
crosscity_summary.csv (one tidy row per city x index x dimension).

Coverage is always a percentage of the city's own grid, read from
meta_<city>.csv. Raw cell counts are not comparable across cities -- the grid
scales with the administrative boundary, and Amsterdam's ~93k cells against
Greater Melbourne's ~1.6M is a fact about boundaries, not parks. (That
observation grew into Section 6.1 of the report.)

    python3 crosscity_compare.py --out-dir output_multi [--cities ...]
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

DIMS = ["cultural", "environmental", "nature", "physical", "social"]
DIM_COLORS = ["#e74c3c", "#2ecc71", "#27ae60", "#3498db", "#9b59b6"]


def load_csv(out_dir: str, name: str, city: str) -> pd.DataFrame | None:
    p = os.path.join(out_dir, f"{name}_{city}.csv")
    return pd.read_csv(p) if os.path.exists(p) else None


def city_label(c: str) -> str:
    return c.replace("_", " ").title()


def collect(out_dir: str, cities: list[str]) -> pd.DataFrame:
    """One tidy row per city x index x dimension."""
    rows = []
    for city in cities:
        meta = load_csv(out_dir, "meta", city)
        cells = load_csv(out_dir, "cells", city)
        if meta is not None and "n_cells" in meta.columns and len(meta):
            total = int(meta["n_cells"].iloc[0])
        elif cells is not None:
            total = len(cells)
        else:
            print(f"  {city}: no meta/cells file, skipping", file=sys.stderr)
            continue

        qwe = load_csv(out_dir, "qwe", city)
        qamd = load_csv(out_dir, "qamd", city)
        gma = load_csv(out_dir, "gma", city)

        for d in DIMS:
            row = {"city": city, "dimension": d, "n_cells": total}
            if qwe is not None and f"QWE_{d}" in qwe.columns:
                v = qwe[f"QWE_{d}"].dropna()
                row["qwe_cells"] = int((v > 0).sum())
                row["qwe_pct"] = 100 * row["qwe_cells"] / total
                row["qwe_mean"] = v[v > 0].mean() if (v > 0).any() else np.nan
            if qamd is not None and f"QAMD_{d}" in qamd.columns:
                v = qamd[f"QAMD_{d}"].dropna()
                row["qamd_cells"] = len(v)
                row["qamd_pct"] = 100 * len(v) / total
                row["qamd_15min_pct_of_reached"] = (
                    100 * (v <= 15).sum() / len(v) if len(v) else np.nan
                )
                row["qamd_15min_pct_of_all"] = 100 * (v <= 15).sum() / total
                row["qamd_median_min"] = v.median() if len(v) else np.nan
            if gma is not None and f"GMA_{d}" in gma.columns:
                v = gma[f"GMA_{d}"].dropna()
                row["gma_cells"] = int((v > 0).sum())
                row["gma_pct"] = 100 * row["gma_cells"] / total
            rows.append(row)
    return pd.DataFrame(rows)


# --- figures

def fig_coverage(df: pd.DataFrame, out_dir: str) -> None:
    agg = (df.groupby("city")
             .agg(qwe=("qwe_pct", "max"), gma=("gma_pct", "max"),
                  qamd15=("qamd_15min_pct_of_all", "mean"))
             .sort_values("qwe", ascending=True))
    if agg.empty:
        return
    y = np.arange(len(agg))
    h = 0.26
    fig, ax = plt.subplots(figsize=(10, max(4, 0.45 * len(agg) + 2)))
    ax.barh(y - h, agg["gma"], h, label="GMA > 0 (any dim)", color="#34495e")
    ax.barh(y, agg["qwe"], h, label="QWE > 0 (any dim)", color="#2980b9")
    ax.barh(y + h, agg["qamd15"], h,
            label="QAMD < 15 min (mean of dims)", color="#27ae60")
    ax.set_yticks(y)
    ax.set_yticklabels([city_label(c) for c in agg.index])
    ax.set_xlabel("% of the city's own grid cells")
    ax.set_title("Accessibility coverage by city", fontweight="bold")
    ax.grid(axis="x", alpha=0.3)
    ax.legend(fontsize=8)
    plt.tight_layout()
    p = os.path.join(out_dir, "crosscity_coverage.png")
    fig.savefig(p, dpi=150)
    plt.close(fig)
    print(f"  saved {os.path.basename(p)}")


def _heatmap(df, value, title, cbar_label, fname, out_dir, cmap="RdYlGn"):
    piv = df.pivot(index="city", columns="dimension", values=value)
    piv = piv.reindex(columns=DIMS)
    if piv.empty or piv.isna().all().all():
        return
    piv = piv.loc[piv.mean(axis=1).sort_values(ascending=False).index]

    fig, ax = plt.subplots(figsize=(8, max(3.5, 0.45 * len(piv) + 1.8)))
    im = ax.imshow(piv.values, cmap=cmap, aspect="auto")
    ax.set_xticks(range(len(DIMS)))
    ax.set_xticklabels([d.capitalize() for d in DIMS], rotation=30, ha="right")
    ax.set_yticks(range(len(piv)))
    ax.set_yticklabels([city_label(c) for c in piv.index])
    for i in range(piv.shape[0]):
        for j in range(piv.shape[1]):
            v = piv.values[i, j]
            if not np.isnan(v):
                ax.text(j, i, f"{v:.0f}", ha="center", va="center", fontsize=8,
                        color="black")
    ax.set_title(title, fontweight="bold")
    fig.colorbar(im, ax=ax, label=cbar_label, shrink=0.8)
    plt.tight_layout()
    p = os.path.join(out_dir, fname)
    fig.savefig(p, dpi=150)
    plt.close(fig)
    print(f"  saved {os.path.basename(p)}")


def fig_dimension_gap(df: pd.DataFrame, out_dir: str) -> None:
    """How unevenly served are a city's five dimensions?"""
    piv = df.pivot(index="city", columns="dimension",
                   values="qamd_15min_pct_of_all").reindex(columns=DIMS)
    if piv.empty or piv.isna().all().all():
        return
    gap = (piv.max(axis=1) - piv.min(axis=1)).sort_values()
    best = piv.idxmax(axis=1)
    worst = piv.idxmin(axis=1)

    fig, ax = plt.subplots(figsize=(9, max(4, 0.4 * len(gap) + 2)))
    ax.barh([city_label(c) for c in gap.index], gap.values, color="#8e44ad",
            alpha=0.85)
    for i, c in enumerate(gap.index):
        ax.text(gap.values[i] + 0.3, i,
                f"best {best[c][:4]} / worst {worst[c][:4]}",
                va="center", fontsize=7, color="grey")
    ax.set_xlabel("Percentage-point gap, best-served minus worst-served dimension")
    ax.set_title("Within-city inequality across the five dimensions\n"
                 "(QAMD reachable within 15 min, % of all cells)",
                 fontweight="bold", fontsize=11)
    ax.grid(axis="x", alpha=0.3)
    # Leave room for the "best X / worst Y" annotations, which sit to the right
    # of each bar and would otherwise be clipped by the axes edge.
    ax.set_xlim(0, gap.max() * 1.55 if gap.max() > 0 else 1)
    plt.tight_layout()
    p = os.path.join(out_dir, "crosscity_dimension_gap.png")
    fig.savefig(p, dpi=150)
    plt.close(fig)
    print(f"  saved {os.path.basename(p)}")


def discover_cities(out_dir: str) -> list[str]:
    return sorted(f[4:-4] for f in os.listdir(out_dir)
                  if f.startswith("qwe_") and f.endswith(".csv"))


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out-dir", default="output_multi")
    ap.add_argument("--cities", nargs="+", metavar="CITY")
    args = ap.parse_args()

    if not os.path.isdir(args.out_dir):
        print(f"ERROR: no such directory {args.out_dir}", file=sys.stderr)
        return 1

    cities = args.cities or discover_cities(args.out_dir)
    if not cities:
        print(f"No pipeline output in {args.out_dir}", file=sys.stderr)
        return 1

    print(f"Comparing {len(cities)} cities: {', '.join(cities)}\n")
    df = collect(args.out_dir, cities)
    if df.empty:
        print("Nothing to compare.", file=sys.stderr)
        return 1

    csv_path = os.path.join(args.out_dir, "crosscity_summary.csv")
    df.round(3).to_csv(csv_path, index=False)
    print(f"  saved {os.path.basename(csv_path)}")

    if df["city"].nunique() < 2:
        print("\nOnly one city present - comparison figures need at least two.")
        print("Run more cities, then re-run this script.")
        return 0

    fig_coverage(df, args.out_dir)
    _heatmap(df, "qamd_15min_pct_of_all",
             "Cells reaching an above-average park within 15 min",
             "% of all cells", "crosscity_qamd_15min.png", args.out_dir)
    _heatmap(df, "qwe_mean", "Mean Quality-Weighted Exposure (cells with QWE > 0)",
             "mean QWE", "crosscity_qwe_mean.png", args.out_dir, cmap="viridis")
    fig_dimension_gap(df, args.out_dir)

    print("\nDone.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
