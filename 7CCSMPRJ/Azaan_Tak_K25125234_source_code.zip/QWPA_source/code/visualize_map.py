#!/usr/bin/env python3
"""
Interactive Leaflet maps of the per-cell index values -- one self-contained
HTML file per city, plus an index.html portal linking them all.

    python visualize_map.py [--out-dir DIR] [--cities CITY ...]

Needs numpy and pandas; geopandas only if a city's parks GeoJSON is missing
and has to be rebuilt.
"""

import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

# --- Constants

GHS_CELL_DEG = 3 / 3600  # 3 arc-seconds ≈ 0.000833°

DIMS = ["cultural", "environmental", "nature", "physical", "social"]
INDICES = ["qwe", "qamd", "gma"]

INDEX_LABELS = {
    "qwe":  "Quality-Weighted Exposure",
    "qamd": "Quality-Adjusted Min. Distance",
    "gma":  "Gravity Model Accessibility",
}
INDEX_SHORT = {"qwe": "QWE", "qamd": "QAMD", "gma": "GMA"}
DIM_LABELS = {
    "cultural":      "Cultural",
    "environmental": "Environmental",
    "nature":        "Nature",
    "physical":      "Physical",
    "social":        "Social",
}
DIM_ICONS = {
    "cultural": "&#127916;",
    "environmental": "&#127807;",
    "nature": "&#127794;",
    "physical": "&#127939;",
    "social": "&#129309;",
}

# Approximate city centres (lon, lat) — used to reconstruct cx/cy when cells CSV is missing
CITY_CENTERS = {
    "amsterdam":     ( 4.9041,  52.3676),
    "berlin":        (13.4050,  52.5200),
    "london":        (-0.1276,  51.5074),
    "paris":         ( 2.3522,  48.8566),
    "rome":          (12.4964,  41.9028),
    "madrid":        (-3.7038,  40.4168),
    "barcelona":     ( 2.1734,  41.3851),
    "vienna":        (16.3738,  48.2082),
    "brussels":      ( 4.3517,  50.8503),
    "athens":        (23.7275,  37.9838),
    "lisbon":        (-9.1393,  38.7223),
    "dubai":         (55.2708,  25.2048),
    "tokyo":         (139.6917, 35.6895),
    "singapore":     (103.8198,  1.3521),
    "sydney":        (151.2093, -33.8688),
    "melbourne":     (144.9631, -37.8136),
    "auckland":      (174.7633, -36.8485),
    "christchurch":  (172.6362, -43.5320),
    "new_york":      (-74.0060,  40.7128),
    "los_angeles":   (-118.2437, 34.0522),
    "san_francisco": (-122.4194, 37.7749),
    "san_diego":     (-117.1611, 32.7157),
    "chicago":       (-87.6298,  41.8781),
    "toronto":       (-79.3832,  43.6532),
    "vancouver":     (-123.1207, 49.2827),
    "montreal":      (-73.5673,  45.5017),
    "mexico_city":   (-99.1332,  19.4326),
    "sao_paulo":     (-46.6333, -23.5505),
    "bogota":        (-74.0721,   4.7110),
    "johannesburg":  (28.0473,  -26.2041),
    "nairobi":       (36.8219,   -1.2921),
    "cape_town":     (18.4241,  -33.9249),
    "beijing":       (116.4074,  39.9042),
    "shanghai":      (121.4737,  31.2304),
    "mumbai":        (72.8777,   19.0760),
}

CITY_DISPLAY = {k: k.replace("_", " ").title() for k in CITY_CENTERS}
CITY_DISPLAY.update({
    "new_york": "New York",
    "los_angeles": "Los Angeles",
    "san_francisco": "San Francisco",
    "san_diego": "San Diego",
    "sao_paulo": "São Paulo",
    "bogota": "Bogotá",
    "cape_town": "Cape Town",
    "mexico_city": "Mexico City",
})

# --- Data loading

def find_city_dir(output_dir: Path, city: str) -> Path | None:
    """Return directory holding city files (per-city subdir or flat output_dir)."""
    per_city = output_dir / city
    key_file = f"qwe_{city}.csv"
    if (per_city / key_file).exists():
        return per_city
    if (output_dir / key_file).exists():
        return output_dir
    # Try cell_scores as fallback key
    if (per_city / f"cell_scores_{city}.csv").exists():
        return per_city
    if (output_dir / f"cell_scores_{city}.csv").exists():
        return output_dir
    return None


def _infer_grid_origin(
    df: pd.DataFrame, x_col: str, y_col: str, center_lon: float, center_lat: float
) -> tuple[float, float]:
    """Infer GHS grid origin from index midpoint and known city centre."""
    x_mid = (df[x_col].min() + df[x_col].max()) / 2
    y_mid = (df[y_col].min() + df[y_col].max()) / 2
    raw_x = center_lon - (x_mid + 0.5) * GHS_CELL_DEG
    raw_y = center_lat - (y_mid + 0.5) * GHS_CELL_DEG
    x_origin = math.floor(raw_x / GHS_CELL_DEG) * GHS_CELL_DEG
    y_origin = math.floor(raw_y / GHS_CELL_DEG) * GHS_CELL_DEG
    return x_origin, y_origin


def load_coords(city_dir: Path, city: str, center_lon: float, center_lat: float) -> pd.DataFrame | None:
    """
    Load or reconstruct cell centroid coordinates (x, y, cx, cy).

    Strategy (in priority order):
      1. cells_{city}.csv  — written by updated pipeline, has exact coordinates
      2. Union of all index x,y pairs — covers all accessible cells
      3. cell_scores x,y only — fallback, may cover fewer cells
    """
    cells_path = city_dir / f"cells_{city}.csv"
    if cells_path.exists():
        df = pd.read_csv(cells_path)
        if {"x", "y", "cx", "cy"}.issubset(df.columns):
            return df[["x", "y", "cx", "cy"]]

    # Collect the union of (x, y) from all available index files — these cover
    # all cells for which any index value was computed (superset of cell_scores).
    xy_parts = []
    for idx in INDICES:
        p = city_dir / f"{idx}_{city}.csv"
        if p.exists():
            tmp = pd.read_csv(p, usecols=lambda c: c in ("x_source", "y_source", "x", "y"))
            tmp = tmp.rename(columns={"x_source": "x", "y_source": "y"})
            xy_parts.append(tmp[["x", "y"]])
    # Also include cell_scores in case it has unique cells not in any index
    cs_path = city_dir / f"cell_scores_{city}.csv"
    if cs_path.exists():
        tmp = pd.read_csv(cs_path, usecols=["x", "y"])
        xy_parts.append(tmp[["x", "y"]])

    if not xy_parts:
        return None

    all_xy = pd.concat(xy_parts, ignore_index=True).drop_duplicates()
    all_xy["x"] = all_xy["x"].astype(int)
    all_xy["y"] = all_xy["y"].astype(int)
    all_xy = all_xy.drop_duplicates().reset_index(drop=True)

    x_origin, y_origin = _infer_grid_origin(all_xy, "x", "y", center_lon, center_lat)
    all_xy["cx"] = x_origin + (all_xy["x"] + 0.5) * GHS_CELL_DEG
    all_xy["cy"] = y_origin + (all_xy["y"] + 0.5) * GHS_CELL_DEG
    return all_xy[["x", "y", "cx", "cy"]]


def load_index_df(city_dir: Path, city: str, idx: str) -> pd.DataFrame | None:
    """Load a QWE/QAMD/GMA/BEST CSV; normalise column names to x, y."""
    p = city_dir / f"{idx}_{city}.csv"
    if not p.exists():
        return None
    df = pd.read_csv(p)
    df = df.rename(columns={"x_source": "x", "y_source": "y"})
    df["x"] = df["x"].astype(int)
    df["y"] = df["y"].astype(int)
    return df


def load_city_data(output_dir: Path, city: str) -> dict | None:
    """Load all available result files for one city."""
    city_dir = find_city_dir(output_dir, city)
    if city_dir is None:
        return None

    center = CITY_CENTERS.get(city, (0.0, 0.0))
    coords = load_coords(city_dir, city, center[0], center[1])
    if coords is None or len(coords) == 0:
        print(f"  [{city}] No cell coordinates — skipping.")
        return None

    data: dict = {
        "city": city,
        "center": center,
        "coords": coords,
        "indices": {},
        "parks_json": "null",
    }

    for idx in INDICES:
        df = load_index_df(city_dir, city, idx)
        data["indices"][idx] = df

    # Parks GeoJSON (may not exist for older pipeline runs)
    parks_path = city_dir / f"parks_{city}.geojson"
    if parks_path.exists():
        data["parks_json"] = parks_path.read_text(encoding="utf-8")

    return data

# --- Cell data builder

def build_cell_json(data: dict) -> tuple[str, str, str]:
    """
    Build compact JSON strings for embedding in HTML.

    Returns:
        coords_json  — [[lon, lat], ...]  (one entry per cell, shared)
        values_json  — {idx: {dim: [value|null, ...]}, ...}
        stats_json   — {idx: {dim: {min,max,mean,p05,p95,pct_notnull}}, ...}
    """
    coords_df = data["coords"].reset_index(drop=True)
    # Round to 6 d.p. (sub-metre precision, saves JSON size)
    coord_list = [
        [round(float(row.cx), 6), round(float(row.cy), 6)]
        for row in coords_df.itertuples()
    ]
    n = len(coord_list)

    # Build (x, y) → position-in-array lookup using a merge approach
    coords_df = coords_df.copy()
    coords_df["_pos"] = range(n)

    values: dict = {}
    stats: dict = {}

    for idx in INDICES:
        df = data["indices"].get(idx)
        if df is None:
            continue

        values[idx] = {}
        stats[idx] = {}

        for dim in DIMS:
            col = f"{idx.upper()}_{dim}"
            if col not in (df.columns if df is not None else []):
                continue

            # Left-join coords order onto index values → preserves cell ordering
            merged = coords_df[["x", "y", "_pos"]].merge(
                df[["x", "y", col]], on=["x", "y"], how="left"
            ).sort_values("_pos")

            raw = merged[col].values.astype(float)   # NaN where no data
            valid = raw[~np.isnan(raw)]
            if len(valid) == 0:
                continue

            st = {
                "min":         round(float(np.nanmin(raw)),  6),
                "max":         round(float(np.nanmax(raw)),  6),
                "mean":        round(float(np.nanmean(raw)), 6),
                "p05":         round(float(np.nanpercentile(raw,  5)), 6),
                "p95":         round(float(np.nanpercentile(raw, 95)), 6),
                "pct_notnull": round(float(len(valid) / n * 100), 1),
            }
            stats[idx][dim] = st

            # Compact encoding: null for NaN, otherwise rounded float
            vals_enc = [
                None if np.isnan(v) else round(float(v), 6)
                for v in raw
            ]
            values[idx][dim] = vals_enc

    sep = (",", ":")          # compact separators
    return (
        json.dumps(coord_list, separators=sep),
        json.dumps(values,     separators=sep),
        json.dumps(stats,      separators=sep),
    )

# --- HTML templates

_CITY_MAP_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Park Accessibility &mdash; CITY_DISPLAY</title>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <style>
    *{margin:0;padding:0;box-sizing:border-box;}
    html,body{height:100%;overflow:hidden;font-family:'Segoe UI',system-ui,sans-serif;background:#f4f4f4;color:#222;}
    #app{display:flex;flex-direction:column;height:100%;}
    header{
      background:#00285c;color:white;padding:10px 20px;
      display:flex;align-items:center;gap:14px;flex-shrink:0;
      border-bottom:2px solid #7fb3ff;min-height:44px;
    }
    #back-link{color:#7fb3ff;text-decoration:none;font-size:13px;white-space:nowrap;}
    #back-link:hover{color:white;}
    #city-title{font-size:18px;font-weight:700;letter-spacing:0.01em;}
    #subtitle{font-size:11px;color:#a0c0e0;margin-left:auto;white-space:nowrap;}
    #main{display:flex;flex-direction:row;flex:1;min-height:0;}
    #sidebar{
      width:270px;min-width:270px;max-width:270px;background:white;
      border-right:1px solid #e4e4e4;overflow-y:auto;
      display:flex;flex-direction:column;flex-shrink:0;
    }
    .s-section{padding:12px 14px;border-bottom:1px solid #f0f0f0;}
    .s-section h3{
      font-size:10px;text-transform:uppercase;letter-spacing:0.1em;
      color:#999;margin-bottom:8px;font-weight:700;
    }
    /* Index buttons */
    .idx-btn{
      display:block;width:100%;padding:8px 10px;margin-bottom:5px;
      border:1.5px solid #ddd;border-radius:6px;cursor:pointer;
      background:white;text-align:left;font-size:12px;transition:all 0.12s;
    }
    .idx-btn:hover{background:#f0f5ff;border-color:#00285c;}
    .idx-btn.active{background:#00285c;color:white;border-color:#00285c;}
    .idx-btn .i-code{font-weight:700;font-size:13px;}
    .idx-btn .i-name{font-size:10px;opacity:0.75;margin-top:1px;}
    /* Dimension tabs */
    .dim-tabs{display:flex;flex-wrap:wrap;gap:4px;}
    .dim-tab{
      padding:4px 9px;border:1.5px solid #ddd;border-radius:20px;
      cursor:pointer;font-size:12px;background:white;transition:all 0.12s;
    }
    .dim-tab:hover{background:#f0f5ff;}
    .dim-tab.active{background:#00285c;color:white;border-color:#00285c;}
    /* Sliders & toggles */
    .ctrl-label{font-size:12px;color:#555;display:block;margin-bottom:4px;}
    #op-slider{width:100%;accent-color:#00285c;}
    .toggle-row{display:flex;align-items:center;gap:6px;font-size:12px;
                cursor:pointer;margin-top:8px;}
    /* Legend */
    #legend-canvas{width:100%;height:14px;border-radius:4px;display:block;margin:6px 0 3px;}
    #legend-labels{display:flex;justify-content:space-between;font-size:10px;color:#888;}
    #legend-note{font-size:10px;color:#bbb;margin-top:4px;}
    /* Stats */
    .stat-grid{display:grid;grid-template-columns:1fr 1fr;gap:5px;}
    .stat-cell{background:#f7f7f7;border-radius:5px;padding:6px 8px;}
    .stat-cell .sl{font-size:10px;color:#999;text-transform:uppercase;letter-spacing:0.05em;}
    .stat-cell .sv{font-size:15px;font-weight:700;margin-top:2px;color:#00285c;}
    /* Cell info */
    #cell-info{
      background:#f0f5ff;border:1px solid #c0d8ff;border-radius:7px;
      padding:10px;margin:12px 14px;font-size:12px;display:none;
    }
    #cell-info h4{color:#00285c;font-size:12px;margin-bottom:7px;}
    .ir{display:flex;justify-content:space-between;padding:3px 0;
        border-bottom:1px solid #e0e8ff;}
    .ir:last-child{border-bottom:none;}
    .il{color:#666;}
    .iv{font-weight:700;}
    /* Credits */
    #credits{padding:12px 14px;font-size:10px;color:#bbb;line-height:1.6;margin-top:auto;}
    /* Map */
    #map{flex:1;}
  </style>
</head>
<body>
<div id="app">
  <header>
    <a href="../index.html" id="back-link">&#8592; All Cities</a>
    <span id="city-title">CITY_DISPLAY</span>
    <span id="subtitle">Quantifying Urban Greenspace Globally</span>
  </header>
  <div id="main">
    <div id="sidebar">

      <div class="s-section">
        <h3>Index</h3>
        <button class="idx-btn active" data-idx="qwe" onclick="setIndex('qwe')">
          <div class="i-code">QWE</div>
          <div class="i-name">Quality-Weighted Exposure</div>
        </button>
        <button class="idx-btn" data-idx="qamd" onclick="setIndex('qamd')">
          <div class="i-code">QAMD</div>
          <div class="i-name">Quality-Adjusted Min. Distance</div>
        </button>
        <button class="idx-btn" data-idx="gma" onclick="setIndex('gma')">
          <div class="i-code">GMA</div>
          <div class="i-name">Gravity Model Accessibility</div>
        </button>
      </div>

      <div class="s-section">
        <h3>Dimension</h3>
        <div class="dim-tabs">
          <button class="dim-tab active" data-dim="cultural"      onclick="setDim('cultural')">&#127916; Cultural</button>
          <button class="dim-tab"        data-dim="environmental" onclick="setDim('environmental')">&#127807; Environmental</button>
          <button class="dim-tab"        data-dim="nature"        onclick="setDim('nature')">&#127794; Nature</button>
          <button class="dim-tab"        data-dim="physical"      onclick="setDim('physical')">&#127939; Physical</button>
          <button class="dim-tab"        data-dim="social"        onclick="setDim('social')">&#129309; Social</button>
        </div>
      </div>

      <div class="s-section">
        <h3>Display</h3>
        <label class="ctrl-label">Cell opacity</label>
        <input type="range" id="op-slider" min="10" max="100" value="70"
               oninput="setOpacity(this.value/100)">
        <label class="toggle-row" id="parks-toggle-label">
          <input type="checkbox" id="parks-toggle" checked onchange="toggleParks(this.checked)">
          <span>Show parks</span>
        </label>
      </div>

      <div class="s-section">
        <h3>Legend</h3>
        <canvas id="legend-canvas" height="14"></canvas>
        <div id="legend-labels">
          <span id="leg-lo">&mdash;</span>
          <span id="leg-hi">&mdash;</span>
        </div>
        <div id="legend-note"></div>
      </div>

      <div class="s-section">
        <h3>Statistics</h3>
        <div class="stat-grid">
          <div class="stat-cell"><div class="sl">Mean</div><div class="sv" id="st-mean">&mdash;</div></div>
          <div class="stat-cell"><div class="sl">Coverage</div><div class="sv" id="st-cov">&mdash;</div></div>
          <div class="stat-cell"><div class="sl">5th pct.</div><div class="sv" id="st-p5">&mdash;</div></div>
          <div class="stat-cell"><div class="sl">95th pct.</div><div class="sv" id="st-p95">&mdash;</div></div>
        </div>
      </div>

      <div id="cell-info">
        <h4 id="ci-title">Selected cell</h4>
        <div id="ci-body"></div>
      </div>

      <div id="credits">
        Park quality scores: Dietz et al. (2025)<br>
        Spatial framework: Battiston &amp; Schifanella (2023)<br>
        OSM data: OpenStreetMap contributors<br>
        GHS grid: 3 arc-seconds (~90 m)
      </div>
    </div><!-- /sidebar -->

    <!-- Map wrapper: holds Leaflet div + overlay canvas as siblings -->
    <div id="map-wrap" style="position:relative;flex:1;min-width:0;min-height:0;overflow:hidden;">
      <div id="map" style="position:absolute;top:0;left:0;right:0;bottom:0;"></div>
      <canvas id="cell-canvas"
              style="position:absolute;top:0;left:0;pointer-events:none;z-index:500;display:block;">
      </canvas>
    </div>
  </div>
</div>

<script>
// ── Embedded data ─────────────────────────────────────────────────────────
var GHS_HALF = GHS_CELL_DEG_PLACEHOLDER / 2;
var COORDS   = COORDS_JSON_PLACEHOLDER;
var VALUES   = VALUES_JSON_PLACEHOLDER;
var STATS    = STATS_JSON_PLACEHOLDER;
var PARKS    = PARKS_JSON_PLACEHOLDER;
var CENTER   = CENTER_JSON_PLACEHOLDER;   // [lon, lat]

// ── Color scales (viridis / RdYlGn reversed / plasma) ─────────────────────
var COLORS = {
  qwe:  [[68,1,84],[59,82,139],[33,145,140],[94,201,98],[253,231,37]],
  qamd: [[26,152,80],[145,207,96],[255,255,191],[252,141,89],[215,25,28]],
  gma:  [[13,8,135],[126,3,168],[203,70,121],[248,149,64],[240,249,33]]
};

function lerp(a,b,t){ return a+(b-a)*t; }
function lerpRgb(c1,c2,t){ return [lerp(c1[0],c2[0],t),lerp(c1[1],c2[1],t),lerp(c1[2],c2[2],t)]; }

function scaleColor(idx, t){
  var stops = COLORS[idx];
  var n = stops.length - 1;
  var i = Math.min(Math.floor(t*n), n-1);
  var c = lerpRgb(stops[i], stops[i+1], t*n - i);
  return 'rgb('+Math.round(c[0])+','+Math.round(c[1])+','+Math.round(c[2])+')';
}

function valueToColor(idx, v, vmin, vmax){
  if(v===null) return null;
  var t = (v-vmin)/(vmax-vmin||1);
  t = Math.max(0, Math.min(1, t));
  if(idx==='qamd') t = 1-t;   // lower distance = greener
  return scaleColor(idx, t);
}

// ── State ─────────────────────────────────────────────────────────────────
var curIdx = 'qwe', curDim = 'cultural', curOpacity = 0.70;
var vmin = 0, vmax = 1;

function updateRange(){
  var st = (STATS[curIdx]||{})[curDim];
  if(st){ vmin=st.p05; vmax=st.p95; }
}

// ── Leaflet ────────────────────────────────────────────────────────────────
var map = L.map('map',{center:[CENTER[1],CENTER[0]],zoom:12});

L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png',{
  attribution:'&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; <a href="https://carto.com/attributions">CARTO</a>',
  subdomains:'abcd', maxZoom:19
}).addTo(map);

// ── Canvas cell overlay ────────────────────────────────────────────────────
// The canvas sits in #map-wrap as a sibling to #map, both position:absolute
// so their coordinate origins coincide.  latLngToContainerPoint returns
// pixels relative to the Leaflet container (#map div), which is at the same
// position as the canvas, so coordinates are directly usable.
var cellCanvas = document.getElementById('cell-canvas');
var cellCtx = cellCanvas.getContext('2d');

function resizeCanvas(){
  var wrap = document.getElementById('map-wrap');
  cellCanvas.width  = wrap.clientWidth;
  cellCanvas.height = wrap.clientHeight;
}

function redraw(){
  resizeCanvas();
  cellCtx.clearRect(0, 0, cellCanvas.width, cellCanvas.height);

  var vals = (VALUES[curIdx]||{})[curDim];
  if(!vals || !vals.length) return;

  cellCtx.globalAlpha = curOpacity;

  for(var i = 0; i < COORDS.length; i++){
    var v = vals[i];
    if(v === null) continue;
    var lon = COORDS[i][0], lat = COORDS[i][1];
    // latLngToContainerPoint: pixels relative to map container top-left
    var sw = map.latLngToContainerPoint(L.latLng(lat - GHS_HALF, lon - GHS_HALF));
    var ne = map.latLngToContainerPoint(L.latLng(lat + GHS_HALF, lon + GHS_HALF));
    var w = ne.x - sw.x;
    var h = sw.y - ne.y;   // sw.y > ne.y in screen coords (y down)
    if(w < 0.5 || h < 0.5) continue;
    cellCtx.fillStyle = valueToColor(curIdx, v, vmin, vmax);
    cellCtx.fillRect(sw.x, ne.y, w, h);
  }
}

map.on('moveend zoomend', redraw);
window.addEventListener('resize', function(){ map.invalidateSize(); redraw(); });

// ── Parks layer ────────────────────────────────────────────────────────────
var parksLayer=null;

function initParks(){
  if(!PARKS) return;
  parksLayer=L.geoJSON(PARKS,{
    style:{fillColor:'#2a7a3b',fillOpacity:0.22,color:'#1a5430',weight:1,opacity:0.55},
    onEachFeature:function(f,l){
      if(f.properties&&f.properties.name)
        l.bindPopup('<strong>'+f.properties.name+'</strong>',{maxWidth:200});
    }
  }).addTo(map);
  // Show toggle only if parks exist
  document.getElementById('parks-toggle-label').style.display='flex';
}

// ── Controls ───────────────────────────────────────────────────────────────
function setIndex(idx){
  curIdx=idx;
  document.querySelectorAll('.idx-btn').forEach(function(b){
    b.classList.toggle('active', b.dataset.idx===idx);
  });
  updateRange(); redraw(); updateLegend(); updateStats();
}

function setDim(dim){
  curDim=dim;
  document.querySelectorAll('.dim-tab').forEach(function(b){
    b.classList.toggle('active', b.dataset.dim===dim);
  });
  updateRange(); redraw(); updateLegend(); updateStats();
}

function setOpacity(v){ curOpacity=v; redraw(); }

function toggleParks(show){
  if(!parksLayer) return;
  if(show) parksLayer.addTo(map); else map.removeLayer(parksLayer);
}

// ── Legend ─────────────────────────────────────────────────────────────────
function updateLegend(){
  var c=document.getElementById('legend-canvas');
  var ctx=c.getContext('2d');
  var w=c.clientWidth||238, h=14;
  c.width=w;
  for(var x=0;x<w;x++){
    var t=x/(w-1);
    if(curIdx==='qamd') t=1-t;
    ctx.fillStyle=scaleColor(curIdx,t);
    ctx.fillRect(x,0,1,h);
  }
  var st=(STATS[curIdx]||{})[curDim];
  if(st){
    var lo=curIdx==='qamd'?st.p95:st.p05;
    var hi=curIdx==='qamd'?st.p05:st.p95;
    document.getElementById('leg-lo').textContent=fmtVal(lo);
    document.getElementById('leg-hi').textContent=fmtVal(hi);
    document.getElementById('legend-note').textContent=
      curIdx==='qamd'?'lower = closer (better)':'higher = better';
  }
}

function updateStats(){
  var st=(STATS[curIdx]||{})[curDim];
  if(!st){ return; }
  document.getElementById('st-mean').textContent=fmtVal(st.mean);
  document.getElementById('st-cov').textContent=st.pct_notnull.toFixed(1)+'%';
  document.getElementById('st-p5').textContent=fmtVal(st.p05);
  document.getElementById('st-p95').textContent=fmtVal(st.p95);
}

function fmtVal(v){
  if(v===null||v===undefined) return '—';
  var a=Math.abs(v);
  if(a===0) return '0';
  if(a>=1000) return v.toFixed(0);
  if(a>=10)   return v.toFixed(1);
  if(a>=0.1)  return v.toFixed(3);
  return v.toExponential(2);
}

// ── Click to inspect ───────────────────────────────────────────────────────
map.on('click',function(e){
  var lon=e.latlng.lng, lat=e.latlng.lat;
  var best=-1, bestD=Infinity;
  for(var i=0;i<COORDS.length;i++){
    var dx=Math.abs(COORDS[i][0]-lon), dy=Math.abs(COORDS[i][1]-lat);
    if(dx<=GHS_HALF&&dy<=GHS_HALF){
      var d=dx*dx+dy*dy;
      if(d<bestD){bestD=d;best=i;}
    }
  }
  if(best>=0) showCell(best);
});

function showCell(i){
  var lon=COORDS[i][0].toFixed(5), lat=COORDS[i][1].toFixed(5);
  document.getElementById('ci-title').textContent=lat+', '+lon;
  var rows='';
  ['qwe','qamd','gma'].forEach(function(idx){
    var vals=(VALUES[idx]||{})[curDim];
    if(!vals) return;
    var v=vals[i];
    rows+='<div class="ir"><span class="il">'+idx.toUpperCase()+'</span>';
    rows+='<span class="iv">'+(v!==null?fmtVal(v):'—')+'</span></div>';
  });
  document.getElementById('ci-body').innerHTML=rows;
  document.getElementById('cell-info').style.display='block';
}

// ── Boot ───────────────────────────────────────────────────────────────────
initParks();
updateRange();
updateLegend();
updateStats();
// Wait for Leaflet to size the container before drawing cells
map.whenReady(function(){
  resizeCanvas();
  redraw();
});
</script>
</body>
</html>
"""

_PORTAL_HTML = """\
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Quantifying Urban Greenspace Globally &mdash; City Explorer</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box;}
    body{font-family:'Segoe UI',system-ui,sans-serif;background:#f2f4f8;color:#222;min-height:100vh;}
    header{
      background:#00285c;color:white;padding:24px 32px 20px;
      border-bottom:3px solid #7fb3ff;
    }
    header h1{font-size:24px;font-weight:700;margin-bottom:4px;}
    header p{font-size:13px;color:#a0c0e0;max-width:700px;line-height:1.5;}
    .meta{font-size:11px;color:#7fb3ff;margin-top:10px;}
    main{max-width:1200px;margin:32px auto;padding:0 24px;}
    h2{font-size:14px;color:#666;text-transform:uppercase;letter-spacing:0.08em;
       font-weight:600;margin-bottom:16px;}
    .grid{
      display:grid;
      grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
      gap:12px;
    }
    .city-card{
      background:white;border-radius:10px;border:1.5px solid #e4e8f0;
      padding:16px 14px;text-decoration:none;color:#222;
      transition:transform 0.12s,box-shadow 0.12s,border-color 0.12s;
      display:flex;flex-direction:column;gap:4px;
    }
    .city-card:hover{
      transform:translateY(-2px);box-shadow:0 4px 16px rgba(0,40,92,0.12);
      border-color:#00285c;
    }
    .city-card.disabled{
      opacity:0.4;cursor:default;pointer-events:none;
    }
    .city-name{font-weight:700;font-size:14px;}
    .city-cells{font-size:11px;color:#888;}
    .city-badge{
      display:inline-block;font-size:10px;padding:2px 7px;border-radius:20px;
      margin-top:4px;width:fit-content;
    }
    .badge-ok{background:#e6f5ec;color:#1a7a3b;}
    .badge-missing{background:#f5f5f5;color:#aaa;}
    footer{
      text-align:center;padding:24px;font-size:11px;color:#aaa;
      border-top:1px solid #e4e4e4;margin-top:40px;
    }
    footer a{color:#7fb3ff;text-decoration:none;}
    .indices-legend{
      display:flex;gap:16px;flex-wrap:wrap;margin-bottom:28px;
    }
    .idx-pill{
      background:white;border:1.5px solid #ddd;border-radius:8px;
      padding:8px 14px;font-size:12px;
    }
    .idx-pill strong{color:#00285c;margin-right:4px;}
  </style>
</head>
<body>
<header>
  <h1>Quantifying Urban Greenspace Globally</h1>
  <p>
    Interactive maps of park accessibility indices combining Dietz et al. (2025) park
    well-being fingerprints with the ATGreen spatial framework (Battiston &amp;
    Schifanella 2023). Indices computed on the GHS 3 arc-second grid (~90 m).
  </p>
  <div class="meta">KCL Final Project &mdash; Azaan Tak (K25125234) &mdash; Supervisor: Prof. Linus Dietz</div>
</header>
<main>
  <div class="indices-legend">
    <div class="idx-pill"><strong>QWE</strong> Quality-Weighted Exposure</div>
    <div class="idx-pill"><strong>QAMD</strong> Quality-Adjusted Min. Distance</div>
    <div class="idx-pill"><strong>GMA</strong> Gravity Model Accessibility</div>
  </div>
  <h2>CITIES_COUNT cities &mdash; click to explore</h2>
  <div class="grid">
CITY_CARDS_PLACEHOLDER
  </div>
</main>
<footer>
  Data: <a href="https://www.openstreetmap.org">OpenStreetMap</a> contributors &bull;
  Park scores: Dietz et al. (2025) &bull;
  Framework: <a href="https://arxiv.org/abs/2308.05538">Battiston &amp; Schifanella (2023)</a>
</footer>
</body>
</html>
"""

# --- HTML generation

def generate_city_html(data: dict) -> str:
    """Return self-contained HTML string for one city's map."""
    city = data["city"]
    coords_json, values_json, stats_json = build_cell_json(data)
    center_json = json.dumps(list(data["center"]))

    # Use custom placeholder tokens so we never conflict with JS braces
    html = _CITY_MAP_HTML
    html = html.replace("CITY_DISPLAY",            CITY_DISPLAY.get(city, city.title()))
    html = html.replace("GHS_CELL_DEG_PLACEHOLDER", str(GHS_CELL_DEG))
    html = html.replace("COORDS_JSON_PLACEHOLDER",  coords_json)
    html = html.replace("VALUES_JSON_PLACEHOLDER",  values_json)
    html = html.replace("STATS_JSON_PLACEHOLDER",   stats_json)
    html = html.replace("PARKS_JSON_PLACEHOLDER",   data["parks_json"])
    html = html.replace("CENTER_JSON_PLACEHOLDER",  center_json)
    return html


def generate_portal_html(cities_info: list[dict]) -> str:
    """Return HTML for the index.html portal page."""
    cards = []
    ok_count = 0
    for info in cities_info:
        city = info["city"]
        name = CITY_DISPLAY.get(city, city.title())
        has_data = info.get("has_data", False)
        n_cells = info.get("n_cells", 0)
        if has_data:
            ok_count += 1
            badge = '<span class="city-badge badge-ok">&#10003; data available</span>'
            cells_text = f"{n_cells:,} cells"
            href = f'{city}/{city}_map.html'
            card = (
                f'    <a class="city-card" href="{href}">\n'
                f'      <div class="city-name">{name}</div>\n'
                f'      <div class="city-cells">{cells_text}</div>\n'
                f'      {badge}\n'
                f'    </a>'
            )
        else:
            badge = '<span class="city-badge badge-missing">no data yet</span>'
            card = (
                f'    <div class="city-card disabled">\n'
                f'      <div class="city-name">{name}</div>\n'
                f'      <div class="city-cells">&mdash;</div>\n'
                f'      {badge}\n'
                f'    </div>'
            )
        cards.append(card)

    html = _PORTAL_HTML
    html = html.replace("CITY_CARDS_PLACEHOLDER", "\n".join(cards))
    html = html.replace("CITIES_COUNT", str(ok_count))
    return html

# --- Main

def discover_cities(output_dir: Path) -> list[str]:
    """Find cities that have at least a qwe or cell_scores CSV."""
    found = set()
    # Per-city subdirs
    for sub in output_dir.iterdir():
        if sub.is_dir() and sub.name in CITY_CENTERS:
            if any((sub / f"{k}_{sub.name}.csv").exists() for k in ("qwe", "cell_scores")):
                found.add(sub.name)
    # Flat files
    for p in output_dir.glob("qwe_*.csv"):
        city = p.stem[4:]      # strip "qwe_"
        if city in CITY_CENTERS:
            found.add(city)
    return sorted(found)


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument(
        "--out-dir", default="output_figures",
        help="Directory containing pipeline output (default: output_figures)",
    )
    parser.add_argument(
        "--cities", nargs="+", metavar="CITY",
        help="Generate maps only for these cities (default: all detected)",
    )
    args = parser.parse_args()

    output_dir = Path(args.out_dir).resolve()
    if not output_dir.exists():
        parser.error(f"Output directory not found: {output_dir}")

    cities_to_process = args.cities or discover_cities(output_dir)
    if not cities_to_process:
        print("No city data found in", output_dir)
        print("Run the pipeline first (quality_accessibility_osmium.py or accessibility_cli.py).")
        return

    print(f"Generating maps for {len(cities_to_process)} city/cities in {output_dir}/")
    cities_info = []

    for city in cities_to_process:
        print(f"  [{city}] loading data...", end=" ", flush=True)
        data = load_city_data(output_dir, city)

        if data is None:
            print("no data found, skipping.")
            cities_info.append({"city": city, "has_data": False})
            continue

        n_cells = len(data["coords"])
        print(f"{n_cells:,} cells, generating HTML...", end=" ", flush=True)

        city_html = generate_city_html(data)

        # Write to <out-dir>/<city>/<city>_map.html
        city_out_dir = output_dir / city
        city_out_dir.mkdir(parents=True, exist_ok=True)
        out_path = city_out_dir / f"{city}_map.html"
        out_path.write_text(city_html, encoding="utf-8")

        print(f"done -> {out_path.relative_to(output_dir.parent)}")
        cities_info.append({"city": city, "has_data": True, "n_cells": n_cells})

    # Portal index.html
    all_known = [{"city": c, "has_data": False} for c in sorted(CITY_CENTERS)]
    info_map = {d["city"]: d for d in cities_info}
    portal_cities = [info_map.get(c, {"city": c, "has_data": False}) for c in sorted(CITY_CENTERS)]
    portal_html = generate_portal_html(portal_cities)
    portal_path = output_dir / "index.html"
    portal_path.write_text(portal_html, encoding="utf-8")
    print(f"\nPortal page -> {portal_path}")
    print("\nDone. Open output_figures/index.html in your browser.")


if __name__ == "__main__":
    main()
