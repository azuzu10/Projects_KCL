#!/usr/bin/env python3
"""
KD-tree distance matrix, replacing build_distance_df().

The original masks every origin against every destination. At Amsterdam's size
(93k x 2.4k) you can wait it out; at Greater Melbourne's (1.6M x 22k, ~35
billion mask ops) you cannot.

The trick that keeps it exact: chord length c and great-circle distance d are
related by c = 2R sin(d/2R), which is monotone, so a Euclidean ball query on 3D
unit-sphere coordinates with radius 2R sin(d_max/2R) returns exactly the pairs
within d_max great-circle metres. No projection, no approximation. Haversine
and the minutes threshold are then applied to the candidates with the same
formula and the same rounding as the original, so the output is identical --
verify_against_reference() checks it (Amsterdam: same 9,072,560 pairs, same
distances).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import geopandas as gpd
from scipy.spatial import cKDTree

R_EARTH = 6_371_000.0
WALK_SPEED_MPM = 5000.0 / 60.0  # 5 km/h in metres per minute


def _to_cartesian(lat_deg: np.ndarray, lon_deg: np.ndarray) -> np.ndarray:
    """Lat/lon in degrees -> 3D Cartesian points on a sphere of radius R_EARTH."""
    lat = np.radians(lat_deg)
    lon = np.radians(lon_deg)
    cos_lat = np.cos(lat)
    return np.column_stack(
        [R_EARTH * cos_lat * np.cos(lon),
         R_EARTH * cos_lat * np.sin(lon),
         R_EARTH * np.sin(lat)]
    )


def _haversine_minutes(
    o_lat: np.ndarray, o_lon: np.ndarray, d_lat: float, d_lon: float
) -> np.ndarray:
    """Great-circle walking minutes, matching the original formula exactly."""
    dlat = d_lat - o_lat
    dlon = d_lon - o_lon
    a = (
        np.sin(dlat / 2) ** 2
        + np.cos(o_lat) * np.cos(d_lat) * np.sin(dlon / 2) ** 2
    )
    dist_m = 2 * R_EARTH * np.arcsin(np.sqrt(a))
    return np.round(dist_m / WALK_SPEED_MPM, 2)


def build_distance_df_fast(
    cells: gpd.GeoDataFrame,
    overlap_df: pd.DataFrame,
    max_minutes: float = 30.0,
    origin_mask: np.ndarray | None = None,
    verbose: bool = True,
) -> pd.DataFrame:
    """
    Drop-in replacement for qa.build_distance_df().

    Parameters
    ----------
    cells       : GeoDataFrame with columns x, y, cx (lon), cy (lat)
    overlap_df  : output of park_cell_overlap(); defines the 'green' destinations
    max_minutes : discard pairs beyond this walking time
    origin_mask : optional boolean array over `cells` restricting which origins
                  are processed. Used by the chunked driver to bound memory.

    Returns
    -------
    DataFrame: x_source, y_source, x_dest, y_dest, geodesic_minutes
    """
    green_xys = overlap_df[["x", "y"]].drop_duplicates()
    dests = cells[["x", "y", "cx", "cy"]].merge(green_xys, on=["x", "y"], how="inner")

    origins = cells if origin_mask is None else cells.loc[origin_mask]
    if len(origins) == 0 or len(dests) == 0:
        return pd.DataFrame(
            columns=["x_source", "y_source", "x_dest", "y_dest", "geodesic_minutes"]
        )

    # The reference implementation rounds minutes to 2 decimals *before* testing
    # `minutes <= max_minutes`, so a pair at 30.004 min rounds to 30.00 and is
    # kept. The ball query must therefore use a slightly generous radius or those
    # borderline pairs would be dropped before the rounding is applied. The exact
    # (round -> compare) test below still decides acceptance, so widening the
    # prefilter cannot admit anything the reference would reject.
    ROUND_TOL_MIN = 0.01  # > half of the 2-decimal rounding unit (0.005)
    max_dist_m = (max_minutes + ROUND_TOL_MIN) * WALK_SPEED_MPM
    # Chord radius exactly equivalent to the great-circle cutoff
    chord_r = 2 * R_EARTH * np.sin(max_dist_m / (2 * R_EARTH))

    o_xyz = _to_cartesian(origins["cy"].values, origins["cx"].values)
    d_xyz = _to_cartesian(dests["cy"].values, dests["cx"].values)

    if verbose:
        print(
            f"    Origins: {len(origins)}, Destinations: {len(dests)}, "
            f"cutoff: {max_minutes} min  [KD-tree]"
        )

    tree = cKDTree(o_xyz)
    # One ball query per destination, returning only nearby origin indices
    neighbours = tree.query_ball_point(d_xyz, r=chord_r, workers=-1)

    o_lat_rad = np.radians(origins["cy"].values)
    o_lon_rad = np.radians(origins["cx"].values)
    o_x = origins["x"].values
    o_y = origins["y"].values
    d_lat_rad = np.radians(dests["cy"].values)
    d_lon_rad = np.radians(dests["cx"].values)
    d_x = dests["x"].values
    d_y = dests["y"].values

    parts = []
    for k, idx in enumerate(neighbours):
        if len(idx) == 0:
            continue
        idx = np.asarray(idx, dtype=np.int64)
        minutes = _haversine_minutes(
            o_lat_rad[idx], o_lon_rad[idx], d_lat_rad[k], d_lon_rad[k]
        )
        within = minutes <= max_minutes
        if not within.any():
            continue
        sel = idx[within]
        parts.append(
            pd.DataFrame(
                {
                    "x_source": o_x[sel],
                    "y_source": o_y[sel],
                    "x_dest": d_x[k],
                    "y_dest": d_y[k],
                    "geodesic_minutes": minutes[within],
                }
            )
        )

    if not parts:
        return pd.DataFrame(
            columns=["x_source", "y_source", "x_dest", "y_dest", "geodesic_minutes"]
        )
    return pd.concat(parts, ignore_index=True)


def install(module) -> None:
    """Monkeypatch `module.build_distance_df` with the fast implementation."""
    module.build_distance_df = build_distance_df_fast


def verify_against_reference(cells, overlap_df, max_minutes: float = 30.0) -> dict:
    """Run both implementations and compare their outputs exactly."""
    import quality_accessibility_osmium as qa

    ref = qa.build_distance_df(cells, overlap_df, max_minutes=max_minutes)
    fast = build_distance_df_fast(
        cells, overlap_df, max_minutes=max_minutes, verbose=False
    )

    key = ["x_source", "y_source", "x_dest", "y_dest"]
    ref_s = ref.sort_values(key).reset_index(drop=True)
    fast_s = fast.sort_values(key).reset_index(drop=True)

    same_rows = len(ref_s) == len(fast_s)
    same_pairs = same_rows and ref_s[key].equals(fast_s[key])
    same_minutes = (
        same_rows
        and np.allclose(
            ref_s["geodesic_minutes"].values,
            fast_s["geodesic_minutes"].values,
            atol=1e-9,
        )
    )
    return {
        "n_reference": len(ref_s),
        "n_fast": len(fast_s),
        "same_row_count": same_rows,
        "same_pair_set": bool(same_pairs),
        "same_distances": bool(same_minutes),
    }
