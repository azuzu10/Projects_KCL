#!/usr/bin/env python3
"""
Per-city figure set for any number of cities.

visualize_scores.py hardcodes Amsterdam in three places (OUT_DIR, TOTAL_CELLS,
filename prefixes); rather than destabilise the file that made the published
Amsterdam figures, this is the city-parameterised counterpart. For each city it
writes the QWE/QAMD/GMA histograms, the coverage chart, radar_<city>.png and
<city>_index_summary.csv into --out-dir.
"""

from __future__ import annotations

import argparse
import os
import sys

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

DIMS = ["cultural", "environmental", "nature", "physical", "social"]
SCORE_COLS = [f"combined_score_{d}" for d in DIMS]
DIM_COLORS = ["#e74c3c", "#2ecc71", "#27ae60", "#3498db", "#9b59b6"]


def find_scores_csv(project_root: str) -> str:
    for rel in (
        ("Health-Promoting-Parks-Replication-main", "data", "scores_cities.csv"),
        ("Health-Promoting-Parks-Replication-main",
         "Health-Promoting-Parks-Replication-main", "data", "scores_cities.csv"),
    ):
        p = os.path.join(project_root, *rel)
        if os.path.exists(p):
            return p
    raise FileNotFoundError("scores_cities.csv not found under " + project_root)


def load_csv(out_dir: str, name: str, city: str) -> pd.DataFrame | None:
    path = os.path.join(out_dir, f"{name}_{city}.csv")
    return pd.read_csv(path) if os.path.exists(path) else None


def total_cells(out_dir: str, city: str) -> tuple[int, bool]:
    """Return (n_cells, exact). `exact` is False when falling back."""
    meta = load_csv(out_dir, "meta", city)
    if meta is not None and "n_cells" in meta.columns and len(meta):
        return int(meta["n_cells"].iloc[0]), True
    cells = load_csv(out_dir, "cells", city)
    if cells is not None:
        return len(cells), True
    gma = load_csv(out_dir, "gma", city)
    if gma is not None:
        return len(gma), False
    return 0, False


# --- per-city figures

def plot_index_histogram(out_dir: str, city: str, index: str) -> None:
    df = load_csv(out_dir, index.lower(), city)
    if df is None:
        print(f"    {index}: no data, skipped")
        return
    cols = [f"{index}_{d}" for d in DIMS]
    if not all(c in df.columns for c in cols):
        print(f"    {index}: unexpected columns, skipped")
        return

    fig, axes = plt.subplots(1, 5, figsize=(16, 4), sharey=True)
    for ax, dim, col, c in zip(axes, DIMS, cols, DIM_COLORS):
        vals = df[col].dropna()
        plotted = vals if index == "QAMD" else vals[vals > 0]
        ax.hist(plotted, bins=40, color=c, alpha=0.75, edgecolor="white")
        ax.set_title(dim.capitalize(), fontsize=10, fontweight="bold")
        ax.grid(axis="y", alpha=0.3)
        if index == "QAMD":
            ax.axvline(15, color="black", lw=1, ls="--", label="15-min target")
            ax.set_xlabel("Minutes")
            pct = 100 * (vals <= 15).sum() / len(vals) if len(vals) else 0
            ax.text(0.95, 0.95, f"<15min: {pct:.0f}%", transform=ax.transAxes,
                    ha="right", va="top", fontsize=8, color="grey")
        else:
            ax.set_xlabel(f"{index} value")
            ax.text(0.95, 0.95, f"n={len(plotted):,}", transform=ax.transAxes,
                    ha="right", va="top", fontsize=8, color="grey")

    axes[0].set_ylabel("Number of cells")
    if index == "QAMD":
        axes[0].legend(fontsize=7, loc="upper left")
    titles = {
        "QWE": "Quality-Weighted Exposure (QWE)",
        "QAMD": "Quality-Adjusted Min Distance (QAMD, q=0)",
        "GMA": "Gravity-Model Accessibility (GMA, tau=10)",
    }
    fig.suptitle(f"{titles[index]} - {city.replace('_',' ').title()}",
                 fontweight="bold", fontsize=12)
    plt.tight_layout()
    path = os.path.join(out_dir, f"{city}_{index.lower()}_histogram.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"    saved {os.path.basename(path)}")


def plot_coverage(out_dir: str, city: str) -> None:
    qwe = load_csv(out_dir, "qwe", city)
    qamd = load_csv(out_dir, "qamd", city)
    gma = load_csv(out_dir, "gma", city)
    if qwe is None or qamd is None or gma is None:
        print("    coverage: missing index output, skipped")
        return

    total, exact = total_cells(out_dir, city)
    if total == 0:
        print("    coverage: cannot determine grid size, skipped")
        return
    if not exact:
        print(f"    WARNING: no meta_{city}.csv; coverage uses a fallback "
              f"denominator of {total:,} cells")

    categories, values = [], []
    categories.append("QWE > 0\n(any dim)")
    values.append(100 * (qwe[[f"QWE_{d}" for d in DIMS]].sum(axis=1) > 0).sum() / total)
    for d in DIMS:
        vals = qamd[f"QAMD_{d}"].dropna()
        categories.append(f"QAMD {d[:4]}\n<15 min")
        values.append(100 * (vals <= 15).sum() / total)
    categories.append("GMA > 0\n(any dim)")
    values.append(100 * (gma[[f"GMA_{d}" for d in DIMS]].sum(axis=1) > 0).sum() / total)

    fig, ax = plt.subplots(figsize=(10, 5))
    bars = ax.bar(range(len(categories)), values,
                  color=["#2c3e50"] + DIM_COLORS + ["#2c3e50"], alpha=0.8)
    ax.set_xticks(range(len(categories)))
    ax.set_xticklabels(categories, fontsize=8)
    ax.set_ylabel(f"% of grid cells (n={total:,})")
    ax.set_title(
        f"{city.replace('_',' ').title()} - Accessibility Coverage "
        f"(% of {total:,} cells)", fontweight="bold")
    ax.set_ylim(0, 100)
    ax.grid(axis="y", alpha=0.3)
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1,
                f"{val:.1f}%", ha="center", va="bottom", fontsize=8)
    plt.tight_layout()
    path = os.path.join(out_dir, f"{city}_coverage.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"    saved {os.path.basename(path)}")


def plot_radar(out_dir: str, city: str, scores: pd.DataFrame) -> None:
    if city not in set(scores["city"]):
        print("    radar: city absent from scores_cities.csv, skipped")
        return
    city_mean = scores[scores["city"] == city][SCORE_COLS].mean().values
    global_mean = scores[SCORE_COLS].mean().values

    angles = np.linspace(0, 2 * np.pi, len(DIMS), endpoint=False).tolist()
    angles += angles[:1]
    cv = np.concatenate([city_mean, city_mean[:1]])
    gv = np.concatenate([global_mean, global_mean[:1]])

    fig, ax = plt.subplots(figsize=(7, 7), subplot_kw=dict(polar=True))
    ax.plot(angles, cv, "o-", lw=2, color="#e74c3c",
            label=city.replace("_", " ").title())
    ax.fill(angles, cv, color="#e74c3c", alpha=0.15)
    ax.plot(angles, gv, "s--", lw=2, color="#7f8c8d", label="Global Average")
    ax.fill(angles, gv, color="#7f8c8d", alpha=0.10)
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels([d.capitalize() for d in DIMS])
    ax.set_title(f"{city.replace('_',' ').title()} vs Global Average",
                 fontweight="bold", fontsize=13, pad=20)
    ax.legend(loc="lower right", bbox_to_anchor=(1.15, -0.05))
    plt.tight_layout()
    path = os.path.join(out_dir, f"radar_{city}.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"    saved {os.path.basename(path)}")


def save_index_summary(out_dir: str, city: str) -> pd.DataFrame:
    total, _ = total_cells(out_dir, city)
    rows = []
    for name in ("QWE", "QAMD", "GMA"):
        df = load_csv(out_dir, name.lower(), city)
        if df is None:
            continue
        for d in DIMS:
            col = f"{name}_{d}"
            if col not in df.columns:
                continue
            vals = df[col].dropna()
            if not len(vals):
                continue
            row = {
                "city": city,
                "index": name,
                "dimension": d,
                "cells_with_value": len(vals),
                "pct_of_total": round(100 * len(vals) / total, 1) if total else np.nan,
                "mean": round(vals.mean(), 4),
                "median": round(vals.median(), 4),
                "std": round(vals.std(), 4),
                "min": round(vals.min(), 4),
                "max": round(vals.max(), 4),
            }
            if name == "QAMD":
                row["pct_within_15min"] = round(100 * (vals <= 15).sum() / len(vals), 1)
            rows.append(row)
    out = pd.DataFrame(rows)
    path = os.path.join(out_dir, f"{city}_index_summary.csv")
    out.to_csv(path, index=False)
    print(f"    saved {os.path.basename(path)}")
    return out


def discover_cities(out_dir: str) -> list[str]:
    return sorted(
        f[len("qwe_"):-len(".csv")]
        for f in os.listdir(out_dir)
        if f.startswith("qwe_") and f.endswith(".csv")
    )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out-dir", default="output_multi")
    ap.add_argument("--project-root", default=os.getcwd())
    ap.add_argument("--cities", nargs="+", metavar="CITY")
    ap.add_argument("--all", action="store_true",
                    help="process every city with a qwe_<city>.csv in --out-dir")
    args = ap.parse_args()

    if not os.path.isdir(args.out_dir):
        print(f"ERROR: no such directory {args.out_dir}", file=sys.stderr)
        return 1

    cities = args.cities or discover_cities(args.out_dir)
    if not cities:
        print(f"No pipeline output found in {args.out_dir}", file=sys.stderr)
        return 1

    scores = pd.read_csv(find_scores_csv(args.project_root))

    print(f"Generating figures for {len(cities)} city/cities -> {args.out_dir}\n")
    summaries = []
    for city in cities:
        print(f"  {city}")
        if load_csv(args.out_dir, "qwe", city) is None:
            print("    no qwe output, skipped\n")
            continue
        for idx in ("QWE", "QAMD", "GMA"):
            plot_index_histogram(args.out_dir, city, idx)
        plot_coverage(args.out_dir, city)
        plot_radar(args.out_dir, city, scores)
        summaries.append(save_index_summary(args.out_dir, city))
        print()

    if summaries:
        combined = pd.concat(summaries, ignore_index=True)
        path = os.path.join(args.out_dir, "all_cities_index_summary.csv")
        combined.to_csv(path, index=False)
        print(f"Combined summary -> {path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
