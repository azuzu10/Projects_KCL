"""
The whole pipeline for one city, end to end: read the boundary and parks out of
an OSM PBF extract, lay a GHS-style 3 arc-second grid (~90 m) over the city,
work out park/cell overlap, attach the Dietz et al. (2025) well-being scores,
and compute the four quality-weighted indices. No Overpass, no database --
everything comes from the local PBF file. Deliberately self-contained; nothing
here imports from the older parks_cells_spatial.py or quality_accessibility.py.

Needs osmium, geopandas, shapely, numpy, pandas.

Inputs: a Geofabrik extract covering the city, plus the two CSVs from the Dietz
replication package -- scores_cities.csv (the scores) and fingerprints_cities.csv
(which also carries the park OSM IDs used to find geometries).

Run it from the "Final project" folder:

    python quality_accessibility_osmium.py amsterdam path/to/amsterdam.osm.pbf

or import it and call run("amsterdam", "amsterdam.osm.pbf") directly.
"""

from __future__ import annotations

import os
import sys
from typing import Optional

import geopandas as gpd
import numpy as np
import osmium
import pandas as pd
from shapely.geometry import LineString, MultiPolygon, Polygon, box
from shapely.ops import linemerge, polygonize, unary_union

# --- Constants

# GHS-POP raster resolution: 3 arc-seconds ≈ 0.000833 degrees
GHS_CELL_DEG = 3 / 3600

# OSM relation IDs for administrative boundaries of the 35 study cities
CITY_OSM_RELATIONS: dict[str, int] = {
    "amsterdam":      271110,
    "auckland":      2184679,
    "berlin":           62422,
    "boston":         2315704,
    "buenos_aires":   1224652,
    "chicago":          122604,
    "christchurch":   3360985,
    "copenhagen":     2192363,
    "hong_kong":       913110,
    "houston":        2688911,
    "london":           65606,
    "madrid":         5326784,
    "melbourne":      4246124,
    "montreal":       1634158,
    "moscow":         2555133,
    "new_york":        175905,
    "paris":            71525,
    "perth":           234748,
    "philadelphia":    188022,
    "rio_de_janeiro": 2697233,
    "rome":             41485,
    "san_diego":       253832,
    "san_francisco":   111968,
    "seattle":         237385,
    "seoul":           307756,
    "singapore":       536780,
    "st_petersburg":   337422,
    "stockholm":       398021,
    "sydney":        13766477,
    "taipeh":         1293250,
    "tokyo":          1543125,
    "toronto":         324211,
    "vancouver":      1852574,
    "vienna":          109166,
    "washington_dc":   162069,
}

SCORE_DIMS = ["cultural", "environmental", "nature", "physical", "social"]
SCORE_COLS = [f"combined_score_{d}" for d in SCORE_DIMS]

# --- osmium helpers

def _node_coords(n) -> tuple[float, float]:
    """Return (lon, lat) for an osmium node reference, skipping invalid locations."""
    loc = n.location
    return (loc.lon, loc.lat)


class _RelationMemberCollector(osmium.SimpleHandler):
    """
    Pass 1 — scan the PBF for a single relation by ID and record
    the IDs and roles of all its way members.
    """
    def __init__(self, relation_id: int) -> None:
        super().__init__()
        self.relation_id = relation_id
        self.way_ids: list[int] = []
        self.roles: dict[int, str] = {}

    def relation(self, r) -> None:
        if r.id != self.relation_id:
            return
        for m in r.members:
            if m.type == "w":
                self.way_ids.append(m.ref)
                self.roles[m.ref] = m.role


class _WayGeometryExtractor(osmium.SimpleHandler):
    """
    Pass 2 — scan the PBF with node locations resolved (locations=True)
    and build Shapely geometries for a fixed set of way IDs.
    Closed ways become Polygons; open ways become LineStrings.
    """
    def __init__(self, target_ids: set[int], roles: dict[int, str]) -> None:
        super().__init__()
        self.target_ids = target_ids
        self.roles = roles
        self.ways: list[dict] = []  # [{way_id, role, geometry}]

    def way(self, w) -> None:
        if w.id not in self.target_ids:
            return
        coords = [_node_coords(n) for n in w.nodes if n.location.valid()]
        if len(coords) < 2:
            return
        if coords[0] == coords[-1] and len(coords) >= 4:
            geom = Polygon(coords)
        else:
            geom = LineString(coords)
        self.ways.append({
            "way_id":   w.id,
            "role":     self.roles.get(w.id, "outer"),
            "geometry": geom,
        })


def _assemble_polygon(ways: list[dict]) -> Polygon | MultiPolygon | None:
    """
    Reconstruct a (Multi)Polygon from a list of outer/inner member ways.
    Follows the same OSM multipolygon algorithm used in ATGreen processing_osm.py:
      - merge LineStrings by role, polygonize them
      - subtract inner polygons from outer polygons
    """
    outer_ls = [w["geometry"] for w in ways if w["role"] == "outer" and isinstance(w["geometry"], LineString)]
    inner_ls = [w["geometry"] for w in ways if w["role"] == "inner" and isinstance(w["geometry"], LineString)]
    outer_pg = [w["geometry"] for w in ways if w["role"] == "outer" and isinstance(w["geometry"], Polygon)]
    inner_pg = [w["geometry"] for w in ways if w["role"] == "inner" and isinstance(w["geometry"], Polygon)]

    if outer_ls:
        outer_pg += list(polygonize(linemerge(outer_ls)))
    if inner_ls:
        inner_pg += list(polygonize(linemerge(inner_ls)))

    if not outer_pg:
        return None

    result = []
    for op in outer_pg:
        for ip in inner_pg:
            if ip.within(op):
                op = op.buffer(0).difference(ip.buffer(0))
        result.append(op.buffer(0))

    if len(result) == 1:
        return result[0]
    return MultiPolygon([g for g in result if not g.is_empty])


# --- City boundary

def extract_city_boundary(pbf_path: str, relation_id: int) -> gpd.GeoDataFrame:
    """
    Extract the administrative boundary polygon of a city from a PBF file.

    Uses two osmium passes (matching ATGreen's WayFind approach):
      Pass 1 — collect member way IDs from the target relation
      Pass 2 — extract those ways with resolved node locations

    Parameters
    ----------
    pbf_path    : path to the .osm.pbf city extract
    relation_id : OSM relation ID of the admin boundary

    Returns
    -------
    Single-row GeoDataFrame in EPSG:4326
    """
    print(f"    Pass 1 - reading relation {relation_id} members ...")
    collector = _RelationMemberCollector(relation_id)
    collector.apply_file(pbf_path)

    if not collector.way_ids:
        raise ValueError(
            f"Relation {relation_id} not found in {pbf_path}.\n"
            "Make sure your PBF extract covers the full city boundary."
        )

    print(f"    Pass 2 - extracting {len(collector.way_ids)} member ways with locations ...")
    extractor = _WayGeometryExtractor(set(collector.way_ids), collector.roles)
    extractor.apply_file(pbf_path, locations=True, idx="flex_mem")

    geom = _assemble_polygon(extractor.ways)
    if geom is None:
        raise ValueError(
            f"Could not reconstruct boundary geometry for relation {relation_id}.\n"
            "The PBF extract may be missing some boundary ways."
        )

    return gpd.GeoDataFrame({"geometry": [geom]}, crs="EPSG:4326")


# --- Park extraction

class _ParkWayHandler(osmium.SimpleHandler):
    """
    Single-pass handler (locations=True) that extracts leisure=park polygon ways.
    If target_ids is provided, only those OSM IDs are collected.
    """
    def __init__(self, target_ids: Optional[set[int]] = None) -> None:
        super().__init__()
        self.target_ids = target_ids
        self.parks: list[dict] = []

    def way(self, w) -> None:
        if w.tags.get("leisure") != "park":
            return
        if w.tags.get("access") in ("no", "private"):
            return
        if self.target_ids is not None and w.id not in self.target_ids:
            return
        coords = [_node_coords(n) for n in w.nodes if n.location.valid()]
        if len(coords) < 3 or coords[0] != coords[-1]:
            return  # not a closed ring - skip (open ways are not park polygons)
        self.parks.append({"osm_id": w.id, "geometry": Polygon(coords).buffer(0)})


class _ParkRelationCollector(osmium.SimpleHandler):
    """
    Pass 1 for park relations — collect member way IDs for all
    leisure=park multipolygon relations (optionally filtered by target IDs).
    """
    def __init__(self, target_ids: Optional[set[int]] = None) -> None:
        super().__init__()
        self.target_ids = target_ids
        # rel_id -> {"way_ids": [...], "roles": {way_id: role}}
        self.relations: dict[int, dict] = {}

    def relation(self, r) -> None:
        if r.tags.get("leisure") != "park":
            return
        if r.tags.get("type") != "multipolygon":
            return
        if r.tags.get("access") in ("no", "private"):
            return
        if self.target_ids is not None and r.id not in self.target_ids:
            return
        way_ids, roles = [], {}
        for m in r.members:
            if m.type == "w":
                way_ids.append(m.ref)
                roles[m.ref] = m.role
        if way_ids:
            self.relations[r.id] = {"way_ids": way_ids, "roles": roles}


def extract_parks(
    pbf_path: str,
    target_osm_ids: Optional[list[int]] = None,
) -> gpd.GeoDataFrame:
    """
    Extract park polygons from a PBF file using osmium.

    Parks stored as OSM ways are extracted in a single pass.
    Parks stored as OSM relations (multipolygons) need two passes
    (same two-pass pattern as ATGreen's relationsExtraction pipeline).

    Parameters
    ----------
    pbf_path       : path to the .osm.pbf city extract
    target_osm_ids : if provided, only extract parks with these OSM IDs;
                     otherwise extract all leisure=park features in the file

    Returns
    -------
    GeoDataFrame with columns: osm_id, geometry (EPSG:4326)
    """
    target_set = set(target_osm_ids) if target_osm_ids else None

    # --- Ways (single pass)
    print("    Extracting park ways (single pass with locations) ...")
    way_handler = _ParkWayHandler(target_set)
    way_handler.apply_file(pbf_path, locations=True, idx="flex_mem")
    parks = way_handler.parks.copy()
    way_ids_found = {p["osm_id"] for p in parks}
    print(f"    -> {len(parks)} park ways found.")

    # --- Relations (two passes)
    # Only look for relation IDs not already found as ways
    rel_target = (target_set - way_ids_found) if target_set else None

    print("    Collecting park relations (pass 1) ...")
    rel_collector = _ParkRelationCollector(rel_target)
    rel_collector.apply_file(pbf_path)
    print(f"    -> {len(rel_collector.relations)} park relations found.")

    if rel_collector.relations:
        # Gather all member way IDs across all relations
        all_member_ids: set[int] = set()
        all_roles: dict[int, str] = {}
        for info in rel_collector.relations.values():
            all_member_ids.update(info["way_ids"])
            all_roles.update(info["roles"])

        print(f"    Extracting {len(all_member_ids)} relation member ways (pass 2) ...")
        mem_extractor = _WayGeometryExtractor(all_member_ids, all_roles)
        mem_extractor.apply_file(pbf_path, locations=True, idx="flex_mem")
        ways_by_id = {w["way_id"]: w for w in mem_extractor.ways}

        for rel_id, info in rel_collector.relations.items():
            member_ways = [ways_by_id[wid] for wid in info["way_ids"] if wid in ways_by_id]
            if not member_ways:
                continue
            geom = _assemble_polygon(member_ways)
            if geom is not None:
                parks.append({"osm_id": rel_id, "geometry": geom})

    if not parks:
        raise ValueError(
            "No parks extracted from PBF.\n"
            "Check that your PBF extract contains the city's parks and that "
            "the OSM IDs in fingerprints_cities.csv match what is in the file."
        )

    print(f"    -> {len(parks)} parks total (ways + relations).")
    return gpd.GeoDataFrame(parks, crs="EPSG:4326")


# --- GHS grid cell generation

def generate_ghs_grid(
    boundary: gpd.GeoDataFrame,
    buffer_m: float = 3000.0,
    cell_deg: float = GHS_CELL_DEG,
) -> gpd.GeoDataFrame:
    """
    Generate GHS-aligned 3 arc-second (~90 m) grid cells covering the city
    boundary plus an optional buffer.  Mirrors ATGreen's population raster grid.

    Parameters
    ----------
    boundary : single-row GeoDataFrame with city outline (EPSG:4326)
    buffer_m : buffer distance in metres added around the boundary
    cell_deg : cell side length in decimal degrees (default = 3 arc-seconds)

    Returns
    -------
    GeoDataFrame: x (col), y (row), cx/cy (centroid lon/lat), geometry
    """
    boundary_proj = boundary.to_crs(boundary.estimate_utm_crs())
    boundary_buf  = boundary_proj.buffer(buffer_m).to_crs("EPSG:4326")
    bounds = boundary_buf.total_bounds   # (minx, miny, maxx, maxy)

    # Snap extent to GHS grid origin
    minx = np.floor(bounds[0] / cell_deg) * cell_deg
    miny = np.floor(bounds[1] / cell_deg) * cell_deg
    maxx = np.ceil(bounds[2]  / cell_deg) * cell_deg
    maxy = np.ceil(bounds[3]  / cell_deg) * cell_deg

    xs = np.arange(minx, maxx, cell_deg)
    ys = np.arange(miny, maxy, cell_deg)

    rows = []
    for col_i, x in enumerate(xs):
        for row_j, y in enumerate(ys):
            rows.append({
                "x":  col_i,
                "y":  row_j,
                "cx": x + cell_deg / 2,
                "cy": y + cell_deg / 2,
                "geometry": box(x, y, x + cell_deg, y + cell_deg),
            })

    gdf = gpd.GeoDataFrame(rows, crs="EPSG:4326")
    # Keep only cells that touch the buffered boundary
    boundary_union = unary_union(boundary_buf.geometry.values)
    return gdf[gdf.intersects(boundary_union)].reset_index(drop=True)


# --- Spatial analysis

def _to_metric(gdf: gpd.GeoDataFrame) -> gpd.GeoDataFrame:
    """Reproject to the best local UTM CRS for area/distance calculations."""
    return gdf.to_crs(gdf.estimate_utm_crs())


def park_cell_overlap(
    cells: gpd.GeoDataFrame,
    parks: gpd.GeoDataFrame,
    min_overlap_ha: float = 0.0,
) -> pd.DataFrame:
    """
    For every (cell, park) pair that spatially intersects, compute the
    intersection area in hectares.

    Returns
    -------
    DataFrame: x, y, osm_id, cell_area_ha, overlap_ha, overlap_frac
    """
    cells_m = _to_metric(cells)[["x", "y", "geometry"]].copy().reset_index(drop=True)
    parks_m = _to_metric(parks)[["osm_id", "geometry"]].copy().reset_index(drop=True)

    joined = gpd.sjoin(cells_m, parks_m, how="inner", predicate="intersects")

    # Build a lookup dict for fast park geometry access
    parks_geom = parks_m.set_index("osm_id")["geometry"].to_dict()

    rows = []
    for idx, row in joined.iterrows():
        cell_geom = cells_m.loc[idx, "geometry"]
        park_geom = parks_geom.get(row["osm_id"])
        if park_geom is None:
            continue
        isect      = cell_geom.intersection(park_geom)
        overlap_ha = isect.area / 10_000
        cell_ha    = cell_geom.area / 10_000
        if overlap_ha >= min_overlap_ha:
            rows.append({
                "x":            row["x"],
                "y":            row["y"],
                "osm_id":       row["osm_id"],
                "cell_area_ha": round(cell_ha, 4),
                "overlap_ha":   round(overlap_ha, 6),
                "overlap_frac": round(overlap_ha / cell_ha, 4) if cell_ha > 0 else 0.0,
            })

    return pd.DataFrame(rows)


# --- Quality scores

def load_park_scores(
    path: str = (
        "Health-Promoting-Parks-Replication-main/"
        "Health-Promoting-Parks-Replication-main/data/scores_cities.csv"
    ),
) -> pd.DataFrame:
    """
    Load Dietz et al. (2025) park quality scores.

    Expected columns: city, osm_id, combined_score_{cultural, environmental,
    nature, physical, social}
    """
    df = pd.read_csv(path)
    missing = [c for c in ["city", "osm_id"] + SCORE_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns in scores CSV: {missing}")
    return df


def assign_cell_scores(
    overlap_df: pd.DataFrame,
    scores_df: pd.DataFrame,
    city: str,
    normalise: bool = True,
) -> pd.DataFrame:
    """
    Map park-level quality scores onto grid cells via area-weighted averaging.

    For each cell, the score for dimension d is:
        cell_score_d = Σ(overlap_ha_j × park_score_d_j) / Σ(overlap_ha_j)

    Parameters
    ----------
    overlap_df : output of park_cell_overlap()
    scores_df  : output of load_park_scores()
    city       : must match the 'city' column in scores_df
    normalise  : if True, add _norm columns shifted to [0, 1] within the city

    Returns
    -------
    DataFrame: x, y, combined_score_{dim}, [combined_score_{dim}_norm]
    """
    city_scores = scores_df[scores_df["city"] == city][["osm_id"] + SCORE_COLS].copy()
    merged = overlap_df.merge(city_scores, on="osm_id", how="left").dropna(subset=SCORE_COLS)

    if merged.empty:
        raise ValueError(
            f"No score data found for city='{city}'.\n"
            "Check that OSM IDs in the overlap table match those in scores_cities.csv."
        )

    rows = []
    for (cx, cy), grp in merged.groupby(["x", "y"]):
        total = grp["overlap_ha"].sum()
        if total == 0:
            continue
        row = {"x": cx, "y": cy}
        for sc in SCORE_COLS:
            row[sc] = (grp[sc] * grp["overlap_ha"]).sum() / total
        rows.append(row)

    cell_scores = pd.DataFrame(rows)

    if normalise:
        for sc in SCORE_COLS:
            mn, mx = cell_scores[sc].min(), cell_scores[sc].max()
            rng = mx - mn
            cell_scores[sc + "_norm"] = (cell_scores[sc] - mn) / rng if rng > 0 else 0.0

    return cell_scores


# --- Accessibility indices

def quality_weighted_exposure(
    dist_df: pd.DataFrame,
    cell_scores: pd.DataFrame,
    threshold_min: float = 15.0,
    use_normalised: bool = True,
) -> pd.DataFrame:
    """
    Quality-Weighted Exposure (QWE).

    For each origin cell i:
        QWE_i^d = Σ_{j : dist_ij ≤ T} overlap_ha_j × score_d(j)

    Parameters
    ----------
    dist_df        : distance DataFrame with columns x_source, y_source,
                     x_dest, y_dest, and either walk_minutes or geodesic_minutes
    cell_scores    : output of assign_cell_scores()
    threshold_min  : walking-time threshold in minutes (default 15)
    use_normalised : use _norm score columns so below-average parks still
                     contribute positively (recommended: True)

    Returns
    -------
    DataFrame: x_source, y_source, QWE_{dim} for each dimension
    """
    dist_col = "walk_minutes" if "walk_minutes" in dist_df.columns else "geodesic_minutes"
    reachable = dist_df[dist_df[dist_col] <= threshold_min].copy()

    suffix    = "_norm" if use_normalised else ""
    score_map = {f"QWE_{d}": f"combined_score_{d}{suffix}" for d in SCORE_DIMS}

    reachable = reachable.merge(
        cell_scores[["x", "y"] + list(score_map.values())],
        left_on=["x_dest", "y_dest"], right_on=["x", "y"],
        how="inner",
    )

    if "overlap_ha" in cell_scores.columns:
        reachable = reachable.merge(
            cell_scores[["x", "y", "overlap_ha"]],
            left_on=["x_dest", "y_dest"], right_on=["x", "y"],
            how="left", suffixes=("", "_c"),
        )
        reachable["overlap_ha"] = reachable["overlap_ha"].fillna(0)
    else:
        reachable["overlap_ha"] = 1.0

    for qcol, sc in score_map.items():
        reachable[qcol] = reachable["overlap_ha"] * reachable[sc]

    return (
        reachable.groupby(["x_source", "y_source"])[list(score_map)]
        .sum()
        .reset_index()
    )


def quality_adjusted_min_distance(
    dist_df: pd.DataFrame,
    cell_scores: pd.DataFrame,
    q: float = 0.0,
    use_normalised: bool = False,
) -> pd.DataFrame:
    """
    Quality-Adjusted Minimum Distance (QAMD).

    For each origin cell i, find the minimum travel time to a destination j
    whose quality score is at or above threshold q:
        QAMD_i^d(q) = min_{j : score_d(j) ≥ q} dist_ij

    Parameters
    ----------
    q : quality threshold.  With raw scores (use_normalised=False):
          q=0 → accepts only above-average parks (scores centred at 0)
        With normalised scores (use_normalised=True):
          q=0.5 → top 50% of parks by quality

    Returns
    -------
    DataFrame: x_source, y_source, QAMD_{dim} for each dimension
    NaN means no qualifying park is reachable.
    """
    dist_col = "walk_minutes" if "walk_minutes" in dist_df.columns else "geodesic_minutes"
    suffix   = "_norm" if use_normalised else ""
    parts    = []

    for dim in SCORE_DIMS:
        sc_col  = f"combined_score_{dim}{suffix}"
        out_col = f"QAMD_{dim}"
        qualifying = cell_scores[cell_scores[sc_col] >= q][["x", "y"]]
        sub = dist_df.merge(
            qualifying, left_on=["x_dest", "y_dest"], right_on=["x", "y"], how="inner"
        )
        if sub.empty:
            continue
        parts.append(
            sub.groupby(["x_source", "y_source"])[dist_col]
            .min().reset_index().rename(columns={dist_col: out_col})
        )

    if not parts:
        return pd.DataFrame(
            columns=["x_source", "y_source"] + [f"QAMD_{d}" for d in SCORE_DIMS]
        )
    result = parts[0]
    for p in parts[1:]:
        result = result.merge(p, on=["x_source", "y_source"], how="outer")
    return result


def gravity_accessibility(
    dist_df: pd.DataFrame,
    cell_scores: pd.DataFrame,
    tau: float = 10.0,
    use_normalised: bool = True,
) -> pd.DataFrame:
    """
    Gravity-Model Accessibility (GMA).

    For each origin cell i:
        GMA_i^d = Σ_j overlap_ha_j × score_d(j) × exp(-dist_ij / tau)

    Parameters
    ----------
    tau : distance-decay half-life in minutes.
          tau=5  → nearby parks dominate strongly
          tau=15 → more evenly distributed contribution from farther parks

    Returns
    -------
    DataFrame: x_source, y_source, GMA_{dim} for each dimension
    """
    dist_col = "walk_minutes" if "walk_minutes" in dist_df.columns else "geodesic_minutes"
    suffix   = "_norm" if use_normalised else ""

    working = dist_df.copy()
    working["decay"] = np.exp(-working[dist_col] / tau)

    sc_cols = [f"combined_score_{d}{suffix}" for d in SCORE_DIMS]
    working = working.merge(
        cell_scores[["x", "y"] + sc_cols],
        left_on=["x_dest", "y_dest"], right_on=["x", "y"],
        how="inner",
    )

    if "overlap_ha" in cell_scores.columns:
        working = working.merge(
            cell_scores[["x", "y", "overlap_ha"]],
            left_on=["x_dest", "y_dest"], right_on=["x", "y"],
            how="left", suffixes=("", "_c"),
        )
        working["overlap_ha"] = working["overlap_ha"].fillna(0)
    else:
        working["overlap_ha"] = 1.0

    gma_cols = []
    for dim, sc in zip(SCORE_DIMS, sc_cols):
        col = f"GMA_{dim}"
        working[col] = working["overlap_ha"] * working[sc] * working["decay"]
        gma_cols.append(col)

    return working.groupby(["x_source", "y_source"])[gma_cols].sum().reset_index()


# --- Best reachable park score

def best_reachable_score(
    dist_df: pd.DataFrame,
    cell_scores: pd.DataFrame,
    thresholds_min: list[float] = [5.0, 15.0, 30.0],
    use_normalised: bool = False,
) -> pd.DataFrame:
    """
    For each origin cell, find the MAXIMUM park quality score reachable
    within each travel-time threshold, per activity dimension.

    Rationale: you only need one great park to enjoy nature or play sports.
    This metric captures whether a cell's "best reachable park" clears the bar,
    rather than how much total green exposure it has.

    Formula
    -------
        BEST_i^d(T) = max_{j : dist_ij <= T} score_d(j)

    NaN means no park with a score is reachable within that threshold.

    Parameters
    ----------
    dist_df         : distance DataFrame with columns x_source, y_source,
                      x_dest, y_dest, and walk_minutes or geodesic_minutes
    cell_scores     : output of assign_cell_scores()
    thresholds_min  : list of travel-time thresholds in minutes (default [5, 15, 30])
    use_normalised  : if True, use _norm score columns (scores shifted to [0, 1]);
                      if False (default), use raw z-score columns so the result
                      is directly interpretable as standard deviations above/below
                      the city average park quality

    Returns
    -------
    DataFrame with columns:
        x_source, y_source,
        BEST_{dim}_{T}min  for each dimension and each threshold T

    Example columns: BEST_nature_5min, BEST_nature_15min, BEST_nature_30min,
                     BEST_physical_5min, ...
    """
    dist_col = "walk_minutes" if "walk_minutes" in dist_df.columns else "geodesic_minutes"
    suffix   = "_norm" if use_normalised else ""

    # Attach destination cell scores to the distance table once (all thresholds share it)
    sc_cols = [f"combined_score_{d}{suffix}" for d in SCORE_DIMS]
    enriched = dist_df.merge(
        cell_scores[["x", "y"] + sc_cols],
        left_on=["x_dest", "y_dest"],
        right_on=["x", "y"],
        how="inner",   # only destination cells that are green AND have scores
    )

    results = []
    for T in thresholds_min:
        reachable = enriched[enriched[dist_col] <= T]
        if reachable.empty:
            continue
        # Per origin cell, take the max score across all reachable green cells
        agg = reachable.groupby(["x_source", "y_source"])[sc_cols].max().reset_index()
        # Rename columns to BEST_{dim}_{T}min
        rename = {
            f"combined_score_{d}{suffix}": f"BEST_{d}_{int(T)}min"
            for d in SCORE_DIMS
        }
        agg = agg.rename(columns=rename)
        results.append(agg)

    if not results:
        cols = (
            ["x_source", "y_source"]
            + [f"BEST_{d}_{int(T)}min" for d in SCORE_DIMS for T in thresholds_min]
        )
        return pd.DataFrame(columns=cols)

    # Merge all thresholds on the origin cell key
    merged = results[0]
    for part in results[1:]:
        merged = merged.merge(part, on=["x_source", "y_source"], how="outer")

    # Order columns: x_source, y_source, then grouped by dimension
    dim_cols = [
        f"BEST_{d}_{int(T)}min"
        for d in SCORE_DIMS
        for T in thresholds_min
    ]
    present = [c for c in dim_cols if c in merged.columns]
    return merged[["x_source", "y_source"] + present]


# --- Geodesic distance matrix (fallback for when OSRM is unavailable)

def build_distance_df(
    cells: gpd.GeoDataFrame,
    overlap_df: pd.DataFrame,
    max_minutes: float = 30.0,
) -> pd.DataFrame:
    """
    Build a cell-to-cell distance matrix using vectorized haversine distances,
    converted to walking minutes at 5 km/h.

    Only keeps pairs within max_minutes walking time to avoid memory blow-up.

    Use this as a fallback when the OSRM street-network matrix is not available.
    For production results, replace with ATGreen's OSRM-based distances.

    Parameters
    ----------
    cells       : GeoDataFrame with columns x, y, cx (lon), cy (lat)
    overlap_df  : output of park_cell_overlap() — defines which cells are 'green'
    max_minutes : discard pairs beyond this walking time (default 30)

    Returns
    -------
    DataFrame: x_source, y_source, x_dest, y_dest, geodesic_minutes
    """
    green_xys = overlap_df[["x", "y"]].drop_duplicates()
    dests = cells[["x", "y", "cx", "cy"]].merge(green_xys, on=["x", "y"], how="inner")

    orig_lat = np.radians(cells["cy"].values)
    orig_lon = np.radians(cells["cx"].values)
    dest_lat = np.radians(dests["cy"].values)
    dest_lon = np.radians(dests["cx"].values)

    R = 6_371_000
    WALK_SPEED_MPM = 5000.0 / 60.0

    max_dist_m = max_minutes * WALK_SPEED_MPM
    max_dlat_rad = max_dist_m / R * 1.2
    max_dlon_rad = max_dlat_rad * 1.5

    all_parts = []
    batch = 500
    n_dest = len(dests)
    print(f"    Origins: {len(cells)}, Destinations: {n_dest}, "
          f"cutoff: {max_minutes} min")

    for i in range(0, n_dest, batch):
        j = min(i + batch, n_dest)
        d_lat = dest_lat[i:j]
        d_lon = dest_lon[i:j]

        for k in range(len(d_lat)):
            dlat_abs = np.abs(orig_lat - d_lat[k])
            dlon_abs = np.abs(orig_lon - d_lon[k])
            mask = (dlat_abs < max_dlat_rad) & (dlon_abs < max_dlon_rad)
            if not mask.any():
                continue

            o_lat = orig_lat[mask]
            o_lon = orig_lon[mask]
            dlat = d_lat[k] - o_lat
            dlon = d_lon[k] - o_lon
            a = np.sin(dlat / 2) ** 2 + np.cos(o_lat) * np.cos(d_lat[k]) * np.sin(dlon / 2) ** 2
            dist_m = 2 * R * np.arcsin(np.sqrt(a))
            minutes = np.round(dist_m / WALK_SPEED_MPM, 2)

            within = minutes <= max_minutes
            if not within.any():
                continue

            idx = np.where(mask)[0][within]
            part = pd.DataFrame({
                "x_source": cells["x"].values[idx],
                "y_source": cells["y"].values[idx],
                "x_dest": dests["x"].values[i + k],
                "y_dest": dests["y"].values[i + k],
                "geodesic_minutes": minutes[within],
            })
            all_parts.append(part)

    if not all_parts:
        return pd.DataFrame(
            columns=["x_source", "y_source", "x_dest", "y_dest", "geodesic_minutes"]
        )
    return pd.concat(all_parts, ignore_index=True)


# --- Main pipeline

def run(
    city: str,
    pbf_path: str,
    scores_path: str = (
        "Health-Promoting-Parks-Replication-main/"
        "Health-Promoting-Parks-Replication-main/data/scores_cities.csv"
    ),
    fingerprints_path: str = (
        "Health-Promoting-Parks-Replication-main/"
        "Health-Promoting-Parks-Replication-main/data/fingerprints_cities.csv"
    ),
    buffer_m: float = 3000.0,
    qwe_threshold_min: float = 15.0,
    gma_tau: float = 10.0,
    qamd_q: float = 0.0,
) -> dict:
    """
    Full pipeline for one city.

    Parameters
    ----------
    city               : city name (must be a key in CITY_OSM_RELATIONS)
    pbf_path           : path to .osm.pbf city extract
    scores_path        : path to scores_cities.csv
    fingerprints_path  : path to fingerprints_cities.csv
    buffer_m           : boundary buffer in metres for grid generation
    qwe_threshold_min  : walking-time cap for QWE index
    gma_tau            : distance-decay parameter (minutes) for GMA index
    qamd_q             : minimum quality threshold for QAMD index

    Returns
    -------
    dict with keys: cells, parks, overlap, cell_scores, dist_df, qwe, qamd, gma
    """
    if city not in CITY_OSM_RELATIONS:
        raise ValueError(
            f"Unknown city '{city}'.\n"
            f"Available cities: {sorted(CITY_OSM_RELATIONS)}\n"
            "To add a new city, append its OSM relation ID to CITY_OSM_RELATIONS."
        )

    relation_id = CITY_OSM_RELATIONS[city]
    print(f"\n{'='*60}")
    print(f"  City : {city}")
    print(f"  PBF  : {pbf_path}")
    print(f"{'='*60}\n")

    # Step 1: City boundary
    print("[1/6] Extracting city boundary via osmium ...")
    boundary = extract_city_boundary(pbf_path, relation_id)
    print(f"      Boundary CRS: {boundary.crs}")

    # Step 2: Target park OSM IDs from fingerprints CSV
    print("[2/6] Loading target park OSM IDs from fingerprints CSV ...")
    fp = pd.read_csv(fingerprints_path)
    fp_city = fp[fp["city"] == city]
    target_ids = fp_city["osm_id"].tolist()
    print(f"      {len(target_ids)} parks listed for '{city}'.")

    # Step 3: Park geometries via pyosmium
    print("[3/6] Extracting park geometries via osmium ...")
    parks = extract_parks(pbf_path, target_osm_ids=target_ids)

    # Step 4: GHS grid cells
    print("[4/6] Generating GHS-aligned grid cells ...")
    cells = generate_ghs_grid(boundary, buffer_m=buffer_m)
    print(f"      {len(cells)} cells generated.")

    # Step 5: Park–cell spatial overlap
    print("[5/6] Computing park-cell spatial overlap ...")
    overlap = park_cell_overlap(cells, parks)
    print(f"      {len(overlap)} (cell, park) intersection pairs.")

    # Step 6: Cell-level quality scores
    print("[6/6] Assigning area-weighted quality scores to cells ...")
    scores = load_park_scores(scores_path)
    cell_scores = assign_cell_scores(overlap, scores, city)
    # Add per-cell total overlap area (used as weight in QWE / GMA)
    cell_scores = cell_scores.merge(
        overlap.groupby(["x", "y"])["overlap_ha"].sum().reset_index(),
        on=["x", "y"], how="left",
    )
    print(f"      {len(cell_scores)} green cells with quality scores.")

    # Distance matrix (geodesic fallback)
    print("\nBuilding geodesic distance matrix ...")
    print("  (Replace with ATGreen OSRM walk_minutes for production results.)")
    dist_df = build_distance_df(cells, overlap)
    print(f"  {len(dist_df):,} origin–destination pairs computed.")

    # Accessibility indices
    print("\nComputing accessibility indices ...")
    qwe  = quality_weighted_exposure(
        dist_df, cell_scores, threshold_min=qwe_threshold_min
    )
    qamd = quality_adjusted_min_distance(dist_df, cell_scores, q=qamd_q)
    gma  = gravity_accessibility(dist_df, cell_scores, tau=gma_tau)
    best = best_reachable_score(dist_df, cell_scores, thresholds_min=[5.0, 15.0, 30.0])

    # Summary
    print(f"\n{'-'*60}")
    print(f"  QWE  rows : {len(qwe)}")
    print(f"  QAMD rows : {len(qamd)}")
    print(f"  GMA  rows : {len(gma)}")
    print(f"  BEST rows : {len(best)}")
    print(f"{'-'*60}")
    print("\n-- QWE (first 5 rows) --")
    print(qwe.head().to_string(index=False))
    print("\n-- QAMD (first 5 rows) --")
    print(qamd.head().to_string(index=False))
    print("\n-- GMA (first 5 rows) --")
    print(gma.head().to_string(index=False))
    print("\n-- BEST reachable score (first 5 rows) --")
    print(best.head().to_string(index=False))

    return {
        "cells":       cells,
        "parks":       parks,
        "overlap":     overlap,
        "cell_scores": cell_scores,
        "dist_df":     dist_df,
        "qwe":         qwe,
        "qamd":        qamd,
        "gma":         gma,
        "best":        best,
    }


# --- CLI entry point

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(__doc__)
        print("\nUsage: python quality_accessibility_osmium.py <city> <path/to/city.osm.pbf>")
        print("Example: python quality_accessibility_osmium.py amsterdam amsterdam.osm.pbf")
        sys.exit(1)

    _city = sys.argv[1]
    _pbf  = sys.argv[2]
    results = run(_city, _pbf)

    out_dir = "output_figures"
    os.makedirs(out_dir, exist_ok=True)
    results["qwe"].to_csv(f"{out_dir}/qwe_{_city}.csv", index=False)
    results["qamd"].to_csv(f"{out_dir}/qamd_{_city}.csv", index=False)
    results["gma"].to_csv(f"{out_dir}/gma_{_city}.csv", index=False)
    results["best"].to_csv(f"{out_dir}/best_{_city}.csv", index=False)
    results["cell_scores"].to_csv(f"{out_dir}/cell_scores_{_city}.csv", index=False)
    results["overlap"].to_csv(f"{out_dir}/overlap_{_city}.csv", index=False)
    # Save cell centroids and park geometries for map visualisation
    results["cells"][["x", "y", "cx", "cy"]].to_csv(
        f"{out_dir}/cells_{_city}.csv", index=False
    )
    try:
        results["parks"].to_file(f"{out_dir}/parks_{_city}.geojson", driver="GeoJSON")
    except Exception as _exc:
        print(f"Warning: could not save parks GeoJSON: {_exc}")
    print(f"\nResults saved to {out_dir}/")
