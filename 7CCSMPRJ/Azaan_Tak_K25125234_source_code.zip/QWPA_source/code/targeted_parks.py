#!/usr/bin/env python3
"""
Park extraction for big extracts without a node-location index.

extract_parks() with idx="flex_mem" indexes every node in the file. Quebec is
1.1 GB and Spain 1.4 GB; that index alone blows a small machine's RAM, and the
disk-backed fallback (lowmem_index) is correct but slow -- three full passes
with random-access lookups.

The observation that fixes it: the park OSM IDs are known before we touch the
file, from fingerprints_cities.csv, so almost none of those nodes matter. Three
sequential scans: relations first (member ways + roles of target multipolygons),
then ways (node ID lists), then nodes (coordinates for just the IDs collected --
tens of thousands, not tens of millions). Assembly then follows the original
rules exactly: Polygon(coords).buffer(0) for closed ways, qa._assemble_polygon()
for relations, same leisure=park and access filters, same de-duplication.

Returns the same GeoDataFrame (osm_id, geometry, EPSG:4326) as
qa.extract_parks(), and install() rebinds at runtime rather than editing the
original. verify_against_reference() confirmed identical parks on Amsterdam
(106) and Melbourne (1,787).
"""

from __future__ import annotations

import os
import pickle

import geopandas as gpd
import osmium
from shapely.geometry import LineString, Polygon

import quality_accessibility_osmium as qa


# --- Pass A: target multipolygon relations

class _RelCollector(osmium.SimpleHandler):
    def __init__(self, target_ids: set[int] | None) -> None:
        super().__init__()
        self.target_ids = target_ids
        self.relations: dict[int, dict] = {}

    def relation(self, r) -> None:
        if r.tags.get("leisure") != "park":
            return
        if r.tags.get("type") != "multipolygon":
            return
        if r.tags.get("access") in ("no", "private"):
            return
        if self.target_ids is not None and r.id not in self.target_ids:
            return
        way_ids, roles = [], {}
        for m in r.members:
            if m.type == "w":
                way_ids.append(m.ref)
                roles[m.ref] = m.role
        if way_ids:
            self.relations[r.id] = {"way_ids": way_ids, "roles": roles}


# --- Pass B: node-ID lists for the ways we care about

class _WayRefCollector(osmium.SimpleHandler):
    """
    Collect node-ID sequences without resolving locations.

    `park_targets` filters ways that are parks in their own right (tag checks
    apply). `member_targets` are relation member ways, which carry no park tags
    of their own and must therefore bypass the tag filter.
    """

    def __init__(self, park_targets: set[int] | None,
                 member_targets: set[int]) -> None:
        super().__init__()
        self.park_targets = park_targets
        self.member_targets = member_targets
        self.park_ways: dict[int, list[int]] = {}
        self.member_ways: dict[int, list[int]] = {}
        self.needed_nodes: set[int] = set()

    def way(self, w) -> None:
        wid = w.id
        if wid in self.member_targets:
            refs = [n.ref for n in w.nodes]
            self.member_ways[wid] = refs
            self.needed_nodes.update(refs)

        if w.tags.get("leisure") != "park":
            return
        if w.tags.get("access") in ("no", "private"):
            return
        if self.park_targets is not None and wid not in self.park_targets:
            return
        refs = [n.ref for n in w.nodes]
        self.park_ways[wid] = refs
        self.needed_nodes.update(refs)


# --- Pass C: coordinates for exactly those nodes

class _NodeCollector(osmium.SimpleHandler):
    def __init__(self, needed: set[int]) -> None:
        super().__init__()
        self.needed = needed
        self.coords: dict[int, tuple[float, float]] = {}

    def node(self, n) -> None:
        if n.id in self.needed:
            loc = n.location
            if loc.valid():
                self.coords[n.id] = (loc.lon, loc.lat)


def _resolve_nodes(pbf_path: str, needed: set[int]) -> dict[int, tuple[float, float]]:
    """
    Return {node_id: (lon, lat)} for `needed`, using a C++-side IdFilter when the
    installed pyosmium supports it and falling back to a Python handler if not.
    Both paths produce identical results.
    """
    if not needed:
        return {}

    has_filter = hasattr(osmium, "FileProcessor") and hasattr(
        getattr(osmium, "filter", None), "IdFilter"
    )
    if has_filter:
        try:
            coords: dict[int, tuple[float, float]] = {}
            fp = (
                osmium.FileProcessor(pbf_path, osmium.osm.NODE)
                .with_filter(osmium.filter.IdFilter(needed))
            )
            for n in fp:
                loc = n.location
                if loc.valid():
                    coords[n.id] = (loc.lon, loc.lat)
            return coords
        except Exception as exc:  # pragma: no cover - defensive
            print(f"    [lowmem] IdFilter path unavailable ({exc}); "
                  f"falling back to handler", flush=True)

    handler = _NodeCollector(needed)
    handler.apply_file(pbf_path)
    return handler.coords


_CACHE_PREFIX: str | None = None


def set_cache(prefix: str | None) -> None:
    """
    Enable per-pass caching, writing `<prefix>_refs.pkl` and `<prefix>_coords.pkl`.

    Each pass is a full scan of the extract, so on a country-sized file a single
    pass can take longer than an execution time limit allows. Caching lets an
    interrupted extraction resume at the next pass instead of starting over.
    Pass None to disable.
    """
    global _CACHE_PREFIX
    _CACHE_PREFIX = prefix


def _cache_load(suffix: str):
    if not _CACHE_PREFIX:
        return None
    path = f"{_CACHE_PREFIX}_{suffix}.pkl"
    if os.path.exists(path) and os.path.getsize(path) > 0:
        try:
            with open(path, "rb") as fh:
                return pickle.load(fh)
        except Exception:
            return None
    return None


def _cache_save(suffix: str, obj) -> None:
    if not _CACHE_PREFIX:
        return
    os.makedirs(os.path.dirname(f"{_CACHE_PREFIX}_{suffix}.pkl") or ".", exist_ok=True)
    with open(f"{_CACHE_PREFIX}_{suffix}.pkl", "wb") as fh:
        pickle.dump(obj, fh, protocol=pickle.HIGHEST_PROTOCOL)


def extract_parks_lowmem(
    pbf_path: str,
    target_osm_ids: list[int] | None = None,
) -> gpd.GeoDataFrame:
    """Drop-in replacement for qa.extract_parks() (see module docstring)."""
    target_set = set(target_osm_ids) if target_osm_ids else None

    cached = _cache_load("refs")
    if cached is not None:
        relations, all_roles, park_ways, member_ways, needed_nodes = cached
        print(f"    [lowmem] passes A+B CACHED "
              f"({len(park_ways)} park ways, {len(needed_nodes):,} nodes)",
              flush=True)
    else:
        # Pass A -- relations. Run first so member way IDs are known before the
        # single way scan, letting passes B and C stay at one scan each.
        print("    [lowmem] Pass A: collecting park relations ...", flush=True)
        rel = _RelCollector(target_set)
        rel.apply_file(pbf_path)
        member_ids: set[int] = set()
        all_roles = {}
        for info in rel.relations.values():
            member_ids.update(info["way_ids"])
            all_roles.update(info["roles"])
        print(f"    [lowmem] -> {len(rel.relations)} relations, "
              f"{len(member_ids)} member ways", flush=True)

        # Pass B -- ways
        print("    [lowmem] Pass B: collecting way node refs ...", flush=True)
        ways = _WayRefCollector(target_set, member_ids)
        ways.apply_file(pbf_path)
        print(f"    [lowmem] -> {len(ways.park_ways)} park ways, "
              f"{len(ways.needed_nodes):,} nodes needed", flush=True)
        relations = rel.relations
        park_ways, member_ways = ways.park_ways, ways.member_ways
        needed_nodes = ways.needed_nodes
        _cache_save("refs", (relations, all_roles, park_ways, member_ways,
                             needed_nodes))

    # Pass C -- nodes.
    #
    # A SimpleHandler here would invoke a Python callback for every node in the
    # file: ~50 M calls on quebec-latest, which dominates the whole extraction.
    # pyosmium >= 4 can apply an IdFilter inside the C++ reader instead, so only
    # the few thousand nodes actually wanted ever cross into Python.
    coords = _cache_load("coords")
    if coords is not None:
        print(f"    [lowmem] Pass C CACHED ({len(coords):,} coordinates)", flush=True)
    else:
        print("    [lowmem] Pass C: resolving node coordinates ...", flush=True)
        coords = _resolve_nodes(pbf_path, needed_nodes)
        print(f"    [lowmem] -> {len(coords):,} coordinates resolved", flush=True)
        _cache_save("coords", coords)

    # --- assemble, mirroring qa.extract_parks() exactly
    parks: list[dict] = []
    for wid, refs in park_ways.items():
        pts = [coords[r] for r in refs if r in coords]
        if len(pts) < 3 or pts[0] != pts[-1]:
            continue  # not a closed ring, same rule as the original
        parks.append({"osm_id": wid, "geometry": Polygon(pts).buffer(0)})

    way_ids_found = {p["osm_id"] for p in parks}

    for rel_id, info in relations.items():
        # The original only looks for relation IDs not already found as ways.
        if target_set is not None and rel_id in way_ids_found:
            continue
        member_geoms = []
        for wid in info["way_ids"]:
            refs = member_ways.get(wid)
            if not refs:
                continue
            pts = [coords[r] for r in refs if r in coords]
            if len(pts) < 2:
                continue
            # Mirror _WayGeometryExtractor.way(): closed rings of >= 4 points
            # become Polygons, everything else a LineString, and the default
            # role is "outer". _assemble_polygon() relies on all three.
            if pts[0] == pts[-1] and len(pts) >= 4:
                geom = Polygon(pts)
            else:
                geom = LineString(pts)
            member_geoms.append({
                "way_id": wid,
                "role": all_roles.get(wid, "outer"),
                "geometry": geom,
            })
        if not member_geoms:
            continue
        geom = qa._assemble_polygon(member_geoms)
        if geom is not None:
            parks.append({"osm_id": rel_id, "geometry": geom})

    if not parks:
        raise ValueError(
            "No parks extracted from PBF.\n"
            "Check that the extract contains the city's parks and that the OSM "
            "IDs in fingerprints_cities.csv match what is in the file."
        )

    print(f"    [lowmem] -> {len(parks)} parks total (ways + relations).")
    return gpd.GeoDataFrame(parks, crs="EPSG:4326")


def _ways_to_geoms(
    way_refs: dict[int, list[int]],
    coords: dict[int, tuple[float, float]],
    roles: dict[int, str],
) -> list[dict]:
    """
    Build the [{way_id, role, geometry}] list that qa._assemble_polygon expects,
    using the same rules as qa._WayGeometryExtractor.way().
    """
    out = []
    for wid, refs in way_refs.items():
        pts = [coords[r] for r in refs if r in coords]
        if len(pts) < 2:
            continue
        if pts[0] == pts[-1] and len(pts) >= 4:
            geom = Polygon(pts)
        else:
            geom = LineString(pts)
        out.append({"way_id": wid, "role": roles.get(wid, "outer"), "geometry": geom})
    return out


def extract_city_boundary_lowmem(pbf_path: str, relation_id: int) -> gpd.GeoDataFrame:
    """
    Drop-in replacement for qa.extract_city_boundary().

    The original's second pass uses `locations=True, idx="flex_mem"`, indexing
    every node in the file to resolve at most a few hundred boundary ways. On a
    country-sized extract that either exhausts RAM or, with the disk-backed
    index, needs multiple GB of scratch space. This resolves only the nodes the
    boundary ways actually reference.
    """
    print(f"    [lowmem] Pass 1 - reading relation {relation_id} members ...",
          flush=True)
    way_ids: list[int] = []
    roles: dict[int, str] = {}
    for r in osmium.FileProcessor(pbf_path, osmium.osm.RELATION).with_filter(
        osmium.filter.IdFilter([relation_id])
    ):
        for m in r.members:
            if m.type == "w":
                way_ids.append(m.ref)
                roles[m.ref] = m.role

    if not way_ids:
        raise ValueError(
            f"Relation {relation_id} not found in {pbf_path}.\n"
            "Make sure your PBF extract covers the full city boundary."
        )

    print(f"    [lowmem] Pass 2 - {len(way_ids)} member ways ...", flush=True)
    want = set(way_ids)
    way_refs: dict[int, list[int]] = {}
    needed: set[int] = set()
    for w in osmium.FileProcessor(pbf_path, osmium.osm.WAY).with_filter(
        osmium.filter.IdFilter(want)
    ):
        refs = [n.ref for n in w.nodes]
        way_refs[w.id] = refs
        needed.update(refs)

    print(f"    [lowmem] Pass 3 - resolving {len(needed):,} nodes ...", flush=True)
    coords = _resolve_nodes(pbf_path, needed)

    geom = qa._assemble_polygon(_ways_to_geoms(way_refs, coords, roles))
    if geom is None:
        raise ValueError(
            f"Could not reconstruct boundary geometry for relation {relation_id}.\n"
            "The PBF extract may be missing some boundary ways."
        )
    return gpd.GeoDataFrame({"geometry": [geom]}, crs="EPSG:4326")


def install(module=qa) -> None:
    """Rebind the two PBF-reading extractors to the low-memory implementations."""
    module.extract_parks = extract_parks_lowmem
    module.extract_city_boundary = extract_city_boundary_lowmem


def verify_against_reference(pbf_path: str, target_osm_ids: list[int]) -> dict:
    """Compare against qa.extract_parks() on an extract small enough for both."""
    ref = qa.extract_parks(pbf_path, target_osm_ids=target_osm_ids)
    new = extract_parks_lowmem(pbf_path, target_osm_ids=target_osm_ids)

    ref_ids = set(ref["osm_id"])
    new_ids = set(new["osm_id"])
    ref_s = ref.sort_values("osm_id").reset_index(drop=True)
    new_s = new.sort_values("osm_id").reset_index(drop=True)

    same_geom = None
    if ref_ids == new_ids:
        same_geom = bool(
            ref_s.geometry.geom_equals_exact(new_s.geometry, tolerance=1e-9).all()
        )
        area_ref = ref_s.geometry.area.sum()
        area_new = new_s.geometry.area.sum()
    else:
        area_ref = area_new = float("nan")

    return {
        "n_reference": len(ref),
        "n_lowmem": len(new),
        "same_id_set": ref_ids == new_ids,
        "only_in_reference": sorted(ref_ids - new_ids)[:10],
        "only_in_lowmem": sorted(new_ids - ref_ids)[:10],
        "geometries_equal": same_geom,
        "total_area_reference": area_ref,
        "total_area_lowmem": area_new,
    }
