#!/usr/bin/env python3
"""
Disk-backed node index, for running the pipeline against big extracts on a
small machine.

The pipeline resolves node locations with idx="flex_mem" in three places, which
keeps every node location in RAM. Right choice for Amsterdam's 179 MB extract;
with quebec-latest at 1.1 GB and spain-latest at 1.4 GB the index alone
exhausts memory before any geometry gets built.

The swap is the index backend only -- flex_mem to sparse_file_array, which
memory-maps the index to disk. Locations, geometries and every downstream
number are unchanged; the cost is disk I/O and scratch space (roughly
proportional to the highest node ID -- allow a few GB, cleaned up on
uninstall() or process exit).

    import lowmem_index
    lowmem_index.install()
    ...
    lowmem_index.uninstall()

or use the context manager, lowmem_index.enabled().
"""

from __future__ import annotations

import atexit
import contextlib
import glob
import os
import tempfile

import osmium

_ORIGINAL = None
_SCRATCH: str | None = None

# Extracts at or above this size get the disk-backed index under install(auto=True).
AUTO_THRESHOLD_BYTES = 500 * 1024 * 1024


def _cleanup() -> None:
    global _SCRATCH
    if _SCRATCH and os.path.isdir(_SCRATCH):
        for f in glob.glob(os.path.join(_SCRATCH, "*.idx")):
            try:
                os.remove(f)
            except OSError:
                pass
        try:
            os.rmdir(_SCRATCH)
        except OSError:
            pass
    _SCRATCH = None


def install(scratch_dir: str | None = None, auto: bool = False) -> None:
    """
    Patch osmium so `idx="flex_mem"` becomes a disk-backed sparse_file_array.

    auto=True  -> only for extracts >= AUTO_THRESHOLD_BYTES, leaving small
                  city-sized files on the faster in-memory index.
    auto=False -> always.
    """
    global _ORIGINAL, _SCRATCH
    if _ORIGINAL is not None:
        return  # already installed

    _SCRATCH = scratch_dir or tempfile.mkdtemp(prefix="osmium_idx_")
    os.makedirs(_SCRATCH, exist_ok=True)
    atexit.register(_cleanup)

    _ORIGINAL = osmium.SimpleHandler.apply_file

    def apply_file(self, filename, locations=False, idx="flex_mem"):
        if locations and idx == "flex_mem":
            big = True
            if auto:
                try:
                    big = os.path.getsize(str(filename)) >= AUTO_THRESHOLD_BYTES
                except OSError:
                    big = True
            if big:
                path = os.path.join(_SCRATCH, f"nodes_{id(self):x}.idx")
                idx = f"sparse_file_array,{path}"
        return _ORIGINAL(self, filename, locations=locations, idx=idx)

    osmium.SimpleHandler.apply_file = apply_file


def uninstall() -> None:
    """Restore the original apply_file and delete scratch index files."""
    global _ORIGINAL
    if _ORIGINAL is not None:
        osmium.SimpleHandler.apply_file = _ORIGINAL
        _ORIGINAL = None
    _cleanup()


@contextlib.contextmanager
def enabled(scratch_dir: str | None = None, auto: bool = False):
    install(scratch_dir=scratch_dir, auto=auto)
    try:
        yield
    finally:
        uninstall()
