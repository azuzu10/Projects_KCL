"""
This is the berlin copy of visualize_scores.py. Generated from the Amsterdam
original rather than hand-edited, so the only differences are TOTAL_CELLS
(277,295 for this city's grid, in place of Amsterdam's 92,655) and the city
name in defaults and output filenames. Coverage percentages only mean anything
against the city's own grid, which is why TOTAL_CELLS has to travel with the
city. The original file is untouched.
"""
"""
visualize_scores.py
===================
Statistics and visualizations of park quality scores and accessibility indices.

Part A - Cross-city score analysis (from scores_cities.csv):
  1. city_mean_scores.png      - Horizontal bar chart: mean score per city
  2. radar_berlin.png       - Radar: Berlin vs global average
  3. score_distributions.png   - Box plots: score spread per dimension
  4. dimension_correlation.png - Heatmap: correlation between dimensions
  5. top_bottom_cities.png     - Top/bottom 5 cities per dimension
  6. summary_stats.csv         - Per-city summary table

Part B - Berlin pipeline results (from pipeline CSVs):
  7. berlin_qwe_histogram.png  - QWE distribution per dimension
  8. berlin_qamd_histogram.png - QAMD distribution per dimension
  9. berlin_gma_histogram.png  - GMA distribution per dimension
  10. berlin_coverage.png      - Coverage: % of cells reached per index
  11. berlin_index_summary.csv - Summary statistics for all indices

Usage:
    python visualize_scores.py
"""

import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SCORES_CSV = (
    "Health-Promoting-Parks-Replication-main/"
    "Health-Promoting-Parks-Replication-main/data/scores_cities.csv"
)

DIMS = ["cultural", "environmental", "nature", "physical", "social"]
SCORE_COLS = [f"combined_score_{d}" for d in DIMS]
DIM_COLORS = ["#e74c3c", "#2ecc71", "#27ae60", "#3498db", "#9b59b6"]
OUT_DIR = "output_figures"
TOTAL_CELLS = 277295  # berlin: cells in this city's own GHS grid


def load_scores():
    return pd.read_csv(SCORES_CSV)


# --- Part A: Cross-city score analysis

def print_summary(df):
    print("=" * 60)
    print("  PARK QUALITY SCORES - SUMMARY STATISTICS")
    print("=" * 60)
    print(f"\n  Total parks : {len(df)}")
    print(f"  Cities      : {df['city'].nunique()}")

    sizes = df.groupby("city").size()
    print(f"  Parks/city   : min={int(sizes.min())}  "
          f"median={int(sizes.median())}  max={int(sizes.max())}")
    print(f"  Park area (ha): min={df['area'].min():.3f}  "
          f"median={df['area'].median():.2f}  max={df['area'].max():.1f}")

    print(f"\n  {'Dimension':<16} {'Mean':>8} {'Std':>8} {'Min':>8} {'Max':>8}")
    print("  " + "-" * 50)
    for d, col in zip(DIMS, SCORE_COLS):
        s = df[col]
        print(f"  {d:<16} {s.mean():>8.3f} {s.std():>8.3f} "
              f"{s.min():>8.3f} {s.max():>8.3f}")

    print("\n  Berlin - top 5 parks (by mean across dimensions):")
    ams = df[df["city"] == "berlin"].copy()
    ams["overall"] = ams[SCORE_COLS].mean(axis=1)
    for _, r in ams.nlargest(5, "overall").iterrows():
        print(f"    {r['name']:<32} {r['overall']:>+.3f}")
    print()


def plot_city_means(df):
    city_means = df.groupby("city")[SCORE_COLS].mean()
    city_means["overall"] = city_means.mean(axis=1)
    city_means = city_means.sort_values("overall")

    fig, ax = plt.subplots(figsize=(10, 12))
    y = np.arange(len(city_means))
    bh = 0.15

    for i, (dim, col) in enumerate(zip(DIMS, SCORE_COLS)):
        ax.barh(y + i * bh, city_means[col], height=bh,
                label=dim.capitalize(), color=DIM_COLORS[i], alpha=0.85)

    ax.set_yticks(y + bh * 2)
    ax.set_yticklabels([c.replace("_", " ").title() for c in city_means.index],
                       fontsize=8)
    ax.set_xlabel("Mean Park Score (z-score)")
    ax.set_title("Mean Park Quality Scores by City", fontweight="bold")
    ax.legend(loc="lower right", fontsize=8)
    ax.axvline(0, color="grey", lw=0.5, ls="--")
    ax.grid(axis="x", alpha=0.3)
    plt.tight_layout()

    path = os.path.join(OUT_DIR, "city_mean_scores.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_radar(df, city="berlin"):
    city_vals = df[df["city"] == city][SCORE_COLS].mean().values
    global_vals = df[SCORE_COLS].mean().values

    angles = np.linspace(0, 2 * np.pi, len(DIMS), endpoint=False).tolist()
    angles += angles[:1]
    city_vals = np.append(city_vals, city_vals[0])
    global_vals = np.append(global_vals, global_vals[0])

    fig, ax = plt.subplots(figsize=(6, 6), subplot_kw=dict(polar=True))
    ax.plot(angles, city_vals, "o-", lw=2, color="#e74c3c",
            label=city.replace("_", " ").title())
    ax.fill(angles, city_vals, alpha=0.15, color="#e74c3c")
    ax.plot(angles, global_vals, "s--", lw=1.5, color="#7f8c8d",
            label="Global Average")
    ax.fill(angles, global_vals, alpha=0.08, color="#7f8c8d")

    ax.set_xticks(angles[:-1])
    ax.set_xticklabels([d.capitalize() for d in DIMS], fontsize=10)
    ax.set_title(
        f"{city.replace('_', ' ').title()} vs Global Average",
        fontweight="bold", pad=20,
    )
    ax.legend(loc="lower right", fontsize=9)
    plt.tight_layout()

    path = os.path.join(OUT_DIR, f"radar_{city}.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_distributions(df):
    fig, axes = plt.subplots(1, 5, figsize=(14, 5), sharey=True)
    for ax, dim, col, c in zip(axes, DIMS, SCORE_COLS, DIM_COLORS):
        data = [df[df["city"] == city][col].values
                for city in sorted(df["city"].unique())]
        bp = ax.boxplot(data, orientation="vertical", patch_artist=True,
                        showfliers=False)
        for patch in bp["boxes"]:
            patch.set_facecolor(c)
            patch.set_alpha(0.6)
        ax.set_title(dim.capitalize(), fontsize=10, fontweight="bold")
        ax.set_xticks([])
        ax.axhline(0, color="grey", lw=0.5, ls="--")
        ax.grid(axis="y", alpha=0.3)

    axes[0].set_ylabel("Score (z-score)")
    fig.suptitle("Park Score Distributions Across 35 Cities",
                 fontweight="bold", fontsize=12)
    plt.tight_layout()

    path = os.path.join(OUT_DIR, "score_distributions.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_correlation(df):
    corr = df[SCORE_COLS].corr()
    labels = [d.capitalize() for d in DIMS]

    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(corr.values, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(len(labels)))
    ax.set_yticks(range(len(labels)))
    ax.set_xticklabels(labels, rotation=45, ha="right", fontsize=9)
    ax.set_yticklabels(labels, fontsize=9)

    for i in range(len(labels)):
        for j in range(len(labels)):
            val = corr.values[i, j]
            color = "white" if abs(val) > 0.5 else "black"
            ax.text(j, i, f"{val:.2f}", ha="center", va="center",
                    fontsize=10, color=color)

    fig.colorbar(im, ax=ax, shrink=0.8, label="Pearson r")
    ax.set_title("Correlation Between Score Dimensions", fontweight="bold")
    plt.tight_layout()

    path = os.path.join(OUT_DIR, "dimension_correlation.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_top_bottom(df):
    city_means = df.groupby("city")[SCORE_COLS].mean()

    fig, axes = plt.subplots(1, 5, figsize=(16, 6), sharey=False)
    for ax, dim, col, c in zip(axes, DIMS, SCORE_COLS, DIM_COLORS):
        sorted_cities = city_means[col].sort_values()
        bottom5 = sorted_cities.head(5)
        top5 = sorted_cities.tail(5)
        show = pd.concat([bottom5, top5])

        labels = [n.replace("_", " ").title() for n in show.index]
        colors = ["#e74c3c"] * 5 + ["#2ecc71"] * 5
        ax.barh(range(len(show)), show.values, color=colors, alpha=0.8)
        ax.set_yticks(range(len(show)))
        ax.set_yticklabels(labels, fontsize=7)
        ax.set_title(dim.capitalize(), fontsize=10, fontweight="bold")
        ax.axvline(0, color="grey", lw=0.5, ls="--")
        ax.grid(axis="x", alpha=0.3)

    fig.suptitle("Top 5 (green) and Bottom 5 (red) Cities per Dimension",
                 fontweight="bold", fontsize=12)
    plt.tight_layout()

    path = os.path.join(OUT_DIR, "top_bottom_cities.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"  Saved: {path}")


def save_summary_csv(df):
    city_stats = df.groupby("city").agg(
        n_parks=("osm_id", "count"),
        total_area_ha=("area", "sum"),
        mean_area_ha=("area", "mean"),
        **{f"mean_{d}": (col, "mean") for d, col in zip(DIMS, SCORE_COLS)},
    ).round(3)
    city_stats["overall_mean"] = city_stats[
        [f"mean_{d}" for d in DIMS]
    ].mean(axis=1).round(3)
    city_stats = city_stats.sort_values("overall_mean", ascending=False)

    path = os.path.join(OUT_DIR, "summary_stats.csv")
    city_stats.to_csv(path)
    print(f"  Saved: {path}")


# --- Part B: Berlin pipeline results

def _load_pipeline_csv(name, city="berlin"):
    path = os.path.join(OUT_DIR, f"{name}_{city}.csv")
    if not os.path.exists(path):
        return None
    return pd.read_csv(path)


def plot_qwe_histogram(city="berlin"):
    qwe = _load_pipeline_csv("qwe", city)
    if qwe is None:
        return
    qwe_cols = [f"QWE_{d}" for d in DIMS]

    fig, axes = plt.subplots(1, 5, figsize=(16, 4), sharey=True)
    for ax, dim, col, c in zip(axes, DIMS, qwe_cols, DIM_COLORS):
        vals = qwe[col].dropna()
        ax.hist(vals[vals > 0], bins=40, color=c, alpha=0.75, edgecolor="white")
        ax.set_title(dim.capitalize(), fontsize=10, fontweight="bold")
        ax.set_xlabel("QWE value")
        ax.grid(axis="y", alpha=0.3)
        ax.text(0.95, 0.95, f"n={len(vals)}", transform=ax.transAxes,
                ha="right", va="top", fontsize=8, color="grey")

    axes[0].set_ylabel("Number of cells")
    fig.suptitle(f"Quality-Weighted Exposure (QWE) - {city.title()}",
                 fontweight="bold", fontsize=12)
    plt.tight_layout()

    path = os.path.join(OUT_DIR, f"berlin_qwe_histogram.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_qamd_histogram(city="berlin"):
    qamd = _load_pipeline_csv("qamd", city)
    if qamd is None:
        return
    qamd_cols = [f"QAMD_{d}" for d in DIMS]

    fig, axes = plt.subplots(1, 5, figsize=(16, 4), sharey=True)
    for ax, dim, col, c in zip(axes, DIMS, qamd_cols, DIM_COLORS):
        vals = qamd[col].dropna()
        ax.hist(vals, bins=40, color=c, alpha=0.75, edgecolor="white")
        ax.axvline(15, color="black", lw=1, ls="--", label="15-min target")
        ax.set_title(dim.capitalize(), fontsize=10, fontweight="bold")
        ax.set_xlabel("Minutes")
        ax.grid(axis="y", alpha=0.3)
        within_15 = (vals <= 15).sum()
        pct = 100 * within_15 / len(vals) if len(vals) > 0 else 0
        ax.text(0.95, 0.95, f"<15min: {pct:.0f}%", transform=ax.transAxes,
                ha="right", va="top", fontsize=8, color="grey")

    axes[0].set_ylabel("Number of cells")
    axes[0].legend(fontsize=7, loc="upper left")
    fig.suptitle(
        f"Quality-Adjusted Min Distance (QAMD, q=0) - {city.title()}",
        fontweight="bold", fontsize=12,
    )
    plt.tight_layout()

    path = os.path.join(OUT_DIR, f"berlin_qamd_histogram.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_gma_histogram(city="berlin"):
    gma = _load_pipeline_csv("gma", city)
    if gma is None:
        return
    gma_cols = [f"GMA_{d}" for d in DIMS]

    fig, axes = plt.subplots(1, 5, figsize=(16, 4), sharey=True)
    for ax, dim, col, c in zip(axes, DIMS, gma_cols, DIM_COLORS):
        vals = gma[col].dropna()
        ax.hist(vals[vals > 0], bins=40, color=c, alpha=0.75, edgecolor="white")
        ax.set_title(dim.capitalize(), fontsize=10, fontweight="bold")
        ax.set_xlabel("GMA value")
        ax.grid(axis="y", alpha=0.3)

    axes[0].set_ylabel("Number of cells")
    fig.suptitle(
        f"Gravity-Model Accessibility (GMA, tau=10) - {city.title()}",
        fontweight="bold", fontsize=12,
    )
    plt.tight_layout()

    path = os.path.join(OUT_DIR, f"berlin_gma_histogram.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_coverage(city="berlin"):
    qwe = _load_pipeline_csv("qwe", city)
    qamd = _load_pipeline_csv("qamd", city)
    gma = _load_pipeline_csv("gma", city)
    if qwe is None or qamd is None or gma is None:
        return

    total = TOTAL_CELLS
    categories = []
    values = []

    categories.append("QWE > 0\n(any dim)")
    qwe_cols = [f"QWE_{d}" for d in DIMS]
    qwe_any = (qwe[qwe_cols].sum(axis=1) > 0).sum()
    values.append(100 * qwe_any / total)

    for d in DIMS:
        col = f"QAMD_{d}"
        within = (qamd[col].dropna() <= 15).sum()
        categories.append(f"QAMD {d[:4]}\n<15 min")
        values.append(100 * within / total)

    categories.append("GMA > 0\n(any dim)")
    gma_cols = [f"GMA_{d}" for d in DIMS]
    gma_any = (gma[gma_cols].sum(axis=1) > 0).sum()
    values.append(100 * gma_any / total)

    fig, ax = plt.subplots(figsize=(10, 5))
    colors = (["#2c3e50"]
              + DIM_COLORS
              + ["#2c3e50"])
    bars = ax.bar(range(len(categories)), values, color=colors, alpha=0.8)
    ax.set_xticks(range(len(categories)))
    ax.set_xticklabels(categories, fontsize=8)
    ax.set_ylabel("% of grid cells (n={:,})".format(total))
    ax.set_title(
        f"Berlin - Accessibility Coverage (% of {total:,} cells)",
        fontweight="bold",
    )
    ax.set_ylim(0, 100)
    ax.grid(axis="y", alpha=0.3)

    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 1,
                f"{val:.1f}%", ha="center", va="bottom", fontsize=8)

    plt.tight_layout()
    path = os.path.join(OUT_DIR, "berlin_coverage.png")
    fig.savefig(path, dpi=150)
    plt.close(fig)
    print(f"  Saved: {path}")


def save_index_summary(city="berlin"):
    rows = []

    for name, prefix in [("QWE", "QWE"), ("QAMD", "QAMD"), ("GMA", "GMA")]:
        df = _load_pipeline_csv(name.lower(), city)
        if df is None:
            continue
        for d in DIMS:
            col = f"{prefix}_{d}"
            if col not in df.columns:
                continue
            vals = df[col].dropna()
            row = {
                "index": name,
                "dimension": d,
                "cells_with_value": len(vals),
                "pct_of_total": round(100 * len(vals) / TOTAL_CELLS, 1),
                "mean": round(vals.mean(), 4),
                "median": round(vals.median(), 4),
                "std": round(vals.std(), 4),
                "min": round(vals.min(), 4),
                "max": round(vals.max(), 4),
            }
            if name == "QAMD":
                row["pct_within_15min"] = round(
                    100 * (vals <= 15).sum() / len(vals), 1
                ) if len(vals) > 0 else 0
            rows.append(row)

    out = pd.DataFrame(rows)
    path = os.path.join(OUT_DIR, f"berlin_index_summary.csv")
    out.to_csv(path, index=False)
    print(f"  Saved: {path}")


# --- Main

if __name__ == "__main__":
    os.makedirs(OUT_DIR, exist_ok=True)
    print("\nLoading scores data...")
    df = load_scores()

    print_summary(df)

    print("\nPart A: Cross-city score visualizations...")
    plot_city_means(df)
    plot_radar(df, city="berlin")
    plot_distributions(df)
    plot_correlation(df)
    plot_top_bottom(df)
    save_summary_csv(df)

    print("\nPart B: Berlin pipeline results...")
    has_pipeline = os.path.exists(os.path.join(OUT_DIR, "qwe_berlin.csv"))
    if has_pipeline:
        plot_qwe_histogram()
        plot_qamd_histogram()
        plot_gma_histogram()
        plot_coverage()
        save_index_summary()
    else:
        print("  (Pipeline CSVs not found. Run quality_accessibility_osmium.py first.)")

    print(f"\nDone. All outputs in: {OUT_DIR}/")
