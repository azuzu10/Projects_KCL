# Quantifying Urban Greenspace Globally

Code for my MSc final project. Azaan Tak, K25125234, supervised by Linus Dietz,
Department of Informatics, 7CCSMPRJ.

The project takes park quality scores from Dietz et al. and the grid-based accessibility
framework from ATGreen and joins them, so that a park's contribution to a resident's
accessibility depends on what the park actually offers rather than just its area. Four
indices come out of that. This archive has the code that computes them, the figures that
went into the report, and the summary tables behind every number I quote.

The rest of this file is a walk through what is in here, what is not and why, and how to
run it if you want to.


## The code

Everything is in `code/`. The one file to start with is `quality_accessibility_osmium.py`
— it is the whole pipeline end to end: read a city boundary and its parks out of an OSM
extract, lay the GHS grid over the city, work out which parks overlap which cells, give
each cell an area-weighted quality score, build the origin-destination matrix, and compute
QWE, QAMD, GMA and BEST. It is unchanged from the single-city version of this project.

I did not want to edit that file once the ten-city runs started, so the four modules that
make the larger cities feasible rebind functions at import time instead:

- `fast_grid.py` builds the grid with vectorised numpy rather than a Python loop. Same
  92,655 cells for Amsterdam, same geometries, roughly ten times faster.
- `fast_distance.py` does the distance matrix with a KD-tree. Amsterdam again: the same
  9,072,560 pairs, the same distances.
- `targeted_parks.py` was the one I actually needed. The default approach indexes every
  node in the extract to resolve park coordinates, which is fine for Noord-Holland and
  hopeless for Spain (1.4 GB) or Quebec (1.1 GB). This resolves coordinates only for the
  park IDs in the Dietz fingerprints. Checked against the original on Amsterdam (106
  parks) and Melbourne (1,787).
- `lowmem_index.py` is a spatial index helper the staged runner leans on.

`run_city_staged.py` is what I ran for all ten cities. It wraps the pipeline in seven
cached stages so a run that dies at hour three picks up where it stopped, and it takes
`--chunk-origins` to keep memory bounded. `accessibility_cli.py` is the plainer entry
point for a single city with no staging.

For the analysis on top: `sensitivity.py` runs the four parameter sweeps in Section 5.9
of the report (threshold, buffer, tau, q) and `crosscity_compare.py` pulls the ten runs
together into the coverage table, the dimension-gap analysis, the boundary correlation
and the conditional measure.

The visualisation scripts are `visualize_map.py` (choropleths over the grid),
`visualize_scores.py` (histograms, radar plots, distributions for one city) and
`visualize_scores_multi.py` (panels). There are also nine `visualize_scores_<city>.py`
files. These are generated copies that differ only in the city name and bounding box —
not elegant, but each published figure has the exact script that made it sitting next to
it, which seemed worth more than a tidy refactor.

`download_extracts.bat` fetches the ten Geofabrik extracts.


## Everything else in the archive

`figures/` holds the 20 images that appear in the report, at the size they were placed at.

`results/` has the small tables. There is a `<city>_index_summary.csv` and a
`meta_<city>.csv` for each of the ten cities — the first is coverage and mean values for
the four indices across the five dimensions, the second records which OSM relation was
used, which extract, the snapshot date, cell and park counts, and the park recovery rate.
`crosscity_summary.csv` is the ten-city table behind Chapter 5, `summary_stats.csv` the
aggregates, and the four `sensitivity_*.csv` files the sweeps (threshold and buffer cover
all ten cities; tau and q cover three, for reasons the report explains). Between them,
every figure and table in the report can be rebuilt without running the pipeline again.

`report_source/` is the LaTeX source of the report and its figures. Three passes of
`pdflatex` if you want to compile it.

`AUTHORSHIP.txt` is the signed statement, and `requirements.txt` pins the versions I used.


## What I have left out

**The OSM extracts.** Ten Geofabrik files, 4.4 GB. They are a download away and
`code/download_extracts.bat` will get them, but they are not something to put in a
submission archive. One caveat: OpenStreetMap changes daily, so the results are
reproducible against the snapshots I used, not against whatever is current. Those dates
are in `results/meta_<city>.csv`.

**The per-cell outputs**, another 631 MB. `qwe_<city>.csv`, `qamd_<city>.csv`,
`gma_<city>.csv`, `best_<city>.csv`, `cells_<city>.csv`, `cell_scores_<city>.csv`,
`overlap_<city>.csv` and the `parks_<city>.geojson` files are one row per grid cell or per
park, and there are 3.3 million cells across the sample. Running the pipeline regenerates
them. What the report actually cites are the aggregates, and those are in `results/`.

**The two upstream projects.** This work extends both, and neither is mine to
redistribute:

- ATGreen, Battiston and Schifanella (2023), MIT — https://github.com/alessandrobattiston/ATGreen
- Health-Promoting Parks, Dietz et al. (2025), MIT — https://github.com/lineflow/Health-Promoting-Parks-Replication

I consume exactly two files from the Dietz package: `scores_cities.csv` (the park quality
scores) and `fingerprints_cities.csv` (raw element counts, and the `osm_id` field I use to
find each park in the PBF). Drop them in `data/` before running.

The Python libraries in `requirements.txt` are left out too, per the submission guidance
on well-known third-party libraries.


## Running it

Python 3.11 or newer; I was on 3.14.0.

```bash
python -m venv .venv
.venv\Scripts\activate            # Windows
# source .venv/bin/activate       # Linux / macOS
pip install -r requirements.txt
```

Get the extracts, then run a city:

```bash
code\download_extracts.bat

python code/run_city_staged.py amsterdam pbf_data/noord-holland-260620.osm.pbf \
       --out-dir output_figures --chunk-origins 12000
```

Then the same for berlin, madrid, melbourne, montreal, new_york, paris, rome, singapore
and washington_dc, each pointed at its own extract. `--chunk-origins` only affects memory,
not results — I checked that by running Amsterdam at two different chunk sizes and diffing
the output byte for byte.

Figures and comparison afterwards:

```bash
python code/visualize_scores_paris.py          # and the other nine
python code/crosscity_compare.py --out-dir output_figures
python code/sensitivity.py --out-dir output_figures
```

A word on how long this takes, because it varies enormously. Paris is 49,447 cells and
finishes in a few minutes. Melbourne is 1,626,690 cells and about 62 million
origin-destination pairs, and takes hours. Memory stays under 4 GB at the default chunk
size. Spain and Quebec need `targeted_parks.py`, but the staged runner switches to it on
its own, so there is nothing to set.


## Licensing

Park and boundary geometry comes from OpenStreetMap, © OpenStreetMap contributors, under
the ODbL. The tables in `results/` and the figures are Produced Works — attribution is
required, share-alike is not. The per-cell CSVs and the `parks_<city>.geojson` files would
be a Derivative Database, which is a stricter obligation, and if I ever publish them they
have to go out under the ODbL itself. They are not in this archive. Chapter 7 of the
report goes into this properly.

The park quality scores come from the Dietz et al. replication package, MIT licensed.
